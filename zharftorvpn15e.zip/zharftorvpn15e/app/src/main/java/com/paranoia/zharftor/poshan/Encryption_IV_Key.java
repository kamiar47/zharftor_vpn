package com.paranoia.zharftor.poshan;

import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class Encryption_IV_Key {
    public IvParameterSpec IV;
    public SecretKeySpec Key;
}
