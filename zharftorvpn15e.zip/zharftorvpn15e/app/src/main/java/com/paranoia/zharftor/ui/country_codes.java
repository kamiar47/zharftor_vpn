package com.paranoia.zharftor.ui;

import static com.paranoia.zharftor.vpn_service.vpn;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import com.paranoia.zharftor.R;
import com.paranoia.zharftor.vpn_service;

import java.util.HashMap;
import java.util.Map;

public class country_codes {
    private static Map<String,String> countries;
    private static int counter=0;
    public static String get_city_and_country_by_code(int code){
        if(countries==null) {
            flags=new HashMap<>();
            countries = new HashMap<>();
            countries.put(String.valueOf(counter++),"US California");
            countries.put(String.valueOf(counter++),"US Seattle");
            countries.put(String.valueOf(counter++),"US Chicago");
            countries.put(String.valueOf(counter++),"US New York");
            countries.put(String.valueOf(counter++),"US Las Vagas");
            flags.put("us", BitmapFactory.decodeResource(vpn_service.activity.getResources(), R.drawable.flag_of_us));
            countries.put(String.valueOf(counter++),"Mexico Mexico City");
            flags.put("mexico", BitmapFactory.decodeResource(vpn_service.activity.getResources(), R.drawable.flag_of_mexico));
            countries.put(String.valueOf(counter++),"Germany Berlin");
            countries.put(String.valueOf(counter++),"Germany Frankfurt");
            countries.put(String.valueOf(counter++),"Germany Hamburg");
            countries.put(String.valueOf(counter++),"Germany Monich");
            flags.put("germany", BitmapFactory.decodeResource(vpn_service.activity.getResources(), R.drawable.flag_of_germany));
            countries.put(String.valueOf(counter++),"Italy Rome");
            flags.put("italy", BitmapFactory.decodeResource(vpn_service.activity.getResources(), R.drawable.flag_of_italy));
            countries.put(String.valueOf(counter++),"Belgium Brussels");
            flags.put("belgium", BitmapFactory.decodeResource(vpn_service.activity.getResources(), R.drawable.flag_of_belgium));
            countries.put(String.valueOf(counter++),"Netherlands Amsterdam");
            flags.put("netherlands", BitmapFactory.decodeResource(vpn_service.activity.getResources(), R.drawable.flag_of_netherlands));
            countries.put(String.valueOf(counter++),"Australia Melbourn");
            flags.put("australia", BitmapFactory.decodeResource(vpn_service.activity.getResources(), R.drawable.flag_of_australia));
            countries.put(String.valueOf(counter++),"France Paris");
            flags.put("france", BitmapFactory.decodeResource(vpn_service.activity.getResources(), R.drawable.flag_of_france));
            countries.put(String.valueOf(counter++),"Spain Madrid");
            flags.put("spain", BitmapFactory.decodeResource(vpn_service.activity.getResources(), R.drawable.flag_of_spain));
            countries.put(String.valueOf(counter++),"Hungary Budapest");
            flags.put("hungary", BitmapFactory.decodeResource(vpn_service.activity.getResources(), R.drawable.flag_of_hungary));
            countries.put(String.valueOf(counter++),"Slovakia Bratislava");
            flags.put("slovakia", BitmapFactory.decodeResource(vpn_service.activity.getResources(), R.drawable.flag_of_slovakia));
            countries.put(String.valueOf(counter++),"Austria Vienna");
            flags.put("austria", BitmapFactory.decodeResource(vpn_service.activity.getResources(), R.drawable.flag_of_austria));
            countries.put(String.valueOf(counter++),"Switzerland Zurich");
            flags.put("switzerland", BitmapFactory.decodeResource(vpn_service.activity.getResources(), R.drawable.flag_of_switzerland));
            countries.put(String.valueOf(counter++),"UK London");
            flags.put("uk", BitmapFactory.decodeResource(vpn_service.activity.getResources(), R.drawable.flag_of_uk));
            countries.put(String.valueOf(counter++),"Ireland Dublin");
            flags.put("ireland", BitmapFactory.decodeResource(vpn_service.activity.getResources(), R.drawable.flag_of_ireland));
            countries.put(String.valueOf(counter++),"India New Delhi");
            flags.put("india", BitmapFactory.decodeResource(vpn_service.activity.getResources(), R.drawable.flag_of_india));
            countries.put(String.valueOf(counter++),"russia moscow");
            flags.put("russia", BitmapFactory.decodeResource(vpn_service.activity.getResources(), R.drawable.flag_of_russia));
            countries.put(String.valueOf(counter++),"china");
            flags.put("china", BitmapFactory.decodeResource(vpn_service.activity.getResources(), R.drawable.flag_of_china));
            countries.put(String.valueOf(counter++),"japan");
            flags.put("japan", BitmapFactory.decodeResource(vpn_service.activity.getResources(), R.drawable.flag_of_japan));

            countries.put(String.valueOf(254),"unknown");
        }
        if(countries.get(String.valueOf(code&0xff))==null)
            return countries.get(String.valueOf(254));
        return countries.get(String.valueOf(code&0xff));
    }
    public static Map<String, Bitmap> flags;
}
