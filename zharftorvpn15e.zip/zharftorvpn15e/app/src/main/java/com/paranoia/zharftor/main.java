package com.paranoia.zharftor;
import android.app.Dialog;

import com.paranoia.zharftor.ui.country_codes;
import com.paranoia.zharftor.ui.utils;
import android.content.Intent;
import android.content.IntentSender;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.lifecycle.Lifecycle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.vectordrawable.graphics.drawable.Animatable2Compat;
import androidx.vectordrawable.graphics.drawable.AnimatedVectorDrawableCompat;

import com.google.android.gms.tasks.Task;
import com.google.android.play.core.appupdate.AppUpdateInfo;
import com.google.android.play.core.appupdate.AppUpdateManager;
import com.google.android.play.core.appupdate.AppUpdateManagerFactory;
import com.google.android.play.core.install.model.AppUpdateType;
import com.google.android.play.core.install.model.UpdateAvailability;
import com.paranoia.zharftor.ui.recyclers_adapters;
import com.paranoia.zharftor.ui.servers_adapter;
import com.yandex.metrica.YandexMetrica;
import com.yandex.metrica.YandexMetricaConfig;

import java.util.Iterator;
import java.util.Locale;
public class main extends main_with_ads {
    private String API_key="5160dc2e-f1b4-4bab-964b-7e189af7368d";
    private RecyclerView serverslist;
//    private RelativeLayout time_container;
//    private TextView time_holder_textview;
//    private CountDownTimer time_left_updater;
//    private Button add_time_button;
    private recyclers_adapters.app_chooser_recycler apps_chooser_adapter;
    private app_data_and_preferences.filter_address_entry address_filter_entry=new app_data_and_preferences.filter_address_entry();
    private recyclers_adapters.ip_addresses_recycler allow_all_addresses_adapter,
            disallow_all_addresses_adapter;
    private recyclers_adapters.apps_list_recycler rejected_apps_adapter,accepted_apps_adapter;
    public servers_adapter s_adepter;
    private LinearLayoutManager servers_LayoutManager;
    private Intent vpn_service_intent;
    private Dialog address_filter_dialog,app_filter_dialog;
    public short app_ui_state, vpn_connection_state;
    private TextView connection_btn;
    private RadioButton disallow_all_addrs_radio, allow_all_addrs_radio;
    private LinearLayoutCompat disallow_all_addrs_container, allow_all_addrs_container;
    private RelativeLayout main_page,terms_and_conditions_page,preload_page,privacy_policy_page,config_page;
    private WebView terms_and_conditions_webview,privacy_policy_webview;
    private LinearLayout parent_layout,servers_list_page;
    private ImageView current_country_icon;
    private void connect_click_listener(){
        {
            if(vpn_connection_state ==VPN_STATE_CONNECTED){
                vpn_service_intent.putExtra("disconnect", true);
                startService(vpn_service_intent);
                s_adepter.load_servers_delays();
                return;
            }
            if(vpn_connection_state ==VPN_STATE_CONNECTING){
                vpn_service_intent.putExtra("disconnect", true);
                startService(vpn_service_intent);
                return;
            }
            if(vpn_connection_state ==VPN_STATE_UNCONNETED&&!cent_server_interface.is_effective_response){
                if(app_data_and_preferences.getInstance().should_show_ad()&&
                        !continue_without_ads())
                {
                    show_ad_interstitial();
                    return;
                }
                vpn_service_intent.putExtra("disconnect", false);
                startService(vpn_service_intent);
//                AnimatedVectorDrawable ad=(AnimatedVectorDrawable)im.getDrawable();
//                ad.start();
                return;
            }else {
                Toast.makeText(main.this, "please wait", Toast.LENGTH_SHORT).show();
            }
        }
    };
    public static final short CONNECTION_STATUS_GATHERING_SERVER_INFO=0,CONNECTION_STATUS_EXCHANGING_KEYS=1,CONNECTION_STATUS_READY_OR_CONNECTED=2, UI_STATE_FIRST_USE=0
            ,VPN_STATE_UNCONNETED=1,VPN_STATE_CONNECTING=2,VPN_STATE_CONNECTED=3,UI_STATE_TERM_AND_CONDITIONS=4
            ,UI_STATE_PRIVACY_POLICY=5,UI_STATE_CONFIG=6,UI_STATE_SERVER_SELECTION=7,UI_STATE_MAIN=8
            ,UI_STATE_PRELOAD=9;

    ImageView im;

    @Override
    protected void onStart() {
        super.onStart();
    }
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        YandexMetricaConfig config = YandexMetricaConfig.newConfigBuilder(API_key).build();
//         Initializing the AppMetrica SDK.
        YandexMetrica.activate(getApplicationContext(), config);
//         Automatic tracking of user activity.
        YandexMetrica.enableActivityAutoTracking( getApplication());
        app_data_and_preferences.getInstance().load_essentials();
        evaluate_state();

        set_up_pages();
//        app_data_and_preferences.getInstance().load_address_filter_info();
        check_for_mandatory_update();
    }
    private void check_for_mandatory_update(){
        AppUpdateManager appUpdateManager = AppUpdateManagerFactory.create(this);
// Returns an intent object that you use to check for an update.
        Task<AppUpdateInfo> appUpdateInfoTask = appUpdateManager.getAppUpdateInfo();
// Checks that the platform will allow the specified type of update.
        appUpdateInfoTask.addOnSuccessListener(appUpdateInfo -> {
            if (appUpdateInfo.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE
                    // This example applies an immediate update. To apply a flexible update
                    // instead, pass in AppUpdateType.FLEXIBLE
                    && appUpdateInfo.isUpdateTypeAllowed(AppUpdateType.IMMEDIATE)) {
                // Request the update.
                try {
                    appUpdateManager.startUpdateFlowForResult(
                            // Pass the intent that is returned by 'getAppUpdateInfo()'.
                            appUpdateInfo,
                            // Or 'AppUpdateType.FLEXIBLE' for flexible updates.
                            AppUpdateType.IMMEDIATE,
                            // The current activity making the update request.
                            this,
                            // Include a request code to later monitor this update request.
                            11);
                } catch (IntentSender.SendIntentException e) {
//                    e.printStackTrace();
                }
            }
        });
    }
    private void evaluate_state(){
        if(vpn_service.is_connected()){
            vpn_connection_state =VPN_STATE_CONNECTED;
        }else if(vpn_service.is_connecting()){
            vpn_connection_state =VPN_STATE_CONNECTING;
        }else {
            vpn_connection_state =VPN_STATE_UNCONNETED;
        }
    }
    public void set_up_pages(){
        parent_layout=(LinearLayout)findViewById(R.id.parent);
        main_page=(RelativeLayout) getLayoutInflater().inflate(R.layout.vpn_main_page,null);
        config_page=(RelativeLayout) getLayoutInflater().inflate(R.layout.config_page,null);
        servers_list_page=(LinearLayout) getLayoutInflater().inflate(R.layout.servers_page,null);
        privacy_policy_page=(RelativeLayout) getLayoutInflater().inflate(R.layout.privacy_policy_page,null);
        terms_and_conditions_page =(RelativeLayout) getLayoutInflater().inflate(R.layout.terms_and_conditions_page,null);
        preload_page =(RelativeLayout) getLayoutInflater().inflate(R.layout.preload_page,null);
        parent_layout.addView(main_page);
        parent_layout.addView(config_page);
        parent_layout.addView(servers_list_page);
        parent_layout.addView(privacy_policy_page);
        parent_layout.addView(terms_and_conditions_page);
        parent_layout.addView(preload_page);
        address_filter_dialog =new Dialog(main.this);
        app_filter_dialog=new Dialog(main.this);
        im=main_page.findViewById(R.id.vec_imageview);
        im.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                connect_click_listener();
            }
        });
//        time_container=(RelativeLayout)main_page.findViewById(R.id.time_left_container);
//        time_holder_textview=(TextView) main_page.findViewById(R.id.time_left_textview);
//        add_time_button=(Button) main_page.findViewById(R.id.add_time);
//        add_time_button.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                show_ad_rewarded();
//            }
//        });
        current_country_icon=(ImageView)main_page.findViewById(R.id.current_country_image);
        con_anim=AnimatedVectorDrawableCompat.create(this,R.drawable.animation_connect);
        ent_anim=AnimatedVectorDrawableCompat.create(this,R.drawable.entrance_wait_animator);
        discon_anim=AnimatedVectorDrawableCompat.create(this,R.drawable.animation_disconnect);
        connection_btn =main_page.findViewById(R.id.connection_text);
        privacy_policy_webview=(WebView) privacy_policy_page.findViewById(R.id.privacy_webview);
        WebSettings webSettings = privacy_policy_webview.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setJavaScriptCanOpenWindowsAutomatically(true);
        if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
            webSettings.setAllowFileAccessFromFileURLs(true);
            webSettings.setAllowUniversalAccessFromFileURLs(true);
        }
        privacy_policy_webview.loadUrl("file:///android_asset/html/privacy_policy.html");
        terms_and_conditions_webview=(WebView)terms_and_conditions_page.findViewById(R.id.terms_webview);
        WebSettings webSettings1 = terms_and_conditions_webview.getSettings();
        webSettings1.setJavaScriptEnabled(true);
        webSettings1.setJavaScriptCanOpenWindowsAutomatically(true);
        if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
            webSettings1.setAllowFileAccessFromFileURLs(true);
            webSettings1.setAllowUniversalAccessFromFileURLs(true);
        }
        terms_and_conditions_webview.loadUrl("file:///android_asset/html/terms_and_conditions.html");

        vpn_service_intent = new Intent(this, com.paranoia.zharftor.vpn_service.class);
        evaluate_state();
        if(app_data_and_preferences.getInstance().is_first_time()){
            terms_and_conditions_page.findViewById(R.id.tc_agree_button).setVisibility(View.VISIBLE);
            privacy_policy_page.findViewById(R.id.pp_agree_button).setVisibility(View.VISIBLE);
            terms_and_conditions_page.findViewById(R.id.tc_agree_button).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    app_ui_state =UI_STATE_PRIVACY_POLICY;
                    set_ui_state(app_ui_state);
                }
            });
            privacy_policy_page.findViewById(R.id.pp_agree_button).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    app_data_and_preferences.getInstance().mark_first_time();
                    app_ui_state =UI_STATE_MAIN;
                    set_ui_state(app_ui_state);
                    terms_and_conditions_page.findViewById(R.id.tc_agree_button).setVisibility(View.GONE);
                    privacy_policy_page.findViewById(R.id.pp_agree_button).setVisibility(View.GONE);
                }
            });
            app_ui_state =UI_STATE_TERM_AND_CONDITIONS;
            set_ui_state(app_ui_state);
        }else{
            privacy_policy_page.findViewById(R.id.pp_agree_button).setVisibility(View.GONE);
            terms_and_conditions_page.findViewById(R.id.tc_agree_button).setVisibility(View.GONE);
            app_ui_state =UI_STATE_MAIN;
            set_ui_state(app_ui_state);
        }

        connection_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                connect_click_listener();
            }
        });
        main_page.findViewById(R.id.servers_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(cent_server_interface.is_effective_response){
                    Toast.makeText(main.this, "couldn't load servers list.", Toast.LENGTH_SHORT).show();
                    return;
                }
                app_ui_state =UI_STATE_SERVER_SELECTION;
                set_ui_state(app_ui_state);
                s_adepter.notifyDataSetChanged();
            }
        });
        //temporarily disable config
//        main_page.findViewById(R.id.config_button).setVisibility(View.GONE);
        allow_all_addresses_adapter =new recyclers_adapters.ip_addresses_recycler(recyclers_adapters.ip_addresses_recycler.type_rejected_ips,this);
        disallow_all_addresses_adapter =new recyclers_adapters.ip_addresses_recycler(recyclers_adapters.ip_addresses_recycler.type_accepted_ips,this);
        main_page.findViewById(R.id.config_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                app_ui_state =UI_STATE_CONFIG;
                set_ui_state(app_ui_state);
            }
        });
        main_page.findViewById(R.id.terms_n_conds_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                app_ui_state =UI_STATE_TERM_AND_CONDITIONS;
                set_ui_state(app_ui_state);
            }
        });
        main_page.findViewById(R.id.privacy_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                app_ui_state =UI_STATE_PRIVACY_POLICY;
                set_ui_state(app_ui_state);
            }
        });
        serverslist=(RecyclerView) servers_list_page.findViewById(R.id.servers_recycler_view);
        servers_LayoutManager=new LinearLayoutManager(this);
        serverslist.setLayoutManager(servers_LayoutManager);
        s_adepter =new servers_adapter(this);
        serverslist.setAdapter(s_adepter);
        //filters
        allow_all_addrs_container =(LinearLayoutCompat) config_page.findViewById(R.id.filter_allow_all_except);
        allow_all_addrs_radio =(RadioButton) config_page.findViewById(R.id.filter_radio_allow_all_except);
        disallow_all_addrs_container =(LinearLayoutCompat) config_page.findViewById(R.id.filter_disallow_all_except);
        disallow_all_addrs_radio =(RadioButton) config_page.findViewById(R.id.filter_radio_disallow_all_except);
//        allow_container.addView(getLayoutInflater().inflate(R.layout.config_ip_input,null));
//        disallow_container.addView(getLayoutInflater().inflate(R.layout.config_ip_input,null));
        allow_all_addrs_container.getChildAt(1).setVisibility(View.GONE);
        disallow_all_addrs_container.getChildAt(1).setVisibility(View.GONE);
        RecyclerView recyclerView_address_allowed= disallow_all_addrs_container.findViewById(R.id.allowed_list_recycler_view),
                recyclerView_address_rejected= allow_all_addrs_container.findViewById(R.id.rejected_list_recycler_view);
        LinearLayoutManager llm0=new LinearLayoutManager(this),llm1=new LinearLayoutManager(this);
        recyclerView_address_allowed.setLayoutManager(llm0);
        recyclerView_address_rejected.setLayoutManager(llm1);
        recyclerView_address_allowed.setAdapter(disallow_all_addresses_adapter);
        recyclerView_address_rejected.setAdapter(allow_all_addresses_adapter);
        allow_all_addrs_radio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(disallow_all_addrs_radio.isChecked()){
                    disallow_all_addrs_radio.setChecked(false);
                    disallow_all_addrs_container.getChildAt(1).setVisibility(View.GONE);
                }
                config_page.findViewById(R.id.add_allowed).setVisibility(View.GONE);
                config_page.findViewById(R.id.add_rejected).setVisibility(View.VISIBLE);
                allow_all_addrs_container.getChildAt(1).setVisibility(View.VISIBLE);
                app_data_and_preferences.getInstance().address_filters.filter_type=app_data_and_preferences.address_filters_struct.accept_all_except;
                app_data_and_preferences.getInstance().update_address_filter_details(app_data_and_preferences.update_part_address_filter_type);
            }
        });
        disallow_all_addrs_radio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(allow_all_addrs_radio.isChecked()){
                    allow_all_addrs_radio.setChecked(false);
                    allow_all_addrs_container.getChildAt(1).setVisibility(View.GONE);
                }
                config_page.findViewById(R.id.add_allowed).setVisibility(View.VISIBLE);
                config_page.findViewById(R.id.add_rejected).setVisibility(View.GONE);
                disallow_all_addrs_container.getChildAt(1).setVisibility(View.VISIBLE);
                app_data_and_preferences.getInstance().address_filters.filter_type=app_data_and_preferences.address_filters_struct.reject_all_except;
                app_data_and_preferences.getInstance().update_address_filter_details(app_data_and_preferences.update_part_address_filter_type);
            }
        });
        if(app_data_and_preferences.getInstance().address_filters.filter_type==app_data_and_preferences.address_filters_struct.accept_all_except){
            allow_all_addrs_radio.setChecked(true);
            if(disallow_all_addrs_radio.isChecked()){
                disallow_all_addrs_radio.setChecked(false);
                disallow_all_addrs_container.getChildAt(1).setVisibility(View.GONE);
            }
            config_page.findViewById(R.id.add_allowed).setVisibility(View.GONE);
            config_page.findViewById(R.id.add_rejected).setVisibility(View.VISIBLE);
            allow_all_addrs_container.getChildAt(1).setVisibility(View.VISIBLE);
        }
        if(app_data_and_preferences.getInstance().address_filters.filter_type==app_data_and_preferences.address_filters_struct.reject_all_except){
            disallow_all_addrs_radio.setChecked(true);
            if(allow_all_addrs_radio.isChecked()){
                allow_all_addrs_radio.setChecked(false);
                allow_all_addrs_container.getChildAt(1).setVisibility(View.GONE);
            }
            config_page.findViewById(R.id.add_allowed).setVisibility(View.VISIBLE);
            config_page.findViewById(R.id.add_rejected).setVisibility(View.GONE);
            disallow_all_addrs_container.getChildAt(1).setVisibility(View.VISIBLE);
        }
        config_page.findViewById(R.id.add_allowed).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                show_filter_ip_input_dialog();
            }
        });
        config_page.findViewById(R.id.add_rejected).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                show_filter_ip_input_dialog();
            }
        });
        address_filter_dialog.setContentView(R.layout.config_ip_input);
        address_filter_dialog.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT);
        address_filter_dialog.findViewById(R.id.ip_to_container).setVisibility(View.GONE);
        address_filter_dialog.findViewById(R.id.port_to_container).setVisibility(View.GONE);
        ((RadioGroup)address_filter_dialog.findViewById(R.id.radio_group_ip)).check(R.id.single_ip);
        ((RadioGroup)address_filter_dialog.findViewById(R.id.radio_group_port)).check(R.id.single_port);
        ((RadioGroup)address_filter_dialog.findViewById(R.id.radio_group_ip)).setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                if(i==R.id.single_ip){
                    address_filter_dialog.findViewById(R.id.ip_to_container).setVisibility(View.GONE);
                    ((TextView)((LinearLayoutCompat)address_filter_dialog.findViewById(R.id.ip_from_container)).getChildAt(0)).setText("IP ");
                }
                if(i==R.id.range_ip){
                    address_filter_dialog.findViewById(R.id.ip_to_container).setVisibility(View.VISIBLE);
                    ((TextView)((LinearLayoutCompat)address_filter_dialog.findViewById(R.id.ip_from_container)).getChildAt(0)).setText("from ");
                }
            }
        });
        ((RadioGroup)address_filter_dialog.findViewById(R.id.radio_group_port)).setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                if(i==R.id.single_port){
                    address_filter_dialog.findViewById(R.id.port_to_container).setVisibility(View.GONE);
                    ((TextView)((LinearLayoutCompat)address_filter_dialog.findViewById(R.id.port_from_container)).getChildAt(0)).setText("port ");
                }
                if(i==R.id.range_port){
                    address_filter_dialog.findViewById(R.id.port_to_container).setVisibility(View.VISIBLE);
                    ((TextView)((LinearLayoutCompat)address_filter_dialog.findViewById(R.id.port_from_container)).getChildAt(0)).setText("from ");
                }
            }
        });
        ((EditText)address_filter_dialog.findViewById(R.id.port_from)).setInputType(InputType.TYPE_CLASS_NUMBER);
        ((EditText)address_filter_dialog.findViewById(R.id.port_to)).setInputType(InputType.TYPE_CLASS_NUMBER);
        ((RadioGroup)address_filter_dialog.findViewById(R.id.protocol_group_radio)).check(R.id.protocol_tcp_and_udb);
        address_filter_dialog.findViewById(R.id.app_config_input_done_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int i=((RadioGroup)address_filter_dialog.findViewById(R.id.radio_group_ip)).getCheckedRadioButtonId();
                if(i==R.id.single_ip){
                    address_filter_entry.is_address_range=false;
                    String s=((EditText)address_filter_dialog.findViewById(R.id.ip_from)).getText().toString();
                    int error=utils.validate_input(utils.validation_mode_ip_address,s);
                    if(error!=utils.valid){
                        if(error==utils.validation_error_empty_string){
                            Toast.makeText(main.this,"ip field is empty",Toast.LENGTH_SHORT).show();
                        }
                        if(error==utils.validation_error_invalid_ip_value){
                            Toast.makeText(main.this,"invalid ip value",Toast.LENGTH_SHORT).show();
                        }
                        return;
                    }
                    address_filter_entry.address_min= com.paranoia.zharftor.utils.ip_string_to_long(s);
                }
                if(i==R.id.range_ip){
                    address_filter_entry.is_address_range=true;
                    String s=((EditText)address_filter_dialog.findViewById(R.id.ip_from)).getText().toString();
                    int error=utils.validate_input(utils.validation_mode_ip_address,s);
                    if(error!=utils.valid){
                        if(error==utils.validation_error_empty_string){
                            Toast.makeText(main.this,"ip field is empty",Toast.LENGTH_SHORT).show();
                        }
                        if(error==utils.validation_error_invalid_ip_value){
                            Toast.makeText(main.this,"invalid ip value",Toast.LENGTH_SHORT).show();
                        }
                        return;
                    }
                    address_filter_entry.address_min= com.paranoia.zharftor.utils.ip_string_to_long(s);
                    s=((EditText)address_filter_dialog.findViewById(R.id.ip_to)).getText().toString();
                    error=utils.validate_input(utils.validation_mode_ip_address,s);
                    if(error!=utils.valid){
                        if(error==utils.validation_error_empty_string){
                            Toast.makeText(main.this,"ip field is empty",Toast.LENGTH_SHORT).show();
                        }
                        if(error==utils.validation_error_invalid_ip_value){
                            Toast.makeText(main.this,"invalid ip value",Toast.LENGTH_SHORT).show();
                        }
                        return;
                    }
                    address_filter_entry.address_max= com.paranoia.zharftor.utils.ip_string_to_long(s);
                    if(address_filter_entry.address_min>address_filter_entry.address_min){
                        Toast.makeText(main.this,"invalid ip range",Toast.LENGTH_SHORT).show();
                        return;
                    }
                }

                i=((RadioGroup)address_filter_dialog.findViewById(R.id.radio_group_port)).getCheckedRadioButtonId();
                if(i==R.id.single_port){
                    address_filter_entry.is_port_range=false;
                    String s=((EditText)address_filter_dialog.findViewById(R.id.port_from)).getText().toString();
                    int error=utils.validate_input(utils.validation_mode_port,s);
                    if(error!=utils.valid){
                        if(error==utils.validation_error_empty_string){
                            Toast.makeText(main.this,"port field is empty",Toast.LENGTH_SHORT).show();
                        }
                        if(error==utils.validation_error_port_out_of_range){
                            Toast.makeText(main.this,"invalid port value",Toast.LENGTH_SHORT).show();
                        }
                        return;
                    }
                    address_filter_entry.port_min=Integer.valueOf(s);
                }
                if(i==R.id.range_port){
                    address_filter_entry.is_port_range=true;
                    String s=((EditText)address_filter_dialog.findViewById(R.id.port_from)).getText().toString();
                    int error=utils.validate_input(utils.validation_mode_port,s);
                    if(error!=utils.valid){
                        if(error==utils.validation_error_empty_string){
                            Toast.makeText(main.this,"port field is empty",Toast.LENGTH_SHORT).show();
                        }
                        if(error==utils.validation_error_port_out_of_range){
                            Toast.makeText(main.this,"invalid port value",Toast.LENGTH_SHORT).show();
                        }
                        return;
                    }
                    address_filter_entry.port_min=Integer.valueOf(s);
                    s=((EditText)address_filter_dialog.findViewById(R.id.port_to)).getText().toString();
                    error=utils.validate_input(utils.validation_mode_port,s);
                    if(error!=utils.valid){
                        if(error==utils.validation_error_empty_string){
                            Toast.makeText(main.this,"port field is empty",Toast.LENGTH_SHORT).show();
                        }
                        if(error==utils.validation_error_port_out_of_range){
                            Toast.makeText(main.this,"invalid port value",Toast.LENGTH_SHORT).show();
                        }
                        return;
                    }
                    address_filter_entry.port_max=Integer.valueOf(s);
                    if(address_filter_entry.port_min>address_filter_entry.port_max){
                        Toast.makeText(main.this,"invalid port range",Toast.LENGTH_SHORT).show();
                        return;
                    }
                }

                i=((RadioGroup)address_filter_dialog.findViewById(R.id.protocol_group_radio)).getCheckedRadioButtonId();
                if(i==R.id.protocol_tcp){
                    address_filter_entry.protocol=protocols_namespace.IP.TCP_PROTOCOL_NUMBER;
                }
                if(i==R.id.protocol_udp){
                    address_filter_entry.protocol=protocols_namespace.IP.UDP_PROTOCOL_NUMBER;
                }
                if(i==R.id.protocol_tcp_and_udb){
                    address_filter_entry.protocol=protocols_namespace.IP.CUSTOM_TCP_UDP_COMB_PROTOCOL_NUMBER;
                }
                //all good to add
                if(app_data_and_preferences.getInstance().address_filters.filter_type==app_data_and_preferences.address_filters_struct.accept_all_except){
                    app_data_and_preferences.getInstance().address_filters.ip_addresses_rejected.add(address_filter_entry);
                    app_data_and_preferences.getInstance().update_address_filter_details(app_data_and_preferences.update_part_addresses_rejected);
                    allow_all_addresses_adapter.notifyDataSetChanged();
                }
                if(app_data_and_preferences.getInstance().address_filters.filter_type==app_data_and_preferences.address_filters_struct.reject_all_except){
                    app_data_and_preferences.getInstance().address_filters.ip_addresses_accepted.add(address_filter_entry);
                    app_data_and_preferences.getInstance().update_address_filter_details(app_data_and_preferences.update_part_addresses_accepted);
                    disallow_all_addresses_adapter.notifyDataSetChanged();
                }
                address_filter_entry=new app_data_and_preferences.filter_address_entry();
                address_filter_dialog.dismiss();
                set_address_input_dialog_to_first_time();
            }
        });
        //apps filters
        LinearLayoutCompat allow_all_apps_container =(LinearLayoutCompat) config_page.findViewById(R.id.filter_tunnel_all_apps_except);
        RadioButton allow_all_apps_radio =(RadioButton) config_page.findViewById(R.id.filter_radio_tunnel_all_apps_except);
        LinearLayoutCompat disallow_all_apps_container =(LinearLayoutCompat) config_page.findViewById(R.id.filter_untunnel_all_apps_except);
        RadioButton disallow_all_apps_radio =(RadioButton) config_page.findViewById(R.id.filter_radio_untunnel_all_apps_except);
        allow_all_apps_container.getChildAt(1).setVisibility(View.GONE);
        disallow_all_apps_container.getChildAt(1).setVisibility(View.GONE);
        RecyclerView recyclerView_apps_untunneled= allow_all_apps_container.findViewById(R.id.untunneled_apps_list_recycler_view),
                recyclerView_apps_tunneled= disallow_all_apps_container.findViewById(R.id.tunneled_apps_list_recycler_view);
        LinearLayoutManager llm2=new LinearLayoutManager(this),llm3=new LinearLayoutManager(this);
        recyclerView_apps_untunneled.setLayoutManager(llm2);
        recyclerView_apps_tunneled.setLayoutManager(llm3);
        accepted_apps_adapter=new recyclers_adapters.apps_list_recycler(recyclers_adapters.apps_list_recycler.tunnel_none_except,this);
        rejected_apps_adapter=new recyclers_adapters.apps_list_recycler(recyclers_adapters.apps_list_recycler.tunnel_all_except,this);
        recyclerView_apps_untunneled.setAdapter(rejected_apps_adapter);
        recyclerView_apps_tunneled.setAdapter(accepted_apps_adapter);
        allow_all_apps_radio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(disallow_all_apps_radio.isChecked()){
                    disallow_all_apps_radio.setChecked(false);
                    disallow_all_apps_container.getChildAt(1).setVisibility(View.GONE);
                }
                config_page.findViewById(R.id.add_tunneled_apps).setVisibility(View.GONE);
                config_page.findViewById(R.id.add_untunneled_app).setVisibility(View.VISIBLE);
                allow_all_apps_container.getChildAt(1).setVisibility(View.VISIBLE);
                app_data_and_preferences.getInstance().app_filters.filter_type=app_data_and_preferences.apps_filters_struct.tunnel_all_except;
                app_data_and_preferences.getInstance().update_app_filter_details(app_data_and_preferences.update_part_app_filter_type);
            }
        });
        disallow_all_apps_radio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(allow_all_apps_radio.isChecked()){
                    allow_all_apps_radio.setChecked(false);
                    allow_all_apps_container.getChildAt(1).setVisibility(View.GONE);
                }
                config_page.findViewById(R.id.add_tunneled_apps).setVisibility(View.VISIBLE);
                config_page.findViewById(R.id.add_untunneled_app).setVisibility(View.GONE);
                disallow_all_apps_container.getChildAt(1).setVisibility(View.VISIBLE);
                app_data_and_preferences.getInstance().app_filters.filter_type=app_data_and_preferences.apps_filters_struct.tunnel_none_except;
                app_data_and_preferences.getInstance().update_app_filter_details(app_data_and_preferences.update_part_app_filter_type);
            }
        });
        if(app_data_and_preferences.getInstance().app_filters.filter_type==app_data_and_preferences.apps_filters_struct.tunnel_all_except){
            allow_all_apps_radio.setChecked(true);
            if(disallow_all_apps_radio.isChecked()){
                disallow_all_apps_radio.setChecked(false);
                disallow_all_apps_container.getChildAt(1).setVisibility(View.GONE);
            }
            config_page.findViewById(R.id.add_tunneled_apps).setVisibility(View.GONE);
            config_page.findViewById(R.id.add_untunneled_app).setVisibility(View.VISIBLE);
            allow_all_apps_container.getChildAt(1).setVisibility(View.VISIBLE);
        }
        if(app_data_and_preferences.getInstance().app_filters.filter_type==app_data_and_preferences.apps_filters_struct.tunnel_none_except){
            disallow_all_apps_radio.setChecked(true);
            if(allow_all_apps_radio.isChecked()){
                allow_all_apps_radio.setChecked(false);
                allow_all_apps_container.getChildAt(1).setVisibility(View.GONE);
            }
            config_page.findViewById(R.id.add_tunneled_apps).setVisibility(View.VISIBLE);
            config_page.findViewById(R.id.add_untunneled_app).setVisibility(View.GONE);
            disallow_all_apps_container.getChildAt(1).setVisibility(View.VISIBLE);
        }
        config_page.findViewById(R.id.add_tunneled_apps).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                show_filter_app_input_dialog();
            }
        });
        config_page.findViewById(R.id.add_untunneled_app).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                show_filter_app_input_dialog();
            }
        });
        app_filter_dialog.setContentView(R.layout.config_app_input);
        LinearLayoutManager linearLayoutManager_apps_input=new LinearLayoutManager(this);
        apps_chooser_adapter=new recyclers_adapters.app_chooser_recycler(this);
        ((RecyclerView)app_filter_dialog.findViewById(R.id.app_chooser_recyclerview)).setLayoutManager(linearLayoutManager_apps_input);
        ((RecyclerView)app_filter_dialog.findViewById(R.id.app_chooser_recyclerview)).setAdapter(apps_chooser_adapter);
        app_filter_dialog.findViewById(R.id.app_config_input_done_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(app_data_and_preferences.getInstance().app_filters.filter_type==app_data_and_preferences.apps_filters_struct.tunnel_all_except){
                    for(recyclers_adapters.app_chooser_recycler.package_item item: apps_chooser_adapter.list){
                        if(item.is_selected){
                            app_data_and_preferences.filter_app_entry entry=new app_data_and_preferences.filter_app_entry();
                            entry.package_name=item.applicationInfo.packageName;
                            if(!app_data_and_preferences.getInstance().app_filters.apps_rejected.contains(entry)){
                                entry.icon=item.icon;
                                entry.app_name=item.app_name;
                                app_data_and_preferences.getInstance().app_filters.apps_rejected.add(entry);
                            }
                            app_data_and_preferences.getInstance().update_app_filter_details(app_data_and_preferences.update_part_apps_rejected);
                            rejected_apps_adapter.notifyDataSetChanged();
                        }
                    }
                }
                if(app_data_and_preferences.getInstance().app_filters.filter_type==app_data_and_preferences.apps_filters_struct.tunnel_none_except){
                    for(recyclers_adapters.app_chooser_recycler.package_item item: apps_chooser_adapter.list){
                        if(item.is_selected){
                            app_data_and_preferences.filter_app_entry entry=new app_data_and_preferences.filter_app_entry();
                            entry.package_name=item.applicationInfo.packageName;
                            if(!app_data_and_preferences.getInstance().app_filters.apps_accepted.contains(entry)){
                                entry.icon=item.icon;
                                entry.app_name=item.app_name;
                                app_data_and_preferences.getInstance().app_filters.apps_accepted.add(entry);
                            }
                            app_data_and_preferences.getInstance().update_app_filter_details(app_data_and_preferences.update_part_apps_accepted);
                            accepted_apps_adapter.notifyDataSetChanged();
                        }
                    }
                }
                set_apps_input_dialog_to_first_time();
                app_filter_dialog.dismiss();
            }
        });
    }
    public void stop_vpn_connection(){
            connection_btn.callOnClick();
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==RESULT_OK){
            Toast.makeText(this,"ok",Toast.LENGTH_LONG).show();
            com.paranoia.zharftor.vpn_service.vpn_permission_granted=true;
            connection_btn.callOnClick();
        }
    }
    private void hide_all_views(){
        int i=0;
        while(i<parent_layout.getChildCount()){
            parent_layout.getChildAt(i).setVisibility(View.GONE);
            i++;
        }
    }
    private AnimatedVectorDrawableCompat con_anim,discon_anim,ent_anim;
    private void animate_connect_icon(boolean connected){
        if(main.this.getLifecycle().getCurrentState().isAtLeast(Lifecycle.State.STARTED)) {
            if(im!=null&& con_anim!=null&& discon_anim!=null) {
                if (connected) {
                    if(!im.getDrawable().equals(con_anim)) {
                        im.setImageDrawable(con_anim);
                        con_anim.start();
                    }
                } else {
                    if(!im.getDrawable().equals(discon_anim)) {
                        im.setImageDrawable(discon_anim);
                        discon_anim.start();
                    }
                }
            }
        }
    }
    private void animate_entrance(boolean animate){
        if(main.this.getLifecycle().getCurrentState().isAtLeast(Lifecycle.State.STARTED)) {
            if(preload_page!=null&& ent_anim!=null) {
                if (animate) {
                    ((ImageView)preload_page.findViewById(R.id.entrance_image)).setImageDrawable(ent_anim);
                    ent_anim.registerAnimationCallback(new Animatable2Compat.AnimationCallback() {
                        @Override
                        public void onAnimationEnd(Drawable drawable) {
                            super.onAnimationEnd(drawable);
                            if(app_ui_state==UI_STATE_PRELOAD){
                                ent_anim.start();
                            }
                        }
                    });
                    ent_anim.start();
                } else {
                    ent_anim.stop();
                }
            }
        }
    }
    public void set_ads_loading_state(boolean loading_ads){
        if(app_data_and_preferences.getInstance().is_first_time())
            return;
        if(loading_ads) {
            app_ui_state =UI_STATE_PRELOAD;
            set_ui_state(app_ui_state);
            animate_entrance(true);
        }
        else {
            if(app_ui_state==UI_STATE_PRELOAD) {
                app_ui_state = UI_STATE_MAIN;
                set_ui_state(app_ui_state);
//            main_page.findViewById(R.id.ads_progress_bar_container).setVisibility(View.GONE);
                animate_entrance(false);
            }
        }
    }
    public void set_ui_state(short state){
        hide_all_views();
        if(state==UI_STATE_FIRST_USE){
            terms_and_conditions_page.setVisibility(View.VISIBLE);
            //show an agree button
        }
        if(state==UI_STATE_PRELOAD){
            preload_page.setVisibility(View.VISIBLE);
            //show an agree button
        }
        if(state==UI_STATE_MAIN){
            main_page.setVisibility(View.VISIBLE);
            if(vpn_connection_state ==VPN_STATE_CONNECTED){
                connection_btn.setText("Connected");
//                findViewById(R.id.connection).setBackgroundResource(R.color.connected);
                set_App_connection_status_non_ui_thread(CONNECTION_STATUS_READY_OR_CONNECTED);
                animate_connect_icon(true);
//                time_container.setVisibility(View.VISIBLE);
//                update_time();
            }
            if(vpn_connection_state ==VPN_STATE_CONNECTING){
                connection_btn.setText("Connecting...");
//                findViewById(R.id.connection).setBackgroundResource(R.color.connecting2);
                animate_connect_icon(true);
//                time_container.setVisibility(View.GONE);
            }
            if(vpn_connection_state ==VPN_STATE_UNCONNETED){
                connection_btn.setText("Connect");
//                findViewById(R.id.connection).setBackgroundResource(R.color.connecting1);
                animate_connect_icon(false);
                if(cent_server_interface.is_effective_response) {
//                    findViewById(R.id.connection).setBackgroundResource(R.color.preconnect);
                    set_App_connection_status_non_ui_thread(CONNECTION_STATUS_GATHERING_SERVER_INFO);
                }
//                time_container.setVisibility(View.GONE);
            }
        }
        if(state==UI_STATE_TERM_AND_CONDITIONS){
            terms_and_conditions_page.setVisibility(View.VISIBLE);
        }
        if(state==UI_STATE_PRIVACY_POLICY){
            privacy_policy_page.setVisibility(View.VISIBLE);
        }
        if(state==UI_STATE_CONFIG){
            config_page.setVisibility(View.VISIBLE);
            allow_all_addresses_adapter.notifyDataSetChanged();
            disallow_all_addresses_adapter.notifyDataSetChanged();
            apps_chooser_adapter.notifyDataSetChanged();
            rejected_apps_adapter.notifyDataSetChanged();
            accepted_apps_adapter.notifyDataSetChanged();
        }
        if(state==UI_STATE_SERVER_SELECTION){
            servers_list_page.setVisibility(View.VISIBLE);
        }
    }
    public void show_message_non_ui_threads(String s){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if(main.this.getLifecycle().getCurrentState().isAtLeast(Lifecycle.State.RESUMED)){
                    Toast.makeText(main.this, s, Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    public void set_App_state_non_ui_thread(short state){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if(main.this.getLifecycle().getCurrentState().isAtLeast(Lifecycle.State.RESUMED)){
                    vpn_connection_state =state;
                    if(app_ui_state ==UI_STATE_MAIN){
                        set_ui_state(app_ui_state);
                    }
                }
            }
        });
    }

    public void set_main_page_flag_ui_thread(){
        country_codes.get_city_and_country_by_code(0);
        current_country_icon.setImageBitmap(country_codes.flags.get(
                        country_codes.get_city_and_country_by_code(
                                vpn_service.selected_server_details.extra
                        ).split(" ")[0].toLowerCase(Locale.ROOT)
                )
        );
        current_country_icon.setVisibility(View.VISIBLE);
    }
    public void set_App_connection_status_non_ui_thread(short status){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if(main.this.getLifecycle().getCurrentState().isAtLeast(Lifecycle.State.STARTED)){
//                if(3==2+1){
                    if(status==CONNECTION_STATUS_READY_OR_CONNECTED){
                        if(app_ui_state ==VPN_STATE_UNCONNETED){
//                            findViewById(R.id.connection).setBackgroundResource(R.color.connecting1);
                        }

                        country_codes.get_city_and_country_by_code(0);
                        current_country_icon.setImageBitmap(country_codes.flags.get(
                                country_codes.get_city_and_country_by_code(
                                        vpn_service.selected_server_details.extra
                                ).split(" ")[0].toLowerCase(Locale.ROOT)
                                )
                        );
                        current_country_icon.setVisibility(View.VISIBLE);
                        findViewById(R.id.connection_status_container).setVisibility(View.GONE);
                    }
                    if(status==CONNECTION_STATUS_GATHERING_SERVER_INFO){
                        current_country_icon.setVisibility(View.GONE);
                        findViewById(R.id.connection_status_container).setVisibility(View.VISIBLE);
                        ((TextView)findViewById(R.id.app_connection_state)).setText("gathering server info");
                    }
                    if(status==CONNECTION_STATUS_EXCHANGING_KEYS){
                        country_codes.get_city_and_country_by_code(0);
                        current_country_icon.setImageBitmap(country_codes.flags.get(
                                        country_codes.get_city_and_country_by_code(
                                                vpn_service.selected_server_details.extra
                                        ).split(" ")[0].toLowerCase(Locale.ROOT)
                                )
                        );
                        current_country_icon.setVisibility(View.VISIBLE);
//                        findViewById(R.id.connection).setBackgroundResource(R.color.connecting3);
                        findViewById(R.id.connection_status_container).setVisibility(View.VISIBLE);
                        ((TextView)findViewById(R.id.app_connection_state)).setText("exchaning keys");
                    }
                }
            }
        });
    }
    @Override
    protected void onResume() {
        super.onResume();
        evaluate_state();
        if(vpn_connection_state ==VPN_STATE_UNCONNETED)
            app_data_and_preferences.getInstance().load_essentials();
        else
            app_data_and_preferences.getInstance().load_essentials_unchecked();
        vpn_service.is_main_accessible=true;
        set_ui_state(app_ui_state);
        init_ad_network();
        if(app_data_and_preferences.getInstance().should_show_ad()
                && (app_ui_state!=UI_STATE_FIRST_USE&&
                app_ui_state!=UI_STATE_PRIVACY_POLICY&&
                app_ui_state!=UI_STATE_TERM_AND_CONDITIONS)){
            if(!ads_are_laoded)
                set_ads_loading_state(true);
            else {
                set_ads_loading_state(false);
            }
        } else {
            set_ads_loading_state(false);
        }
//        load_ad_rewarded();
//        if(time_left_updater==null){
//            time_left_updater=new CountDownTimer(24*60*60*1000,60*1000) {
//                @Override
//                public void onTick(long l) {
//                    update_time();
//                }
//
//                @Override
//                public void onFinish() {
//                }
//            }.start();
//        }else {
//            time_left_updater.start();
//        }
    }
    @Override
    protected void onPause() {
        super.onPause();
        vpn_service.is_main_accessible=false;
//        if (time_left_updater!=null){
//            time_left_updater.cancel();
//        }
    }
    @Override
    public void onBackPressed() {
        if(app_data_and_preferences.getInstance().is_first_time()) {
            super.onBackPressed();
            return;
        }
        if(app_ui_state ==UI_STATE_MAIN||app_ui_state==UI_STATE_PRELOAD)
            super.onBackPressed();
        else {
            app_ui_state =UI_STATE_MAIN;
            set_ui_state(app_ui_state);
        }
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        vpn_service.is_main_accessible=false;
//        if (time_left_updater!=null){
//            time_left_updater.cancel();
//        }
//        i.putExtra("disconnect",true);
//        startService(i);
    }
    public void show_filter_ip_input_dialog(){
        address_filter_dialog.show();
    }
    private void set_address_input_dialog_to_first_time(){
        ((RadioGroup)address_filter_dialog.findViewById(R.id.protocol_group_radio)).check(R.id.protocol_tcp_and_udb);
        ((RadioGroup)address_filter_dialog.findViewById(R.id.radio_group_ip)).check(R.id.single_ip);
        ((RadioGroup)address_filter_dialog.findViewById(R.id.radio_group_port)).check(R.id.single_port);
        ((EditText)address_filter_dialog.findViewById(R.id.ip_from)).setText("");
        ((EditText)address_filter_dialog.findViewById(R.id.ip_to)).setText("");
        ((EditText)address_filter_dialog.findViewById(R.id.port_from)).setText("");
        ((EditText)address_filter_dialog.findViewById(R.id.port_to)).setText("");
    }
    public void show_filter_app_input_dialog(){
        app_filter_dialog.show();
    }
    private void set_apps_input_dialog_to_first_time(){
        Iterator<recyclers_adapters.app_chooser_recycler.package_item> e = apps_chooser_adapter.list.iterator();
        while(e.hasNext()){
            e.next().is_selected=false;
        }
        apps_chooser_adapter.notifyDataSetChanged();
    }
//    private void update_time(){
//        if(vpn_connection_state!=VPN_STATE_CONNECTED)return;
//        long time_left_milis=vpn_service.get_active_connection_time_left_milis()/1000;
//        String hours_left=String.valueOf(time_left_milis/60/60);
//        String minutes_left=String.valueOf((time_left_milis/60)%60);
//        time_holder_textview.setText(hours_left+":"+minutes_left);
//    }
//    public void set_addtime_visibility(int Visibility){
//        add_time_button.setVisibility(Visibility);
//    }
}
