package com.paranoia.zharftor;

import android.util.Base64;
import android.util.Log;

import com.paranoia.zharftor.poshan.key_manager;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.channels.DatagramChannel;
import java.nio.channels.NotYetConnectedException;

public class cent_server_interface {

    public static byte[] server_ip = {(byte) 192, (byte) 168, 1, 101};
    public static String[] cent_server_domains = {"cent0.zharftor.com"};
    byte counter=0;
    public static int server_informer_port = 779;
    private DatagramChannel dgram_channel;
    public static boolean is_effective_response =true;
    public cent_server_interface(){
        make_connection();
    }
    private void make_connection(){
        decoder_downstreamer.interrupt();
        if(counter>=cent_server_domains.length)
            counter=0;
        try {
            dgram_channel= DatagramChannel.open();
            dgram_channel.connect(
                    new InetSocketAddress(InetAddress.getByName(cent_server_domains[counter]),server_informer_port)
//                    new InetSocketAddress(InetAddress.getByName("192.168.1.11"),777)
            );
            dgram_channel.configureBlocking(true);
            decoder_downstreamer.start(decoder_downstreamer_runnable);
        } catch (IOException e) {
//            e.printStackTrace();
        }
        counter++;
    }
    private utils.pointed_byteArray buffer_out=new utils.pointed_byteArray(0x1000);
    public void request_dynamic_key_and_list(byte[] modulus_sig) {
        try {
            buffer_out.buffer[0] = 0;//version
            buffer_out.buffer[1] = COMMAND_GET_SIGNED_SERVERS_LIST;
            System.arraycopy(modulus_sig, 0, buffer_out.buffer, 2, 4);
            buffer_out.end = 6;
            buffer_out.byteBuffer.position(0);
            buffer_out.byteBuffer.limit(buffer_out.end);
//            Log.d("debug_data",new String( Base64.encode(buffer_out.buffer,buffer_out.offset,buffer_out.end-buffer_out.offset,Base64.DEFAULT)));
            dgram_channel.write(buffer_out.byteBuffer);
        }catch (IOException e ){
//            e.printStackTrace();
            make_connection();
        } catch (NotYetConnectedException e){
            try {
                Thread.sleep(1500);
            } catch (InterruptedException interruptedException) {
//                interruptedException.printStackTrace();
            }
            make_connection();
        }
    }
    public void check_for_update(byte[] list_sig) {
        try {
            buffer_out.buffer[0] = 0;//version
            buffer_out.buffer[1] = COMMAND_CHECK_WITH_LATEST_SIGNATURE;
            System.arraycopy(list_sig, 0, buffer_out.buffer, 2, key_manager.server_dynamic_RSA_byte_size);
            buffer_out.end = key_manager.server_dynamic_RSA_byte_size + 2;
            buffer_out.byteBuffer.position(0);
            buffer_out.byteBuffer.limit(buffer_out.end);
//            Log.d("debug_data",new String( Base64.encode(buffer_out.buffer,buffer_out.offset,buffer_out.end-buffer_out.offset,Base64.DEFAULT)));
            dgram_channel.write(buffer_out.byteBuffer);
        }catch (IOException e){
//            e.printStackTrace();
            make_connection();
        }catch (NotYetConnectedException e){
            try {
                Thread.sleep(1500);
            } catch (InterruptedException interruptedException) {
//                interruptedException.printStackTrace();
            }
            make_connection();
        }
    }
    public static final byte RESPONSE_GENERAL_ALL_CORRECT=0,
            RESPONSE_GENERAL_FALSE=1,
            RESPONSE_UPDATE_PUBLIC_KEY=2,
            RESPONSE_UPDATE_LIST=3;
    public static final byte version_0=0;
    public static final byte COMMAND_GET_SIGNED_SERVERS_LIST=0,
            COMMAND_CHECK_WITH_LATEST_SIGNATURE=1;
    private one_task_one_thread decoder_downstreamer=new one_task_one_thread();
    private Runnable decoder_downstreamer_runnable=new Runnable() {
        @Override
        public void run() {
            utils.pointed_byteArray pb=new utils.pointed_byteArray(0xffff);
            while(!Thread.currentThread().isInterrupted()&&is_effective_response){
                try {
                    pb.offset = 0;
                    pb.end = pb.buffer.length;
                    pb.byteBuffer.position(0);
                    pb.byteBuffer.limit(pb.end);
                    dgram_channel.read(pb.byteBuffer);
                    pb.end=pb.byteBuffer.position();
//                    vpn_service.activity.show_message_non_ui_threads("recieved packet");
                    if(is_effective_response) {
                        if (pb.buffer[0] == version_0) {//version
                            if (pb.buffer[1] == RESPONSE_GENERAL_ALL_CORRECT) {
                                //list and central key are not updated; good to continue;
                                app_data_and_preferences.getInstance().on_essentials_are_loaded();
                            }
                            if (pb.buffer[1] == RESPONSE_GENERAL_FALSE) {
                                //either list or public key are updated
                                request_dynamic_key_and_list(
                                        app_data_and_preferences.getInstance().get_dynamic_key_modulus_sig()
                                );
                            }
                            if (pb.buffer[1] == RESPONSE_UPDATE_PUBLIC_KEY) {
                                //set key
                                app_data_and_preferences.getInstance().set_latest_dynamic_cent_cerver_public_key(pb);
                                request_dynamic_key_and_list(//get list
                                        app_data_and_preferences.getInstance().get_dynamic_key_modulus_sig()
                                );
                            }
                            if (pb.buffer[1] == RESPONSE_UPDATE_LIST) {
                                //set list
                                app_data_and_preferences.getInstance().set_servers(pb);
                                //validate
                                check_for_update(app_data_and_preferences.getInstance().get_servers_list_signature());
                            }
                        }
                    }
                } catch (Throwable e) {
//                    e.printStackTrace();
                    make_connection();
                }
            }
        }
    };
}
