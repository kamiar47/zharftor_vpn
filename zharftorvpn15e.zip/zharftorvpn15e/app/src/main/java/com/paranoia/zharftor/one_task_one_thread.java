package com.paranoia.zharftor;

public class one_task_one_thread {
    public Thread thread;
    public synchronized void start(Runnable runnable){
        if(thread!=null){
            if(thread.isAlive()){
                while(true) {
                    try {
//                    Log.d("thread_update","waiting for thread "+ thread.getId());
                        thread.join(500);
                    } catch (InterruptedException e) {
//                    e.printStackTrace();
                        thread.interrupt();
                    }
                }
            }
        }
//        Log.d("thread_update","starting new thread ");
        thread=new Thread(runnable);
        thread.start();
    }
    public synchronized void start_kill_previous(Runnable runnable){
        if(thread!=null){
            while (thread.isAlive()){
                thread.interrupt();
            }
        }
//        Log.d("thread_update","starting new thread ");
        thread=new Thread(runnable);
        thread.start();
    }
    public void interrupt(){
        if(thread!=null)
            thread.interrupt();
    }
}