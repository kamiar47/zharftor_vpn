package com.paranoia.zharftor;

class response {
    public long id,version=0,size=0,response=-1;
    public final utils.cirular_buffer_reader_writer data=new utils.cirular_buffer_reader_writer(15000000);
    public byte state;
    public static final byte STATE_CONNECTED =0,STATE_REJECTED_OR_TIMEOUT=1;
    public final static  int RESPONSE_OK=0,
    RESPONSE_CLOSE_CONNECTION=1,
    RESPONSE_DATA_TCP=2,
    RESPONSE_DATA_UDP=3,
    RESPONSE_TCP_CONNECTION_STATE_INFORMATION=4,
    RESPONSE_SET_ADS_NETWORK=5,
    RESPONSE_RAW_PACKET =6,
    RESPONSE_SET_IP =7,
    VERSION_0=0,
    VERSION_1=1,
            VERSION_2=2;

    public short protocol;
}
