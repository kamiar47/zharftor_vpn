package com.paranoia.zharftor;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.util.Base64;

import com.paranoia.zharftor.poshan.key_manager;

import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import javax.crypto.BadPaddingException;

public class app_data_and_preferences {
    private static final String SERVER_DYNAMIC_KEY_PUB="SDKP",
            SERVERS_LIST="SL",
            SERVERS_LIST_SIG="SLS",
            CLIENT_ID="CI",SYMMETRIC_KEY="SK"
            ,FIRST_TIME="FT",
            ADDRESS_FILTER_REJECTED_LIST="afrl",
            ADDRESS_FILTER_ACCEPTED_LIST="afal", CURRENT_ADDRESS_FILTER_STATE ="cafs",APP_FILTER_REJECTED_LIST="appfrl",
            APP_FILTER_ACCEPTED_LIST="appfal", CURRENT_APPS_FILTER_STATE ="cappfs",
    PREFERED_AD_NETWORK_INDEX="pani",AD_LAST_TIMESTAMP="alt";
    private SharedPreferences preferences;
    private Thread data_loader;

    private static app_data_and_preferences instance;
    private byte[] servers_list_signature;
    private RSAPublicKey cent_server_dynamic_public_key;
    private cent_server_interface csi;
    private byte[] dynamic_key_modulus_sig;
    public List<server_details> servers = new ArrayList<>();
    public address_filters_struct address_filters =new address_filters_struct();
    public apps_filters_struct app_filters =new apps_filters_struct();
    private void dispatch_rejected_ip_addresses(String encoded_string)throws Throwable{
        int counter=0;
        utils.cirular_buffer_reader_writer bytes=new utils.cirular_buffer_reader_writer(0);
        bytes.set_buffer_and_wrap_for_reading(Base64.decode(encoded_string,Base64.DEFAULT));
        bytes.offset=0;
        while(bytes.get_available_data_length()>0){
            filter_address_entry entry=new filter_address_entry();
            byte header=(byte) bytes.read_next_number(1);
            if((header&1)==1){
                entry.is_address_range=true;
                entry.address_min=bytes.read_next_number(4);
                entry.address_max=bytes.read_next_number(4);
            }else {
                entry.is_address_range=false;
                entry.address_min=bytes.read_next_number(4);
            }
            if((header&2)==2){
                entry.is_port_range=true;
                entry.port_min=(int)bytes.read_next_number(2);
                entry.port_max=(int)bytes.read_next_number(2);
            }else {
                entry.is_port_range=false;
                entry.port_min=(int)bytes.read_next_number(2);
            }
            if((header&12)==12){
                entry.protocol= protocols_namespace.IP.CUSTOM_TCP_UDP_COMB_PROTOCOL_NUMBER;
            }else {
                if ((header & 4) == 4) {
                    entry.protocol = protocols_namespace.IP.UDP_PROTOCOL_NUMBER;
                }
                if ((header & 8) == 8) {
                    entry.protocol = protocols_namespace.IP.TCP_PROTOCOL_NUMBER;
                }
            }
            address_filters.ip_addresses_rejected.add(entry);
        }
    }
    private void  dispatch_accepted_ip_addresses(String encoded_string)throws Throwable{
        int counter=0;
        utils.cirular_buffer_reader_writer bytes=new utils.cirular_buffer_reader_writer(0);
        bytes.set_buffer_and_wrap_for_reading(Base64.decode(encoded_string,Base64.DEFAULT));
        bytes.offset=0;
        while(bytes.get_available_data_length()>0){
            filter_address_entry entry=new filter_address_entry();
            byte header=(byte) bytes.read_next_number(1);
            int i=header&1;
            i=header&12;
            if((header&1)==1){
                entry.is_address_range=true;
                entry.address_min=bytes.read_next_number(4);
                entry.address_max=bytes.read_next_number(4);
            }else {
                entry.is_address_range=false;
                entry.address_min=bytes.read_next_number(4);
            }
            if((header&2)==2){
                entry.is_port_range=true;
                entry.port_min=(int)bytes.read_next_number(2);
                entry.port_max=(int)bytes.read_next_number(2);
            }else {
                entry.is_port_range=false;
                entry.port_min=(int)bytes.read_next_number(2);
            }
            if((header&12)==12){
                entry.protocol= protocols_namespace.IP.CUSTOM_TCP_UDP_COMB_PROTOCOL_NUMBER;
            }else {
                if ((header & 4) == 4) {
                    entry.protocol = protocols_namespace.IP.UDP_PROTOCOL_NUMBER;
                }
                if ((header & 8) == 8) {
                    entry.protocol = protocols_namespace.IP.TCP_PROTOCOL_NUMBER;
                }
            }
            address_filters.ip_addresses_accepted.add(entry);
        }
    }
    private static int address_filter_complience_counter;
    public static class address_filters_struct {
        public boolean complies_with_policies(byte[] ip,int port,int protocol){
            if(filter_type==accept_all_except){
                if(ip_addresses_rejected.size()!=0){
                    address_filter_complience_counter=0;
                    while (address_filter_complience_counter<ip_addresses_rejected.size()){
                        if(ip_addresses_rejected.get(address_filter_complience_counter).is_subset(ip,port,protocol))
                            return false;
                        address_filter_complience_counter++;
                    }
                }
                return true;
            }else {
                if(ip_addresses_accepted.size()!=0){
                    address_filter_complience_counter=0;
                    while (address_filter_complience_counter<ip_addresses_accepted.size()){
                        if(ip_addresses_accepted.get(address_filter_complience_counter).is_subset(ip,port,protocol))
                            return true;
                        address_filter_complience_counter++;
                    }
                }
                return false;
            }
        }
        public boolean complies_with_policies(long ip,int port,int protocol){
            if(filter_type==accept_all_except){
                if(ip_addresses_rejected.size()!=0){
                    address_filter_complience_counter=0;
                    while (address_filter_complience_counter<ip_addresses_rejected.size()){
                        if(ip_addresses_rejected.get(address_filter_complience_counter).is_subset(ip,port,protocol))
                            return false;
                        address_filter_complience_counter++;
                    }
                }
                return true;
            }else {
                if(ip_addresses_accepted.size()!=0){
                    address_filter_complience_counter=0;
                    while (address_filter_complience_counter<ip_addresses_accepted.size()){
                        if(ip_addresses_accepted.get(address_filter_complience_counter).is_subset(ip,port,protocol))
                            return true;
                        address_filter_complience_counter++;
                    }
                }
                return false;
            }
        }
        public static final boolean accept_all_except=true,reject_all_except=false;
        public boolean filter_type=accept_all_except;
        public boolean is_updated=true;
        public List<filter_address_entry> ip_addresses_rejected=new ArrayList<>();
        public List<filter_address_entry> ip_addresses_accepted=new ArrayList<>();
        public String serialize_rejected_ip_addresses(){
            if(ip_addresses_rejected.size()==0)return "";
            utils.bytes_integrator bytes_integrator_final=new utils.bytes_integrator();
            utils.bytes_integrator bytes_integrator=new utils.bytes_integrator();
            int i=0;
            while(i<ip_addresses_rejected.size()){
                byte header[]=new byte[1];
                if(ip_addresses_rejected.get(i).is_address_range){
                    header[0]=(byte)( header[0]|1);
                    bytes_integrator.add_bytes(utils.long_to_bytes(ip_addresses_rejected.get(i).address_min,4));
                    bytes_integrator.add_bytes(utils.long_to_bytes(ip_addresses_rejected.get(i).address_max,4));
                }else {
                    bytes_integrator.add_bytes(utils.long_to_bytes(ip_addresses_rejected.get(i).address_min,4));
                }
                if(ip_addresses_rejected.get(i).is_port_range){
                    header[0]=(byte)( header[0]|2);
                    bytes_integrator.add_bytes(utils.long_to_bytes(ip_addresses_rejected.get(i).port_min,2));
                    bytes_integrator.add_bytes(utils.long_to_bytes(ip_addresses_rejected.get(i).port_max,2));
                }else {
                    bytes_integrator.add_bytes(utils.long_to_bytes(ip_addresses_rejected.get(i).port_min,2));
                }
                if(ip_addresses_rejected.get(i).protocol==protocols_namespace.IP.TCP_PROTOCOL_NUMBER){
                    header[0]=(byte) (header[0]|8);
                }
                if(ip_addresses_rejected.get(i).protocol==protocols_namespace.IP.UDP_PROTOCOL_NUMBER){
                    header[0]=(byte) (header[0]|4);
                }
                if(ip_addresses_rejected.get(i).protocol==protocols_namespace.IP.CUSTOM_TCP_UDP_COMB_PROTOCOL_NUMBER){
                    header[0]=(byte) (header[0]|12);
                }
                bytes_integrator_final.add_bytes(header);
                bytes_integrator_final.add_bytes(bytes_integrator.integrate_to_bytes());
                i++;
            }
            return Base64.encodeToString(bytes_integrator_final.integrate_to_bytes(),Base64.DEFAULT);
        }
        public String serialize_accepted_ip_addresses(){
            if(ip_addresses_accepted.size()==0)return "";
            utils.bytes_integrator bytes_integrator_final=new utils.bytes_integrator();
            utils.bytes_integrator bytes_integrator=new utils.bytes_integrator();
            int i=0;
            while(i<ip_addresses_accepted.size()){
                byte header[]=new byte[1];
                if(ip_addresses_accepted.get(i).is_address_range){
                    header[0]=(byte)( header[0]|1);
                    bytes_integrator.add_bytes(utils.long_to_bytes(ip_addresses_accepted.get(i).address_min,4));
                    bytes_integrator.add_bytes(utils.long_to_bytes(ip_addresses_accepted.get(i).address_max,4));
                }else {
                    bytes_integrator.add_bytes(utils.long_to_bytes(ip_addresses_accepted.get(i).address_min,4));
                }
                if(ip_addresses_accepted.get(i).is_port_range){
                    header[0]=(byte)( header[0]|2);
                    bytes_integrator.add_bytes(utils.long_to_bytes(ip_addresses_accepted.get(i).port_min,2));
                    bytes_integrator.add_bytes(utils.long_to_bytes(ip_addresses_accepted.get(i).port_max,2));
                }else {
                    bytes_integrator.add_bytes(utils.long_to_bytes(ip_addresses_accepted.get(i).port_min,2));
                }
                //protocol
                if(ip_addresses_accepted.get(i).protocol==protocols_namespace.IP.TCP_PROTOCOL_NUMBER){
                    header[0]=(byte) (header[0]|8);
                }
                if(ip_addresses_accepted.get(i).protocol==protocols_namespace.IP.UDP_PROTOCOL_NUMBER){
                    header[0]=(byte) (header[0]|4);
                }
                if(ip_addresses_accepted.get(i).protocol==protocols_namespace.IP.CUSTOM_TCP_UDP_COMB_PROTOCOL_NUMBER){
                    header[0]=(byte) (header[0]|12);
                }
                bytes_integrator_final.add_bytes(header);
                bytes_integrator_final.add_bytes(bytes_integrator.integrate_to_bytes());
                i++;
            }
            return Base64.encodeToString(bytes_integrator_final.integrate_to_bytes(),Base64.DEFAULT);
        }
    }
    public static class filter_address_entry{
        public boolean is_address_range,is_port_range;
        public long address_min,address_max;
        public int port_min,port_max;
        public byte protocol;
        public boolean is_subset(byte[] ip_address,int port,int protocol){
            if(this.protocol!=protocols_namespace.IP.CUSTOM_TCP_UDP_COMB_PROTOCOL_NUMBER){
                if(protocol!=this.protocol)return false;
            }
            if(is_address_range) {
                if(address_min<=utils.bytes_to_unsigned_long(ip_address)&&
                address_max>=utils.bytes_to_unsigned_long(ip_address));
                else return false;
            }else {
                if(address_min==utils.bytes_to_unsigned_long(ip_address));
                else return false;
            }
            if(is_port_range){
                if(port_min<=port&&port_max>=port)return true;
            }else {
                if(port==port_min)return true;
            }
            return false;
        }
        public boolean is_subset(long ip_address,int port,int protocol){
            if(this.protocol!=protocols_namespace.IP.CUSTOM_TCP_UDP_COMB_PROTOCOL_NUMBER){
                if(protocol!=this.protocol)return false;
            }
            if(is_address_range) {
                if(address_min<=ip_address&&
                        address_max>=ip_address);
                else return false;
            }else {
                if(address_min==ip_address);
                else return false;
            }
            if(is_port_range){
                if(port_min<=port&&port_max>=port)return true;
            }else {
                if(port==port_min)return true;
            }
            return false;
        }
    }
    private void dispatch_rejected_apps(String encoded_string){
        utils.cirular_buffer_reader_writer bytes=new utils.cirular_buffer_reader_writer(0);
        bytes.set_buffer_and_wrap_for_reading(Base64.decode(encoded_string,Base64.DEFAULT));
        bytes.offset=0;
        while(bytes.get_available_data_length()>0){
            filter_app_entry entry=new filter_app_entry();
            try {
                bytes.read_data((int)bytes.read_next_number(2));
            } catch (InterruptedException e) {
//                throw new RuntimeException(e);
            }
            entry.package_name=new String(bytes.buffer,
                    bytes.current_data_portions.offset,bytes.current_data_portions.end-bytes.current_data_portions.offset);
            bytes.mark_read();
            app_filters.apps_rejected.add(entry);
        }
    }
    private void dispatch_accepted_apps(String encoded_string){
        utils.cirular_buffer_reader_writer bytes=new utils.cirular_buffer_reader_writer(0);
        bytes.set_buffer_and_wrap_for_reading(Base64.decode(encoded_string,Base64.DEFAULT));
        bytes.offset=0;
        while(bytes.get_available_data_length()>0){
            filter_app_entry entry=new filter_app_entry();
            try {
                bytes.read_data((int)bytes.read_next_number(2));
            } catch (InterruptedException e) {
//                throw new RuntimeException(e);
            }
            entry.package_name=new String(bytes.buffer,
                    bytes.current_data_portions.offset,bytes.current_data_portions.end-bytes.current_data_portions.offset);
            bytes.mark_read();
            app_filters.apps_accepted.add(entry);
        }
    }
    public static class apps_filters_struct {
        public static final boolean tunnel_all_except =true, tunnel_none_except =false;
        public boolean filter_type= tunnel_all_except;
        public boolean is_updated=true;
        public List<filter_app_entry> apps_rejected=new ArrayList<>();
        public List<filter_app_entry> apps_accepted=new ArrayList<>();
        public String serialize_rejected_apps(){
            if(apps_rejected.size()==0)return "";
            utils.bytes_integrator bytes_integrator_final=new utils.bytes_integrator();
            for (filter_app_entry app:apps_rejected){
                bytes_integrator_final.add_bytes(utils.long_to_bytes(app.package_name.getBytes().length,2));
                bytes_integrator_final.add_bytes(app.package_name.getBytes());
            }
            return Base64.encodeToString(bytes_integrator_final.integrate_to_bytes(),Base64.DEFAULT);
        }
        public String serialize_accepted_apps(){
            if(apps_accepted.size()==0)return "";
            utils.bytes_integrator bytes_integrator_final=new utils.bytes_integrator();
            for (filter_app_entry app:apps_accepted){
                bytes_integrator_final.add_bytes(utils.long_to_bytes(app.package_name.getBytes().length,2));
                bytes_integrator_final.add_bytes(app.package_name.getBytes());
            }
            return Base64.encodeToString(bytes_integrator_final.integrate_to_bytes(),Base64.DEFAULT);
        }
    }
    public static class filter_app_entry{
        public Drawable icon;
        public String package_name,app_name;

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof filter_app_entry)) return false;
            filter_app_entry that = (filter_app_entry) o;
            return package_name.equals(that.package_name);
        }

        @Override
        public int hashCode() {
            return Objects.hash(icon, package_name, app_name);
        }
    }
    public RSAPublicKey getCent_server_dynamic_public_key() throws NoSuchAlgorithmException, InvalidKeySpecException {
        if(cent_server_dynamic_public_key==null){
            cent_server_dynamic_public_key=(RSAPublicKey) KeyFactory.getInstance("rsa").generatePublic(
                    new X509EncodedKeySpec(
                            Base64.decode(preferences.getString(SERVER_DYNAMIC_KEY_PUB,null),Base64.DEFAULT)
                    )
            );
            dynamic_key_modulus_sig=
                    Arrays.copyOfRange(cent_server_dynamic_public_key.getModulus().toByteArray(),0,4);
        }
        return cent_server_dynamic_public_key;
    }
    public static app_data_and_preferences getInstance() {
        if(vpn_service.activity!=null&&instance==null) {
            instance = new app_data_and_preferences(vpn_service.activity);
        }
        return instance;
    }
    private app_data_and_preferences(Context context){
        preferences=context.getSharedPreferences("preference0",Context.MODE_MULTI_PROCESS);
    }
    public static class server_details {
        public byte[] ip;
        public int port;
        public int extra;
        public int latency=-1;
        public server_details(byte[] data,int offset){
            ip=Arrays.copyOfRange(data,offset,offset+4);
            port=(int)utils.bytes_to_unsigned_long(data,offset+4,2);
            extra=(int)utils.bytes_to_unsigned_long(data,offset+6,2);
        }
    }
    private void dispatch_balk_servers_list(utils.pointed_byteArray bytes){
        int i=0;
        servers.removeAll(servers);
        while (i<(bytes.end-bytes.offset)/8){
            servers.add(new server_details(bytes.buffer,i*8+bytes.offset));
            i++;
        }
    }
    public boolean set_servers(utils.pointed_byteArray signed_servers_list){
        try {
            if(com.paranoia.zharftor.poshan.rsa_core.verify_data(//this is signed with dynamic key
                    signed_servers_list.buffer,2,
                    signed_servers_list.end- key_manager.server_dynamic_RSA_byte_size,
                    signed_servers_list.end- key_manager.server_dynamic_RSA_byte_size,
                    signed_servers_list.end,
                    cent_server_dynamic_public_key
            )){
                preferences.edit().putString(SERVERS_LIST,
                        Base64.encodeToString(signed_servers_list.buffer,2,
                                signed_servers_list.end- key_manager.server_dynamic_RSA_byte_size,Base64.DEFAULT)
                ).commit();
                servers_list_signature=Arrays.copyOfRange(signed_servers_list.buffer,
                        signed_servers_list.end-key_manager.server_dynamic_RSA_byte_size,signed_servers_list.end);
                servers.removeAll(servers);
                signed_servers_list.offset=2;
                signed_servers_list.end=signed_servers_list.end- key_manager.server_dynamic_RSA_byte_size;
                dispatch_balk_servers_list(signed_servers_list);
                preferences.edit().putString(SERVERS_LIST_SIG,
                        Base64.encodeToString(servers_list_signature,Base64.DEFAULT))
                .commit();
                return true;
            }
        } catch (NoSuchAlgorithmException e) {
//            e.printStackTrace();
        } catch (BadPaddingException e) {
//            e.printStackTrace();
        }
        return false;
    }
    public List<server_details> getServers(){
        return servers;
    }
    public byte[] get_servers_list_signature(){
        if(servers_list_signature==null)
            servers_list_signature=new byte[key_manager.server_dynamic_RSA_byte_size];
        return servers_list_signature;
    }
    public byte[] get_dynamic_key_modulus_sig(){
        if(dynamic_key_modulus_sig==null)

            dynamic_key_modulus_sig=new byte[4];
        return dynamic_key_modulus_sig;
    }
    public boolean set_latest_dynamic_cent_cerver_public_key(utils.pointed_byteArray signed_x509_key){
        try {
            if(com.paranoia.zharftor.poshan.rsa_core.verify_data(//this is signed with mother key
                    signed_x509_key.buffer,2,
                    signed_x509_key.end- key_manager.server_RSA_mother_byte_size,
                    signed_x509_key.end- key_manager.server_RSA_mother_byte_size,
                    signed_x509_key.end,
                    key_manager.get_m_public_key()
            )){

                //add to preferences
                preferences.edit().putString(SERVER_DYNAMIC_KEY_PUB, Base64.encodeToString(
                        signed_x509_key.buffer,2,signed_x509_key.end- key_manager.server_RSA_mother_byte_size,Base64.DEFAULT)
                ).commit();
                cent_server_dynamic_public_key=(RSAPublicKey) KeyFactory.getInstance("RSA").
                        generatePublic(new X509EncodedKeySpec(Arrays.copyOfRange(signed_x509_key.buffer,2,signed_x509_key.end- key_manager.server_RSA_mother_byte_size)));
                dynamic_key_modulus_sig=Arrays.copyOfRange(cent_server_dynamic_public_key.getModulus().toByteArray(),0,4);
                return true;
            }
        } catch (Throwable throwable) {
//            throwable.printStackTrace();
        }
        return false;
    }
    public void unset_client_id_and_symmetric_key(){
        preferences.edit().putString(SYMMETRIC_KEY,null).commit();
        preferences.edit().putString(CLIENT_ID,null).commit();
    }
    public void set_client_id_and_symmetric_key(byte [] symmetric_key,byte[] id){
        preferences.edit().putString(SYMMETRIC_KEY,
                Base64.encodeToString(symmetric_key,Base64.DEFAULT)).commit();
        preferences.edit().putString(CLIENT_ID,
                Base64.encodeToString(id,Base64.DEFAULT)).commit();
    }

    public key_manager.symmetric_key_and_id get_client_id_and_symmetric_key(){
        String key=preferences.getString(SYMMETRIC_KEY,null)
                ,id=preferences.getString(CLIENT_ID,null);
        if(key==null||id==null){
            return null;
        }
        key_manager.symmetric_key_and_id ski=new key_manager.symmetric_key_and_id();
        ski.symmetric_key=Base64.decode(key,Base64.DEFAULT);
        ski.id=Base64.decode(id,Base64.DEFAULT);
        return ski;
    }
    public void load_essentials_unchecked(){
        on_essentials_are_loaded();
    }
    public void load_essentials()  {
        cent_server_interface.is_effective_response =true;
        data_loader=new Thread(new Runnable() {
            @Override
            public void run() {
                instance.csi=new cent_server_interface();
                while(cent_server_interface.is_effective_response&&!Thread.currentThread().isInterrupted()){
                    String dyn_pub_key=preferences.getString(SERVER_DYNAMIC_KEY_PUB,null)
                            ,servers_sig=preferences.getString(SERVERS_LIST_SIG,null);

                    if(dyn_pub_key==null&&servers_sig==null){
                        dynamic_key_modulus_sig=new byte[4];
                        csi.request_dynamic_key_and_list(get_dynamic_key_modulus_sig());
                    }
                    else if(servers_sig==null&&dyn_pub_key!=null){
                        try {
                            getCent_server_dynamic_public_key();
                            csi.request_dynamic_key_and_list(get_dynamic_key_modulus_sig());
                        } catch (NoSuchAlgorithmException e) {
//                            e.printStackTrace();
                        } catch (InvalidKeySpecException e) {
//                            e.printStackTrace();
                        }
                    }else if (dyn_pub_key!=null&&servers_sig!=null){
                        servers_list_signature=Base64.decode(servers_sig, Base64.DEFAULT);
                        try {
                            getCent_server_dynamic_public_key();
                            csi.check_for_update(servers_list_signature);
                        } catch (NoSuchAlgorithmException e) {
//                            e.printStackTrace();
                        } catch (InvalidKeySpecException e) {
//                            e.printStackTrace();
                        }
                    }

                    try {
                        Thread.sleep(1000*3);
                    } catch (InterruptedException e) {
//                        e.printStackTrace();
                    }
                }
            }
        });
        data_loader.start();
    }
    public void on_essentials_are_loaded(){
        utils.pointed_byteArray balk_servers_list=new utils.pointed_byteArray(
                Base64.decode(preferences.getString(SERVERS_LIST,null),Base64.DEFAULT)
        );
        balk_servers_list.end=balk_servers_list.buffer.length;
        dispatch_balk_servers_list(balk_servers_list);
//        //exp
//        server_details s=servers.get(0);
//        servers.remove(0);
//        servers.add(s);
//        //exp
        if(data_loader!=null)data_loader.interrupt();
        cent_server_interface.is_effective_response =false;
        if(server_interface.server_domain_name==null) {
            vpn_service.selected_server_details =servers.get(0);
            server_interface.server_domain_name = utils.byte_to_regex_seprated_string(servers.get(0).ip, ".");
            server_interface.server_port = servers.get(0).port;
        }
        vpn_service.activity.set_App_connection_status_non_ui_thread(main.CONNECTION_STATUS_READY_OR_CONNECTED);
        if(!vpn_service.is_connected()&&!vpn_service.is_connecting())
            vpn_service.activity.s_adepter.load_servers_delays();
        //Log.d("appdata","essentials loaded");
    }
    public void mark_first_time(){
        preferences.edit().putBoolean(FIRST_TIME,false).commit();
        preferences.edit().putBoolean(CURRENT_ADDRESS_FILTER_STATE, address_filters_struct.accept_all_except).commit();
        preferences.edit().putBoolean(CURRENT_APPS_FILTER_STATE, app_filters.tunnel_all_except).commit();
        preferences.edit().putInt(PREFERED_AD_NETWORK_INDEX, 0).commit();
    }
    public boolean is_first_time(){
        if(instance.preferences.getBoolean(FIRST_TIME,true))
            return true;
        return false;
    }
    public static byte update_part_address_filter_type =0,update_part_addresses_rejected=1,update_part_addresses_accepted=2;
    public void update_address_filter_details(int part){
        if(part== update_part_address_filter_type)
            preferences.edit().putBoolean(CURRENT_ADDRESS_FILTER_STATE, address_filters.filter_type).commit();
        if(part==update_part_addresses_accepted)
            preferences.edit().putString(ADDRESS_FILTER_ACCEPTED_LIST,address_filters.serialize_accepted_ip_addresses()).commit();
        if(part==update_part_addresses_rejected)
            preferences.edit().putString(ADDRESS_FILTER_REJECTED_LIST,address_filters.serialize_rejected_ip_addresses()).commit();
    }
    public void update_prefered_ad_network_index(){
        preferences.edit().putInt(PREFERED_AD_NETWORK_INDEX, main_with_ads.ad_network_index).commit();
    }
    public void load_address_filter_info()throws Throwable {
        address_filters.filter_type=preferences.getBoolean(CURRENT_ADDRESS_FILTER_STATE,true);
        address_filters.ip_addresses_accepted.removeAll(address_filters.ip_addresses_accepted);
        address_filters.ip_addresses_rejected.removeAll(address_filters.ip_addresses_rejected);
        String s=preferences.getString(ADDRESS_FILTER_ACCEPTED_LIST,null);
        if(s!=null)if(s.length()!=0)dispatch_accepted_ip_addresses(s);
        s=preferences.getString(ADDRESS_FILTER_REJECTED_LIST,null);
        if(s!=null)if(s.length()!=0)dispatch_rejected_ip_addresses(s);
    }
    public static byte update_part_app_filter_type =0,update_part_apps_rejected=1,update_part_apps_accepted=2;
    public void update_app_filter_details(int part){
        if(part== update_part_app_filter_type)
            preferences.edit().putBoolean(CURRENT_APPS_FILTER_STATE, app_filters.filter_type).commit();
        if(part==update_part_apps_accepted)
            preferences.edit().putString(APP_FILTER_ACCEPTED_LIST,app_filters.serialize_accepted_apps()).commit();
        if(part==update_part_apps_rejected)
            preferences.edit().putString(APP_FILTER_REJECTED_LIST,app_filters.serialize_rejected_apps()).commit();
    }
    public void load_all_offline_info()throws Throwable{
        address_filters.filter_type=preferences.getBoolean(CURRENT_ADDRESS_FILTER_STATE,true);
        address_filters.ip_addresses_accepted.removeAll(address_filters.ip_addresses_accepted);
        address_filters.ip_addresses_rejected.removeAll(address_filters.ip_addresses_rejected);
        String s=preferences.getString(ADDRESS_FILTER_ACCEPTED_LIST,null);
        if(s!=null)if(s.length()!=0)dispatch_accepted_ip_addresses(s);
        s=preferences.getString(ADDRESS_FILTER_REJECTED_LIST,null);
        if(s!=null)if(s.length()!=0)dispatch_rejected_ip_addresses(s);

        app_filters.filter_type=preferences.getBoolean(CURRENT_APPS_FILTER_STATE,true);
        app_filters.apps_accepted.removeAll(app_filters.apps_accepted);
        app_filters.apps_rejected.removeAll(app_filters.apps_rejected);
        s=preferences.getString(APP_FILTER_ACCEPTED_LIST,null);
        if(s!=null)if(s.length()!=0)dispatch_accepted_apps(s);
        s=preferences.getString(APP_FILTER_REJECTED_LIST,null);
        if(s!=null)if(s.length()!=0)dispatch_rejected_apps(s);

        main_with_ads.ad_network_index=(byte) preferences.getInt(PREFERED_AD_NETWORK_INDEX,0);
    }
    public boolean should_show_ad(){
        if(System.currentTimeMillis()-preferences.getLong(AD_LAST_TIMESTAMP,0)>
                main_with_ads.ads_interval){
            return true;
        }
        return false;
    }
    public void record_ad_display(){
        preferences.edit().putLong(AD_LAST_TIMESTAMP,System.currentTimeMillis()).commit();
    }
}
