package com.paranoia.zharftor;

import android.util.Log;

import java.io.InputStream;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class utils {
    public static void read_pricesly_n_bytes_to_buffer(InputStream is, pointed_byteArray buffer, int n)throws Exception{
        if(n>buffer.buffer.length){
            throw new Exception("buffer size is smaller than n.");
        }
        int c=0,rc;
        while(c<n){
            rc=is.read(buffer.buffer,c,n-c);
            if(rc==-1)
                throw new Exception("connection closed");
            c=c+rc;
        }
        buffer.end=n;
        buffer.offset=0;
    }
    public class equalable_int_state {
        private int state=-1;
        public int get_state(){
            return this.state;
        }
        public boolean equals(int state){
            return this.state == state;
        }
        public void  set_state(int state){
//            if(!debug_is_common_instance)
//                Log.d("state_change","at id "+connection_id+" by thread: "+
//                    Thread.currentThread().getId()+" from "+this.state+" to "+state);
            this.state=state;
        }
    }
    public static class reusable_object_list{
        public interface object_major_methods {
            void update(Object current_object, Object new_object);
            Object clone(Object current_object);
        }
        private class Item {
            public Object object;
            public int id;
            public boolean is_used;
        }
        private Item item_temp;
        private int counter=0;
        private final List<Item> list=new ArrayList();
        public void put(Object object, int id, object_major_methods method){
            item_temp=null;
            counter=0;
            while (counter<list.size()){
                if(!list.get(counter).is_used){
                    item_temp= list.get(counter);
                    break;
                }
                counter++;
            }
            if(item_temp==null) {
                item_temp = new Item();
                item_temp.object=method.clone(object);
            }else {
                method.update(item_temp.object,object);
            }
            item_temp.id=id;
        }
        public void free_object_by_id(int id){
            try{
                get_item_by_id(id).is_used=false;
            }catch (Exception e){
//                e.printStackTrace();
            }
        }
        public Item get_item_by_id(int id){
            for(Item item: list){
                if(item.id==id&&item.is_used)return item;
            }
            return null;
        }
    }
    public static class pointed_byteArray{
        public ByteBuffer byteBuffer;
        public int offset=0,end=0;
        public int secondary_offset=0,secondary_end=0,tmp_end,tmp_offset;
        public byte[] buffer;
        public pointed_byteArray(){

        }
        public int size(){
            return (end-offset+secondary_end-secondary_offset);
        }
        public pointed_byteArray clone(){
            pointed_byteArray pba=new pointed_byteArray(buffer.clone());
            pba.offset=this.offset;
            pba.end=this.end;
            pba.secondary_offset=this.secondary_offset;
            pba.secondary_end=this.secondary_end;
            return pba;
        }
        public pointed_byteArray clone_data_portion(){
            byte[] buffer_clone=Arrays.copyOfRange(buffer,offset,end-offset);
            pointed_byteArray pba=new pointed_byteArray(buffer_clone);
            pba.offset=0;
            pba.end=buffer_clone.length;
            pba.secondary_offset=0;
            pba.secondary_end=0;
            return pba;
        }
        public pointed_byteArray(int size){
            byteBuffer=ByteBuffer.allocate(size);
            buffer=byteBuffer.array();
        }
        public pointed_byteArray(byte [] buffer){
            this.buffer=buffer;
            byteBuffer=ByteBuffer.wrap(buffer);
        }
    }
    public static class cirular_buffer_reader_writer extends pointed_byteArray{
        public static class vanished_exception extends Exception {
            public void printStackTrace() {
//                Log.d("exception", "buffer vanished.");
            }
        }
        private volatile int last_read_id;
        public cirular_buffer_reader_writer(int size){
            byteBuffer=ByteBuffer.allocate(size);
            buffer=byteBuffer.array();
            current_data_portions=new pointed_byteArray(buffer);
        }
        public void set_buffer(byte[ ] buffer){
            this.buffer=buffer;
            this.byteBuffer=ByteBuffer.wrap(buffer);
        }
        public void set_buffer_and_wrap_for_reading(byte[] buffer){
            this.buffer=new byte[buffer.length+1];
            this.byteBuffer=ByteBuffer.wrap(this.buffer);
            pointed_byteArray byteArray=new pointed_byteArray(buffer);
            byteArray.end=buffer.length;byteArray.offset=0;
            write(byteArray);
        }
        public int get_available_empty_space_for_writing(){
            return buffer.length-get_available_data_length()-1;//always return 1 less or otherwise end and offset overlap
        }
        public int get_available_data_length(){
            if(end<offset)
                return buffer.length-(offset-end);
            else return end-offset;
        }
        private long tmp_write_number;
        public void write_number(long number,int number_of_bytes){
            if(end+number_of_bytes<=buffer.length){
                insert_int_to_bytes(buffer,end,number,number_of_bytes);
                end=(end+number_of_bytes)% buffer.length;
            }else {
                tmp_write_number=number>>(8*(number_of_bytes-(buffer.length-end)));
                insert_int_to_bytes(buffer,end,tmp_write_number,buffer.length-end);
                insert_int_to_bytes(buffer,end,number-(tmp_write_number<<(8*number_of_bytes-(buffer.length-end)))
                        ,number_of_bytes-(buffer.length-end));
                end=number_of_bytes-(buffer.length-end);
            }
            synchronized (this){
                this.notifyAll();
            }
        }
        public void write_with_extra_portions(pointed_byteArray data){
            data.tmp_end=data.end;data.tmp_offset=data.offset;
            try {
                write(data);
                data.end = data.secondary_end;
                data.offset = data.secondary_offset;
                write(data);
            }catch (Throwable throwable){

            }
            data.end=data.tmp_end;data.offset=data.tmp_offset;
        }
        public void write(pointed_byteArray data){
            data.byteBuffer.limit(data.buffer.length);
            data.byteBuffer.position(data.offset);
            data.byteBuffer.limit(data.end);
            byteBuffer.position( end);
            if( end>= offset){
                byteBuffer.position( end);
                if((data.end-data.offset)+ end>=buffer.length){
                    int l1=buffer.length- end;
//                        byteBuffer.put(data.buffer,data.offset,l1);
                    data.byteBuffer.limit(l1+data.byteBuffer.position());
                    byteBuffer.put(data.byteBuffer);
                    byteBuffer.position(0);
//                        byteBuffer.put(data.buffer,data.offset+l1,(data.end-data.offset)-l1);
                    data.byteBuffer.position(l1+data.offset);
                    data.byteBuffer.limit(data.end);
                    byteBuffer.put(data.byteBuffer);
                    end=(data.end-data.offset)-l1;
                }else{
                    byteBuffer.put(data.byteBuffer);
                    end= end+(data.end-data.offset);
                }
            }else{
                byteBuffer.position( end);
                byteBuffer.put(data.byteBuffer);
                end=byteBuffer.position();
            }
            synchronized (this) {
                notifyAll();
            }
        }
        public long read_next_number(int number_of_bytes)throws InterruptedException{
            while(number_of_bytes>get_available_data_length()){
//                continue;//add wait here
                try {
                    synchronized (this) {
                        wait();
                    }
                } catch (InterruptedException e) {
                    throw e;
//                    e.printStackTrace();
                }
            }
            long o=0;
            if(number_of_bytes+offset>buffer.length){
                o= ((utils.bytes_to_unsigned_long(buffer,offset,buffer.length-offset)<<((number_of_bytes-(buffer.length-offset))*8))+utils.bytes_to_unsigned_long(buffer,0,number_of_bytes-(buffer.length-offset)));
                offset=number_of_bytes-(buffer.length-offset);
            }else {
                o= utils.bytes_to_unsigned_long(buffer,offset,number_of_bytes);
                offset=offset+number_of_bytes;
            }
            return o;
        }
        private vanished_exception ve=new vanished_exception();
        public pointed_byteArray current_data_portions;
        public void read_data_thread_aware(int proper_amount,int id) throws vanished_exception {
            last_read_id=id;
            while(proper_amount>get_available_data_length()){
//                continue;//add wait here and notify in write
                try {
                    synchronized (this) {
                        wait();
                    }
                } catch (InterruptedException e) {
//                    e.printStackTrace();
                }
            }
            if(id!=last_read_id)
                throw ve;
            current_data_portions.secondary_end=current_data_portions.secondary_offset=0;
            if(offset+proper_amount>=buffer.length){
                current_data_portions.offset=offset;
                current_data_portions.end=buffer.length;
                current_data_portions.secondary_offset=0;
                current_data_portions.secondary_end=proper_amount-(buffer.length-offset);
            }else {
                current_data_portions.offset=offset;
                current_data_portions.end=offset+proper_amount;
            }
        }
        public void read_data(int proper_amount)throws InterruptedException{
            while(proper_amount>get_available_data_length()){
//                continue;//add wait here and notify in write
                try {
                    synchronized (this) {
                        wait();
                    }
                } catch (InterruptedException e) {
                    throw e;
//                    e.printStackTrace();
                }
            }
            current_data_portions.secondary_end=current_data_portions.secondary_offset=0;
            if(offset+proper_amount>=buffer.length){
                current_data_portions.offset=offset;
                current_data_portions.end=buffer.length;
                current_data_portions.secondary_offset=0;
                current_data_portions.secondary_end=proper_amount-(buffer.length-offset);
            }else {
                current_data_portions.offset=offset;
                current_data_portions.end=offset+proper_amount;
            }
        }
        public void mark_read(){
            int len=(current_data_portions.end-current_data_portions.offset)+(current_data_portions.secondary_end-current_data_portions.secondary_offset);
            if(len+offset>=buffer.length){
                offset=(len+offset)%buffer.length;
            }else {
                offset=len+offset;
            }
//            if(offset<0)
//                Log.d("herebug","bug2");
        }
        public void move_offset_presumptiously(int assumed_offset, int displacement){//the assumption is that offset is now ahead from the assumed_offset
//            if(offset<0)
//                Log.d("herebug","bug0");
            if(offset>=assumed_offset){
                displacement=displacement-(offset-assumed_offset);
            }else {
                displacement=displacement-(buffer.length-(assumed_offset-offset));
            }
            try {
                read_data(displacement);
            } catch (InterruptedException e) {
//                throw new RuntimeException(e);
            }
            mark_read();
//            if(offset<0)
//                Log.d("herebug","bug1");
        }
        public void wipe_data(){
            synchronized (this){
                last_read_id++;
                this.notifyAll();
            }
            offset=end=secondary_end=secondary_offset=0;
//            Arrays.fill(buffer,(byte) 0);
//            end=offset=secondary_offset=secondary_end=0;
        }
    }
    public static void replace_bytes_range(ByteBuffer buffer,int position,byte[] new_bytes){
        int p=buffer.position();
        buffer.position(position);
        buffer.put(new_bytes);
        buffer.position(p);
    }
    public static byte[] get_byte_subset(byte[] bytes,int offset, int size){
        byte[] bytes_o=Arrays.copyOfRange(bytes,offset,offset+size);
        return bytes_o;
    }

    public static long bytes_to_unsigned_long(byte[]  bytes){
        long o=0;
        for (int i=0;i<bytes.length;i++){

            o=o*0x100+(((int)bytes[i])&0xff);
        }
        return o;
    }
    public static long bytes_to_unsigned_long(byte[]  bytes,int start,int size){
        long o=0;
        size=start+size;
        while(start<size){
            o=(o<<8)+(((int)bytes[start])&0xff);
            start++;
        }
        return o;
    }
    public static int byte_to_unsinged_long(byte b){
        return ((int) b)&0xff;
    }
    public static String byte_to_regex_seprated_string(byte[] bytes,String regex){
        String s="";
        for(byte b: bytes){
            s=s+regex+ byte_to_unsinged_long(b);
        }
        if(s.length()==0)return s;
        return s.substring(1);
    }
    public static long ip_string_to_long(String s){
        try {
            return bytes_to_unsigned_long(InetAddress.getByName(s).getAddress());
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
        return 0;
    }
    public static class bytes_integrator{
        private final List<byte[]> bytes_list=new ArrayList<>();
        private int size=0;
        public bytes_integrator add_bytes(byte[] bytes){
            if(bytes!=null)
                if(bytes.length!=0) {
                    bytes_list.add(bytes);
                    size=size+bytes.length;
                }
            return this;
        }
        public byte[] integrate_to_bytes(){
            if (size==0)return null;
            int i=0;
            int oi=0;
            byte[] out=new byte[size];
            while(i<bytes_list.size()){
                int j=0;
                while(j<bytes_list.get(i).length){
                    out[oi]=bytes_list.get(i)[j];
                    j++;
                    oi++;
                }
                i++;
            }
            bytes_list.removeAll(bytes_list);
            size=0;
            return out;
        }
    }
    private static final long int_limit=(long)Math.pow(2,32);
    public static long increament_syn_ack(long current_value,long increment){
        return (current_value+increment)%int_limit;
    }
    public static byte[] replace_bytes_range(byte[] bytes, int offset, byte[] new_value){
        int i=0;
        while(i<new_value.length){
            bytes[offset+i]=new_value[i];
            i++;
        }
        return bytes;
    }
    public static byte[] replace_bytes_range(byte[] bytes, int offset, byte[] new_value,int new_value_offset,int new_value_size){
        int i=0;
        while(i<new_value_size){
            bytes[offset+i]=new_value[new_value_offset+i];
            i++;
        }
        return bytes;
    }
    public static byte[] long_to_bytes(long n, int number_of_bytes){
        byte[] bytes=new byte[number_of_bytes];
        int i=0;
        while(i<number_of_bytes){
            bytes[number_of_bytes-i-1]=(byte)( (n&(0xff<<8*i))>>8*i);
            i++;
        }
        return bytes;
    }
    public static byte[] insert_int_to_bytes(byte [] bytes,int offset,long n,int number_of_bytes){
        int i=0;
        while(i<number_of_bytes){
            bytes[offset+number_of_bytes-i-1]=(byte)( (n>>8*i)&0xff);
            i++;
        }
        return bytes;
    }
    public static int calculate_ones_complement_checksum(byte[] packet){
        int i=0,checksum=0;
        packet=packet.clone();
        if(packet.length%2==1){
            packet=new bytes_integrator().add_bytes(packet).add_bytes(long_to_bytes(-0,1)).integrate_to_bytes();
        }
        while(i<packet.length){
            checksum=checksum+(int) bytes_to_unsigned_long(packet,i,2);
            i=i+2;
        }
        int m=checksum&0xffff;
        int carry=checksum>>16;
        checksum=carry+m;
        m=checksum&0xffff;
        carry=checksum>>16;
        checksum=m+carry;
        return (~checksum)&0xffff;
    }
    public static int calculate_ones_complement_checksum(ByteBuffer buffer,int start,int size){
        int i=0,checksum=0;
        byte temp=0;
        if(size%2==1){
            temp=buffer.array()[size];
            replace_bytes_range(buffer,start+size+1, long_to_bytes(0,1));
        }
        while(i<size){
            checksum=checksum+(int) bytes_to_unsigned_long(buffer.array(),i,2);
            i=i+2;
        }
        if(size%2==1){
            buffer.array()[size]=temp;
        }
        int m=checksum&0xffff;
        int carry=checksum>>16;
        checksum=carry+m;
        m=checksum&0xffff;
        carry=checksum>>16;
        checksum=m+carry;
        return (~checksum)&0xffff;
    }
    public static int calculate_ones_complement_checksum_tcp(byte[] buffer,int tcp_segment_start,int tcp_segment_end){
        int i=tcp_segment_start,checksum=0;
        byte temp=0;
        checksum=checksum+(int)(
                bytes_to_unsigned_long(buffer,12,2)
                +bytes_to_unsigned_long(buffer,14,2)
                        +bytes_to_unsigned_long(buffer,16,2)
                        +bytes_to_unsigned_long(buffer,18,2)
                        +0x6
                + (tcp_segment_end-tcp_segment_start)
        );
        if((tcp_segment_end-tcp_segment_start)%2==1){
            temp=buffer[tcp_segment_end];
            insert_int_to_bytes(buffer,tcp_segment_end,0,1);
        }
        while(i<tcp_segment_end){
            checksum=checksum+(int) bytes_to_unsigned_long(buffer,i,2);
            i=i+2;
        }
        if((tcp_segment_end-tcp_segment_start)%2==1){
            buffer[tcp_segment_end]=temp;
        }
        int m=checksum&0xffff;
        int carry=checksum>>16;
        checksum=carry+m;
        m=checksum&0xffff;
        carry=checksum>>16;
        checksum=m+carry;
        return (~checksum)&0xffff;
    }
}
