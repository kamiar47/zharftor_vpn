package com.paranoia.zharftor.proto;

import androidx.annotation.NonNull;

import com.paranoia.zharftor.protocols_namespace;
import com.paranoia.zharftor.utils;

public class ip_packet{
    public ip ip_header;
    public tcp tcp_segment=null;
    public udp udp_datagram=null;
    public boolean needs_attendance=false;
    public int connection_id=-1;

}
