package com.paranoia.zharftor;

import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

//import com.applovin.mediation.MaxAd;
//import com.applovin.mediation.MaxAdListener;
//import com.applovin.mediation.MaxError;
//import com.applovin.mediation.ads.MaxInterstitialAd;
//import com.applovin.sdk.AppLovinPrivacySettings;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.OnUserEarnedRewardListener;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
//import com.unity3d.ads.IUnityAdsInitializationListener;
//import com.unity3d.ads.IUnityAdsLoadListener;
//import com.unity3d.ads.IUnityAdsShowListener;
//import com.unity3d.ads.UnityAds;
//import com.unity3d.ads.UnityAdsShowOptions;

import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;

public class main_with_ads extends AppCompatActivity implements OnUserEarnedRewardListener {
    //unity property
    private String unity_app_id="4982898";
    public static boolean ads_are_laoded,rewarded_ads_loaded;
    private static long last_start_timestamp=System.currentTimeMillis();
    public static long ads_interval=3*60*1000;
    private static final String unity_interstitial_ad_id="Interstitial_Android";
    //admob property
    private InterstitialAd mInterstitialAd;
    private RewardedAd mRewardedAd;
    private static final String admob_test_rewarded_ad_id ="ca-app-pub-3940256099942544/5224354917";
    private static final String admob_test_interstitial_id="ca-app-pub-3940256099942544/1033173712";
    private static final String admob_real_interstitial_id ="ca-app-pub-4547549635569778/3475324233";
    private static final String admob_real_rewarded_ad_id ="ca-app-pub-4547549635569778/5071179807";

    //applovin property
//    private MaxInterstitialAd Applovin_interstitialAd;
    //start.io property
//    private StartAppAd startAppAd;
    public static byte ad_network_index;
    private static byte initiated_ad_network_index;
    public static final byte ad_network_admob=0,ad_network_unity=1,ad_network_applovin=2,ad_network_startio=3;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ads_are_laoded =false;
        setContentView(R.layout.m0);
        com.paranoia.zharftor.vpn_service.activity = (main)this;
        try {
            app_data_and_preferences.getInstance().load_all_offline_info();
        } catch (Throwable e) {
            throw new RuntimeException(e);
        }
        ad_network_index=ad_network_admob;
        init_ad_network();
    }
    public void init_ad_network(){
        if(mInterstitialAd!=null)return;
        initiated_ad_network_index=ad_network_index;
        if(ad_network_index==ad_network_admob){
            MobileAds.initialize(this, new OnInitializationCompleteListener() {
                @Override
                public void onInitializationComplete(InitializationStatus initializationStatus) {
                    load_ad();
                }
            });
        }
    }
    public void load_ad(){
        if(initiated_ad_network_index==ad_network_admob){
            AdRequest adRequest = new AdRequest.Builder().build();
            InterstitialAd.load(this, admob_real_interstitial_id, adRequest,
                    new InterstitialAdLoadCallback() {
                        @Override
                        public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                            // The mInterstitialAd reference will be null until
                            // an ad is loaded.
                            ads_are_laoded =true;
                            mInterstitialAd = interstitialAd;
                            Log.i("admob", "onAdLoaded");
//                            Log.i("timestamp", String.valueOf(System.currentTimeMillis()-last_start_timestamp));
                            vpn_service.activity.set_ads_loading_state(false);
//                            show_ad();
                        }

                        @Override
                        public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                            // Handle the error
                            Log.d("admob", loadAdError.toString());
                            mInterstitialAd = null;
                            ads_are_laoded =false;
                            vpn_service.activity.set_ads_loading_state(false);
                        }
                    });
        }
//        load_ad_rewarded();
    }
//    public void load_ad_rewarded(){
//        if(initiated_ad_network_index==ad_network_admob) {
//            AdRequest adRequest1 = new AdRequest.Builder().build();
//            RewardedAd.load(this, admob_test_rewarded_ad_id, adRequest1, new RewardedAdLoadCallback() {
//                @Override
//                public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
//                    super.onAdFailedToLoad(loadAdError);
//                    rewarded_ads_loaded = false;
//                    mRewardedAd = null;
//                    vpn_service.activity.set_addtime_visibility(View.GONE);
//                }
//
//                @Override
//                public void onAdLoaded(@NonNull RewardedAd rewardedAd) {
//                    super.onAdLoaded(rewardedAd);
//                    rewarded_ads_loaded = true;
//                    mRewardedAd = rewardedAd;
//                    vpn_service.activity.set_addtime_visibility(View.VISIBLE);
//
//                }
//            });
//        }
//    }
    public boolean continue_without_ads(){
        if(ads_are_laoded)
            return false;
        else {
            if(System.currentTimeMillis()-last_start_timestamp>15*1000){
                return true;
            }
            else {
                vpn_service.activity.show_message_non_ui_threads("please wait...");
                return false;
            }
        }
    }
    public void show_ad_interstitial(){
        if(initiated_ad_network_index==ad_network_admob){
            if(mInterstitialAd!=null){
                mInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback(){
                    @Override
                    public void onAdClicked() {
                        // Called when a click is recorded for an ad.
                        Log.d("admob", "Ad was clicked.");
                    }

                    @Override
                    public void onAdDismissedFullScreenContent() {
                        // Called when ad is dismissed.
                        // Set the ad reference to null so you don't show the ad a second time.
                        Log.d("admob", "Ad dismissed fullscreen content.");
                        mInterstitialAd = null;
                    }

                    @Override
                    public void onAdFailedToShowFullScreenContent(AdError adError) {
                        // Called when ad fails to show.
                        Log.e("admob", "Ad failed to show fullscreen content.");
                        mInterstitialAd = null;
                    }

                    @Override
                    public void onAdImpression() {
                        // Called when an impression is recorded for an ad.
                        Log.d("admob", "Ad recorded an impression.");
                    }

                    @Override
                    public void onAdShowedFullScreenContent() {
                        app_data_and_preferences.getInstance().record_ad_display();
                        // Called when ad is shown.
                        Log.d("admob", "Ad showed fullscreen content.");
                    }
                });
                mInterstitialAd.show(main_with_ads.this);
            }else
                init_ad_network();
        }
    }
    public void show_ad_rewarded(){
        if(initiated_ad_network_index==ad_network_admob){
            if(mRewardedAd!=null){
                mRewardedAd.setFullScreenContentCallback(new FullScreenContentCallback(){
                    @Override
                    public void onAdClicked() {
                        // Called when a click is recorded for an ad.
                        Log.d("admob", "Ad was clicked.");
                    }

                    @Override
                    public void onAdDismissedFullScreenContent() {
                        // Called when ad is dismissed.
                        // Set the ad reference to null so you don't show the ad a second time.
                        Log.d("admob", "Ad dismissed fullscreen content.");
                        mRewardedAd = null;
                    }

                    @Override
                    public void onAdFailedToShowFullScreenContent(AdError adError) {
                        // Called when ad fails to show.
                        Log.e("admob", "Ad failed to show fullscreen content.");
                        mRewardedAd = null;
                        load_ad();
                    }

                    @Override
                    public void onAdImpression() {
                        // Called when an impression is recorded for an ad.
                        Log.d("admob", "Ad recorded an impression.");
                    }

                    @Override
                    public void onAdShowedFullScreenContent() {
                        app_data_and_preferences.getInstance().record_ad_display();
                        load_ad();
                        // Called when ad is shown.
                        Log.d("admob", "Ad showed fullscreen content.");
                    }
                });
                mRewardedAd.show(main_with_ads.this,main_with_ads.this);
            }else
                init_ad_network();
        }
    }
    @Override
    protected void onStart() {
        super.onStart();
        last_start_timestamp=System.currentTimeMillis();
    }
    @Override
    public void onUserEarnedReward(@NonNull RewardItem rewardItem) {
//        vpn_service.add_time(rewardItem.getAmount());
//        vpn_service.add_time(2);
//        vpn_service.activity.set_addtime_visibility(View.GONE);
    }
}