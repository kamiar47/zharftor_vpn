package com.paranoia.zharftor.proto;

import static com.paranoia.zharftor.vpn_service.generate_packet;
//import static com.paranoia.zharftor.vpn_service.tcp_cons;
import static com.paranoia.zharftor.vpn_service.tun_buffer_distributer_packet_out_buffer_tcp;

import android.util.Log;

import com.paranoia.zharftor.utils;
import com.paranoia.zharftor.vpn_service;

public class tcp{


    private static final int read_access_id=0xefffff;
    public boolean has_data=false, closed_on_server_side =false, closed_on_client_side =false;
    public int data_length=0,dbg_total_upload=0, total_download =0;
    public tcp(){

    }
    public tcp(int buffer_size){
        server_buffer_reader_writer=new utils.cirular_buffer_reader_writer(buffer_size);
    }
    public boolean has_flag(int flag){
        return (this.flags & flag) == flag;
    }
    public utils.cirular_buffer_reader_writer server_buffer_reader_writer;
    public long dst_port,src_port;
    public long ack_number,seq_number, last_generated_packet_seq,last_generated_ack,ack_of_last_window_update, first_ack_of_client_after_HandShake;
    public int data_offset,urgent_pointer;
    public boolean is_opened_on_server=false;
    public long window_size,latest_window_size=-1;
    public long total_sent_data_len=0,total_recieved_data=0;
    public byte [] check_sum=new byte[2];
    public int flags=0;
    public class options{
        public long mss,window_scale=0;
        public  options clone(){
            options ops=new options();
            ops.mss=this.mss;
            ops.window_scale=this.window_scale;
            return ops;
        }
        //boolean supports_selective_ack;
    }
    int available_data_len,proper_amount;
    public Thread cdt=null;
    public  options options;
    public void parse_and_set_options(byte[] tcp_ip_packet,int offset_of_options,int size){
        if(options==null)options=new  options();
        int i=offset_of_options,opt_size=1;
        while(i<size+offset_of_options){
            if(tcp_ip_packet[i]==0x0){//the end
                return;
            }
            if(tcp_ip_packet[i]==0x1){
                //none option padding
                i++;
                continue;
            }
            opt_size=utils.byte_to_unsinged_long(tcp_ip_packet[i+1]);
            if(tcp_ip_packet[i]==0x2){
                options.mss=utils.bytes_to_unsigned_long(tcp_ip_packet,i+2,opt_size-2);//maximum segment size
            }
            if(tcp_ip_packet[i]==0x3){
                options.window_scale=utils.byte_to_unsinged_long(tcp_ip_packet[i+2]);
            }
            if(tcp_ip_packet[i]==0x4){
                //we dont care about selective acknowlegement
            }
            if(tcp_ip_packet[i]==0x5){
                //utils.bytes_to_unsigned_int(utils.get_byte_subset(bytes,i+2,opt_size-2)); we dont care about selective acknowlegement
            }
            if(tcp_ip_packet[i]==0x8){
                //we dont care about time stamp
            }
            i=i+opt_size;
        }
    }

}