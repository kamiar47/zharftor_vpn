package com.paranoia.zharftor.ui;

import android.app.Activity;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.paranoia.zharftor.R;
import com.paranoia.zharftor.app_data_and_preferences;
import com.paranoia.zharftor.protocols_namespace;

import java.util.ArrayList;
import java.util.List;

public class recyclers_adapters {
    public static class ip_addresses_recycler extends RecyclerView.Adapter<ip_addresses_recycler.v_holder>{
        private byte type;
        private Activity context;
        private List<app_data_and_preferences.filter_address_entry> list;
        public static final byte type_rejected_ips=0,type_accepted_ips=1;
        public ip_addresses_recycler(byte type,Activity activity){
            this.type=type;
            if(type_accepted_ips==type){
                list=app_data_and_preferences.getInstance().address_filters.ip_addresses_accepted;
            }
            if(type_rejected_ips==type){
                list=app_data_and_preferences.getInstance().address_filters.ip_addresses_rejected;
            }
            this.context=activity;
        }
        @NonNull
        @Override
        public v_holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new v_holder(context.getLayoutInflater().inflate(R.layout.config_ip_holder,null));
        }

        @Override
        public void onBindViewHolder(@NonNull v_holder holder, int position) {
            if(list.get(position).protocol== protocols_namespace.IP.TCP_PROTOCOL_NUMBER){
                holder.protocol.setText("Protocol: TCP");
            }
            if(list.get(position).protocol== protocols_namespace.IP.UDP_PROTOCOL_NUMBER){
                holder.protocol.setText("Protocol: UDP");
            }
            if(list.get(position).protocol== protocols_namespace.IP.CUSTOM_TCP_UDP_COMB_PROTOCOL_NUMBER){
                holder.protocol.setText("Protocol: TCP/UDP");
            }

            if(list.get(position).is_address_range){
                holder.ip.setText("IP: from "+utils.ip_long_to_string( list.get(position).address_min)+'\n'+" to "+utils.ip_long_to_string(list.get(position).address_max));
            }else{
                holder.ip.setText("IP: "+utils.ip_long_to_string( list.get(position).address_min));
            }

            if(list.get(position).is_port_range){
                holder.port.setText("Port: from "+list.get(position).port_min+'\n'+" to "+list.get(position).port_max);
            }else{
                holder.port.setText("Port: "+list.get(position).port_min);
            }
            holder.del_button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(type==type_accepted_ips){
                        app_data_and_preferences.getInstance().address_filters.ip_addresses_accepted.remove(holder.getAdapterPosition());
                        app_data_and_preferences.getInstance().update_address_filter_details(app_data_and_preferences.update_part_addresses_accepted);
                    }
                    if(type==type_rejected_ips){
                        app_data_and_preferences.getInstance().address_filters.ip_addresses_rejected.remove(holder.getAdapterPosition());
                        app_data_and_preferences.getInstance().update_address_filter_details(app_data_and_preferences.update_part_addresses_rejected);
                    }
                    notifyDataSetChanged();
                }
            });

        }

        @Override
        public int getItemCount() {
            if(type==type_rejected_ips){
                return app_data_and_preferences.getInstance().address_filters.ip_addresses_rejected.size();
            }
            if(type==type_accepted_ips){
                return app_data_and_preferences.getInstance().address_filters.ip_addresses_accepted.size();
            }
            return 0;
        }

        @Override
        public void onViewDetachedFromWindow(@NonNull v_holder holder) {
            super.onViewDetachedFromWindow(holder);
            holder.ip.setText("");
            holder.port.setText("");
            holder.protocol.setText("");
        }

        public static class v_holder extends RecyclerView.ViewHolder{
            public TextView ip,port,protocol;
            public ImageButton del_button;
            public v_holder(@NonNull View itemView) {
                super(itemView);
                itemView.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT));
                ((ViewGroup.MarginLayoutParams)((LinearLayout)itemView).getLayoutParams()).setMargins(3,3,3,3);
                ip=(TextView) itemView.findViewById(R.id.ip_field_rec);
                port=(TextView) itemView.findViewById(R.id.port_field_rec);
                protocol=(TextView) itemView.findViewById(R.id.protocol_field_rec);
                del_button=(ImageButton) itemView.findViewById(R.id.del_btn_rec);
            }
        }
    }

    public static class app_chooser_recycler extends RecyclerView.Adapter<app_chooser_recycler.v_holder>{
        private byte type;
        private Activity context;
        private PackageManager pm;
        public class package_item{
            public boolean is_selected=false;
            public ApplicationInfo applicationInfo;
            public String app_name;
            public Drawable icon;
            public package_item(ApplicationInfo af){
                this.applicationInfo=af;
                this.app_name=pm.getApplicationLabel(af).toString();
                this.icon=this.applicationInfo.loadIcon(pm);
            }
        }
        public List<package_item> list=new ArrayList<>();
        public app_chooser_recycler(Activity activity){
            this.type=type;
            list=new ArrayList<>();
            this.context=activity;
            pm=activity.getPackageManager();
            List<ApplicationInfo> l=pm.getInstalledApplications(PackageManager.GET_META_DATA);
            for (ApplicationInfo info : l){
                list.add(new package_item(info));
            }
        }
        @NonNull
        @Override
        public v_holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new v_holder(context.getLayoutInflater().inflate(R.layout.config_app_holder,null));
        }

        @Override
        public void onBindViewHolder(@NonNull v_holder holder, final int position) {
            holder.app_name.setText(list.get(position).app_name);
            holder.package_name.setText(list.get(position).applicationInfo.packageName);
            holder.checkBox.setChecked(list.get(position).is_selected);
            holder.icon.setImageDrawable(list.get(position).icon);
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    list.get(position).is_selected=!list.get(position).is_selected;
                    holder.checkBox.setChecked(list.get(position).is_selected);
                }
            });
        }

        @Override
        public int getItemCount() {
            return list.size();
        }

        @Override
        public void onViewDetachedFromWindow(@NonNull v_holder holder) {
            super.onViewDetachedFromWindow(holder);
//            holder.icon.setImageDrawable(null);
//            holder.checkBox.setChecked(false);
//            holder.package_name.setText("");
//            holder.app_name.setText("");
        }
        public static class v_holder extends RecyclerView.ViewHolder{
            public TextView app_name,package_name;
            public ImageView icon;
            public CheckBox checkBox;
            public v_holder(@NonNull View itemView) {
                super(itemView);
                itemView.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT));
                ((ViewGroup.MarginLayoutParams)((LinearLayout)itemView).getLayoutParams()).setMargins(2,1,2,1);
                app_name =(TextView) itemView.findViewById(R.id.app_name);
                package_name=(TextView) itemView.findViewById(R.id.package_name);
                checkBox=(CheckBox) itemView.findViewById(R.id.app_checkbox);
                icon=(ImageView) itemView.findViewById(R.id.app_icon);
            }
        }
    }
    public static class apps_list_recycler extends RecyclerView.Adapter<apps_list_recycler.v_holder>{
        private byte type;
        private Activity context;
        private PackageManager pm;
        public class package_item{
            public ApplicationInfo applicationInfo;
            public package_item(ApplicationInfo af){
                this.applicationInfo=af;
            }
        }
        public List<app_data_and_preferences.filter_app_entry> list=new ArrayList<>();
        public static final byte tunnel_all_except=0,tunnel_none_except=1;
        public apps_list_recycler(byte type,Activity activity){
            this.type=type;
            this.context=activity;
            pm=activity.getPackageManager();
            if(type==tunnel_all_except){
                list=app_data_and_preferences.getInstance().app_filters.apps_rejected;
            }
            if(type==tunnel_none_except){
                list=app_data_and_preferences.getInstance().app_filters.apps_accepted;
            }
            for(app_data_and_preferences.filter_app_entry app: list){
                ApplicationInfo info=null;
                try {
                    info=pm.getApplicationInfo(app.package_name,PackageManager.GET_META_DATA);
                } catch (PackageManager.NameNotFoundException e) {
                    e.printStackTrace();
//                        Toast.makeText(activity,"")
                    continue;
                }
                app.app_name=pm.getApplicationLabel(info).toString();
                app.icon=info.loadIcon(pm);
            }
        }
        @NonNull
        @Override
        public v_holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new v_holder(context.getLayoutInflater().inflate(R.layout.config_app_holder,null));
        }

        @Override
        public void onBindViewHolder(@NonNull v_holder holder, final int position) {
            holder.app_name.setText(list.get(position).app_name);
            holder.package_name.setText(list.get(position).package_name);
            holder.icon.setImageDrawable(list.get(position).icon);
            holder.remove_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    list.remove(position);
                    if(type==tunnel_all_except)
                        app_data_and_preferences.getInstance().update_app_filter_details(app_data_and_preferences.update_part_apps_rejected);
                    if(type==tunnel_none_except)
                        app_data_and_preferences.getInstance().update_app_filter_details(app_data_and_preferences.update_part_apps_accepted);
                    notifyDataSetChanged();
                }
            });
        }

        @Override
        public int getItemCount() {
            return list.size();
        }

        @Override
        public void onViewDetachedFromWindow(@NonNull v_holder holder) {
            super.onViewDetachedFromWindow(holder);
//            holder.icon.setImageDrawable(null);
//            holder.checkBox.setChecked(false);
//            holder.package_name.setText("");
//            holder.app_name.setText("");
//            holder.checkBox.setVisibility(View.GONE);
        }

        @Override
        public void onViewAttachedToWindow(@NonNull v_holder holder) {
            super.onViewAttachedToWindow(holder);
        }

        public static class v_holder extends RecyclerView.ViewHolder{
            public TextView app_name,package_name;
            public ImageView icon;
            public CheckBox checkBox;
            public ImageButton remove_btn;
            public v_holder(@NonNull View itemView) {
                super(itemView);
                itemView.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT));
                ((ViewGroup.MarginLayoutParams)((LinearLayout)itemView).getLayoutParams()).setMargins(2,1,2,1);
                app_name =(TextView) itemView.findViewById(R.id.app_name);
                package_name=(TextView) itemView.findViewById(R.id.package_name);
                checkBox=(CheckBox) itemView.findViewById(R.id.app_checkbox);
                checkBox.setVisibility(View.GONE);
                remove_btn=itemView.findViewById(R.id.remove_app_btn);
                remove_btn.setVisibility(View.VISIBLE);
                icon=(ImageView) itemView.findViewById(R.id.app_icon);
            }
        }
    }
}
