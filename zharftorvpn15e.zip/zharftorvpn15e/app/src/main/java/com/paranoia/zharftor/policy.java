package com.paranoia.zharftor;

import com.paranoia.zharftor.proto.ip_packet;

public class policy {
//    private static long state=0;
//    public static final long rule_allow_all_except=1;
//    public static final long rule_allow_all=2;
//    public static final long rule_block_all_except=4;
//    public static void set_rule(long rule){
//        state=state|rule;
//    }
//    public static void unset_rule(long rule){
//        state=state&(~rule);
//    }
    public static boolean request_is_allowed(ip_packet packet){//to be expanded
//        return utils.byte_to_regex_seprated_string(packet.ip_header.dst_ip, ".").contains("192.168.1.");
//        return utils.byte_to_regex_seprated_string(packet.ip_header.dst_ip, ".").contains("104.193.254.44");
        return true;

    }
}
