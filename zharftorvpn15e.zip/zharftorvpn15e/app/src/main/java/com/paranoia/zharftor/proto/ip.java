package com.paranoia.zharftor.proto;
public class ip{
    public int packet_id, packet_id_outgoing;
    public byte protocol;
    public byte flags;
    public boolean has_flag(short flag){
        return (flag & flags) == flag;
    }
    public long packet_offset;
    public byte[] dst_ip=new byte[4],src_ip=new byte[4];
}
