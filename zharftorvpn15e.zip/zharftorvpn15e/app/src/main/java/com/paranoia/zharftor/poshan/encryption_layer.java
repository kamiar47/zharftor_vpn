package com.paranoia.zharftor.poshan;

import android.util.Log;

import com.paranoia.zharftor.utils;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.nio.channels.SocketChannel;
import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;

public class encryption_layer {
    private final key_manager.server_client_key_combo keys;
    private final SocketChannel channel;
    private CipherOutputStream os;
    private final CipherInputStream is;
    private final Cipher co=Cipher.getInstance("AES/CBC/NoPadding");
    private final Cipher ci=Cipher.getInstance("AES/CBC/NoPadding");
    public encryption_layer(key_manager.server_client_key_combo keys, SocketChannel socketChannel)throws Throwable{
        this.channel=socketChannel;
        this.keys=keys;
        co.init(Cipher.ENCRYPT_MODE,keys.server_keys.Key,keys.server_keys.IV);
        ci.init(Cipher.DECRYPT_MODE,keys.client_keys.Key,keys.client_keys.IV);
//        os=new CipherOutputStream(socketChannel.socket().getOutputStream(),co);
        is=new CipherInputStream(socketChannel.socket().getInputStream(),ci);
    }
    private byte remainder=0;
    private final utils.pointed_byteArray encrypted_buffer=new utils.pointed_byteArray(70000);
    public void write(utils.pointed_byteArray bytes)throws Throwable{//passed bytearray must contain at least 16 empty bytes at the end
        encrypted_buffer.offset=encrypted_buffer.end=0;
        remainder=(byte)((bytes.end-bytes.offset)%16);
        if(remainder!=0){
            Arrays.fill(bytes.buffer,bytes.end,bytes.end+(16-remainder),(byte)0);
            bytes.end= bytes.end+16-remainder;
        }
        long tempt=System.nanoTime();
        while(encrypted_buffer.end< (bytes.end-bytes.offset)){
            bytes.offset=bytes.offset+encrypted_buffer.end;//however much was written
            encrypted_buffer.end=encrypted_buffer.end+
                    co.update(bytes.buffer,bytes.offset,bytes.end-bytes.offset,encrypted_buffer.buffer, encrypted_buffer.end);
//            encrypted_buffer.end=encrypted_buffer.end+
//                    co.doFinal(encrypted_buffer.buffer,encrypted_buffer.end);
        }
        tempt=System.nanoTime()-tempt;
        encrypted_buffer.byteBuffer.position(encrypted_buffer.offset);
        encrypted_buffer.byteBuffer.limit(encrypted_buffer.end);
        channel.write(encrypted_buffer.byteBuffer);
    }
    public void read(utils.pointed_byteArray bytes)throws Throwable{
        bytes.end=is.read(bytes.buffer, bytes.offset, bytes.end)+bytes.offset;
    }
}
