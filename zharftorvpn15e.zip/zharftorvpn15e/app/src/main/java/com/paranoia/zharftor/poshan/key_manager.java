package com.paranoia.zharftor.poshan;

import static java.lang.System.arraycopy;

import android.util.Base64;

import com.paranoia.zharftor.utils;

import java.net.Socket;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.Arrays;
import java.util.Random;

import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class key_manager {
//    private static final String cent_server_m_public_key_x509_encoded_base64="MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAklyTajF9AbS15aZyw6c60TsAdgsS77xbGSm1snRYQS1Zj1gG/JGXC7xyvUZg6yEafOmu/jscpOwRx8zvnCW+BObRnen//XQSBqQqqX3ev0xAssrBTTd/oIQ6GVHxwuoZ5ov2eHmLi3pYd06mfo0OcZE9fxzq4wrEWghqMg/1kI6+czDkQIZ7tb/gGxg0RieyHXNZG4Wy1LW4du11H98CpbX32mZMw6nyEiKBd38w8puzwLgossoxhOxegWuOPml+/6hKQTViKNo2Zp7HbV3zugC7/Hof1aZ/9STgOM8t9yhx1fRrq+BZhiZ+eJ3b5JJacLn1VsDjyFxsByvFIEj5vIwME9cIkd+9ABz2IhQy03NqXnAyy4zVaX3AL2tHb7b+kqOkLVmeHl1uV2d3enLv89dV508/suhMGQg+Z0nfOC8IH9JLPaOatfNcJnMoItsgVq8HhayO5CMaoK/zt8L4BfAiLqyD9qdh88hBrEU7xn+zcr8cZEOT+VxpHA2ZowhCGiMPiJGmwW8v6oKR560TCj7CS3Z4adf5loWNBMx5P/faJpqtZfQna4o9fWwagMQrpu9/0ZwtaGhw6Q0ei+D2fj0tCXWwNbdNVj1VVMTkXrN5kgna4yYCf+aijnbsp6FvdiZUgPorfZuhq22gHg4s9+JWkeiw2sBp5kIUV9WLFkMCAwEAAQ==";//old
//    private static final String cent_server_m_public_key_x509_encoded_base64="MIIEIjANBgkqhkiG9w0BAQEFAAOCBA8AMIIECgKCBAEAqk1Jyq7aa1tTc76Uzk5xOqtU4miwvxMPSUMu51lOUtyBELaMOCLGtwOIu0HfkuCmIU8uQQxt9elHTjFRIv3rKfOeENV11xmkvDiXVPBsbPMyoL73oXEq0wVhf43e5go+v8GwfyuVtDOLaQAGmNz+DCp0ZhGJtCnO3dViWMFnANQ+CwBd7sb/2Y8GjF+yBA4x3jsNt/MBD4QR3Cy3Qok9tWi1aliF7nFGpHL238DVcl7/HMei1fQHtNGD8xjBOAIsQI4AhdfJA/cUpxBzxqHtp8BK3jk+I/XkL3/30JDPIdLcZNJBxa5qQ6070VYyq5iL+ytqeIfrQIRh/LCn2dm9UhKW53wprVnoMbikweLENTZnoOJO+T5pYoaNCQdLaGTV0fyRRUWG2pzIAx/tTUJwhUDMkPhshout2Wc0h92NDOKDX0GtS9oS4QeJyqCPu35BnBxv67Lkhn19EP8FPPESm47rlr8bqfnIRFF8a0OOQIJOft3xrJ8m06ugOVys2769HxdMg3YONu6i0cyQd0w/Jxu+y2BfIvg2fHSGxUebHjqCfhH0Z76AG5vOcGYRtbq/iqaT5GYidjFIFhtyja+mi1OznQ/r4Cuured1jNW0RJXsH8q+Tvhao+6FU0PlD9kIjoMewMyPjqewQnOw9ePpSMmCWqPbt/izcbNNe+V3wwTDFuQH5mbp9k/ZFBGV7VnVBKsyv8q7JAuOiH0tfkQQKBON83/NxuBoG7WK+z0sCOhq82sVOT+q2JjeCzh3WamX4qwCNEACum7dfo6mqG4X0G1WkZgy1U+jZoL0kB2V03N/TNh/5BFifUp/MWaPr4x12q3W3Op9QT4wwiuJlPtJ1IA2F0rMr5w0ZJBIPNLlPvwcUloxjXySXiz06mn1T3TCKnRwa7KvQeiS/FvPjSgg6Ws+DjWEbpXzvtzDUJy3ShlTiKOciHrFu156y2vpJ7KZx5GeqkVZ2x0mmz/O2ERxYHiT7fsykmPx37X0HrTuSjRy7dfNvAPgfDVkpsqaDDf+PWzfuSc9iS5iZBfGfxghRvbGqAL4OIWTSFB+K6J8ZpEEXmfZK5gmwHl6WZ58jocuNCNCCORzaUH7A9hhTF4BIylHTTsksB0MIgaNWj1+G51fWZ4gDxI8dLGaKL+YKvNIrRbCWugy6mHFt72JOOxPXwoMzzDMgYYmftZUvMwDLDGMVX1Pu7KMLJOxBOedkLvifKjsnn4bEVZ8Gq7fKJ8mqem1ndTZOkhApNrjcPYuvj8x9t95e2bqJNEtgFRYfHHdKrTfryPzoN7xdqARWWAVCkLbqHDrCneCYuaCqG6yzi/+BDzDqe+30nAB+USeb1AbEXjKgBHMrOxSBfalNd48pwIDAQAB";
    private static final String cent_server_m_public_key_x509_encoded_base64="MIIEIjANBgkqhkiG9w0BAQEFAAOCBA8AMIIECgKCBAEAxP4tKQ78g1mRPlClM0PVoV3iDhAtcenNNHMycjyqucKiekIQReL/2v/BHSYeZI/LT+gXUOHtafc92CwbVFevRKKL26JFksKF39b3CQUUgPB16B9qqUokLBgrDrxY/v3BBHIAGz2O0G+LVymkJSIKZeoEjYckb3NYSwhg635L095oJxX7kIJnKTbolLfs+omRXfeCWpHEL7uRrTjC1ImmoGmltp7QYG5777BEA7eaO5xVIz62xskGvvVlUyRTHN+2pUKut7BwPIbVUOqpl5qivqx446WWNKniCq5QLXAVoR+/Xw3u5um8JnW5LyH1X7K0/+Xm3bVdpR/O754g01mHzz1Lmxg1sJrVWEccBfyAfDpSAZfnqNHf3gx2ZhWfeSD7229lzRMHY3P876P1CqXgZ9zNsaX5rhfefMkdfrtdL6KbZ8Z1dZx+5qrKUj9wuQAza577Iw+zHrbqdLieU5tFwwCPbz6VC4BQ8W7djwW+SiHJbah9UtEcNx7wyUCmWmd3RxAwqzvjn4RaXtD5UW4MeCOVCIZ4m8Q/zl+wBWaDh4jvGlIeYJVzJw+H3O+wvQgyj2VVKhPmlprPfdK0/Wbv2eele1qN7WZb03sGWzbF0quNpQOX0bTHH5Q9n+Q84bZn2RtteUGPs4txqAc5VF41UyQOCdilDJC5S1tth9jfaeV11AZ54j8s10pzLT2or01r/ptHcPK049ANV7R1zbLkrTFX3EYDw68BbYmkE2+f4iBK0qBavKWYoGvjsjZshzFdwAo676XtFm99HWFVa7MFDf0WkBFSGTp3c6rYLYZuArmYzlU6bsNww7CjqphuPudEGQX762HY6/dpfeGtfC2LoaTrEVLVHlLjxutKRVqgGX2hX5A/BfwxQ8oKrpIQGXytCTa0SYCeiLK0JakRAGCOQLvuqv2ORjv7Hg5sD6jBfbQeGnIQCQL/fNumotwsXXPlbtDZW4v3qXI9BNUSDg8zpyw1tQmkhgQnDKgOSG2iBiRxO2SgfETmDgPQhGFpjEO4wxybCWzpkVOhIMoCVkpfKWihxXNT97n1dbsAMGwPK20baiw4IlOunL0Ig6ue2NrOUIUNvHCpdaYpPAwlOX30xfLf3ykWhk/+0KSEwRG+YxZOZdmx41c/a5XuGZZnfNplGZEA2eA2Y2NRfnNMrEDLNWWmcO/eOxWtdUVsQY6IGjZS03GG3cSUiAGbptzJSpZJcy7yL6PGmQAlRMZwxgxT54OSOOnORaKyWOTeeBW5wkAwrAA0euxKkSSnh+CkTZGmUYDzvvOJf4ZoAyshc6Dj84KVMOhiWeXRLGYHy3b/W62yKSb+s2ny0anL67YTCVL6WnIhvIX/Car6qLs1wqxVDQIDAQAB";
    private static RSAPublicKey m_public_key;
    public static final short server_dynamic_RSA_byte_size =(short) Math.pow(2,8);
    public static final short server_RSA_mother_byte_size=(short) Math.pow(2,10);
    public static RSAPublicKey current_vpn_server_RSA_public_key;
    private static MessageDigest sha_digest;
    public static Random random=new SecureRandom();
    private static byte[] pelpel_tond(){
        byte[] bytes=new byte[16];
        random.nextBytes(bytes);
        return bytes;
    }
    public static RSAPublicKey get_m_public_key() throws Throwable {
        if(m_public_key==null){
            m_public_key=
                    (RSAPublicKey) KeyFactory.getInstance("rsa").generatePublic(new X509EncodedKeySpec(
                    Base64.decode(cent_server_m_public_key_x509_encoded_base64,Base64.DEFAULT)
            ));
        }
        return m_public_key;
    }
    public static RSAPublicKey get_latest_dynamic_cent_server_public_key() throws NoSuchAlgorithmException, InvalidKeySpecException {
        return com.paranoia.zharftor.app_data_and_preferences.getInstance().getCent_server_dynamic_public_key();
    }
    public static symmetric_key_and_id get_client_id_and_symmetric_key() throws NoSuchAlgorithmException, InvalidKeySpecException {
        return com.paranoia.zharftor.app_data_and_preferences.getInstance().get_client_id_and_symmetric_key();
    }
    public static class symmetric_key_and_id{
        public byte[] symmetric_key,id;
    }
    public static class server_client_key_combo{
        public Encryption_IV_Key client_keys,server_keys;
        public byte[] pepper;
    }
    public static server_client_key_combo negotiate_keys_with_server(Socket socket) {
        server_client_key_combo combo = new server_client_key_combo();
        combo.client_keys = new Encryption_IV_Key();
        combo.server_keys = new Encryption_IV_Key();
        combo.client_keys.Key = new SecretKeySpec(new byte[32], "AES");
        combo.client_keys.IV = new IvParameterSpec(new byte[16]);
        combo.server_keys.Key = new SecretKeySpec(new byte[32], "AES");
        combo.server_keys.IV = new IvParameterSpec(new byte[16]);
        return combo;
    }
    public static server_client_key_combo generate_symmetric_keys(key_manager.symmetric_key_and_id ski) {
        byte[] pepper=pelpel_tond();
        try {
            sha_digest=MessageDigest.getInstance("SHA-512");
        } catch (NoSuchAlgorithmException e) {
//            e.printStackTrace();
        }
        sha_digest.update(ski.symmetric_key);
        sha_digest.update(pepper);
        byte[] d1=sha_digest.digest();
        sha_digest.update(pepper);
        sha_digest.update(ski.symmetric_key);
        byte[] d2=sha_digest.digest();
        server_client_key_combo combo = new server_client_key_combo();
        combo.client_keys = new Encryption_IV_Key();
        combo.server_keys = new Encryption_IV_Key();
        combo.client_keys.Key = new SecretKeySpec(d1,0,32, "AES");
        combo.client_keys.IV = new IvParameterSpec(d1,32,16);
        combo.server_keys.Key = new SecretKeySpec(d2,0,32, "AES");
        combo.server_keys.IV = new IvParameterSpec(d2,32,16);
        combo.pepper=pepper;
        return combo;
    }
    public static byte[] generate_random_symmetric_key(){
        byte[] x=new byte[16];
        utils.bytes_integrator integrator=new utils.bytes_integrator();
        Random r=new SecureRandom();
        integrator.add_bytes(
                utils.long_to_bytes(Math.abs(r.nextLong()),8)
        ).add_bytes(
                utils.long_to_bytes(Math.abs(r.nextLong()+System.currentTimeMillis()),8)
        );
        try {
            MessageDigest messageDigest=MessageDigest.getInstance("sha256");
            messageDigest.update(integrator.integrate_to_bytes());
            System.arraycopy(messageDigest.digest(),0,x,0,16);
        } catch (NoSuchAlgorithmException e) {
//            e.printStackTrace();
        }
        return x;
    }
}