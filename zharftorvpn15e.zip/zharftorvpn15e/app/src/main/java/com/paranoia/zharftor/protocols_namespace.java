package com.paranoia.zharftor;

public class protocols_namespace {
    public static class IP{
        public static final int TCP_PROTOCOL_NUMBER=6,UDP_PROTOCOL_NUMBER=17,CUSTOM_TCP_UDP_COMB_PROTOCOL_NUMBER=83;
        public static final byte DO_NOT_FRAGMENT=2,MORE_FRAGMENTS=1;//we number from right to left

    }
    public static class tcp{
        public static final int flag_syn=0x2,flag_rst=0x4,flag_fin=0x1,flag_ack=0x10,flag_psh=0x8,flag_ece=0x40,flag_urg=0x20,flag_ns=0x100,flag_cwr=0x80;
    }
}
