package com.paranoia.zharftor.proto;
import com.paranoia.zharftor.app_data_and_preferences;
import com.paranoia.zharftor.utils;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class PingTask{
    public static Integer set_delay_milis(app_data_and_preferences.server_details server) {
        BufferedReader inputStream=null;
        try {
            String command = "/system/bin/ping -c 1 " + utils.byte_to_regex_seprated_string(server.ip,".");
            Process process = Runtime.getRuntime().exec(command);

            inputStream = new BufferedReader(new InputStreamReader(process.getInputStream()));
            server.latency=-1;
            String outputLine;
            while ((outputLine = inputStream.readLine()) != null) {
                if (outputLine.contains("time=")) {
                    int startIndex = outputLine.indexOf("time=");
                    int endIndex = outputLine.indexOf("ms", startIndex);
                    if (startIndex != -1 && endIndex != -1) {
                        String latencyString = outputLine.substring(startIndex + 5, endIndex).trim();
                        try {
                            server.latency = Float.valueOf(latencyString).intValue();
                        } catch (NumberFormatException e) {
                            e.printStackTrace();
                        }
                    }
                    break;
                }
            }
            return server.latency;
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            if(inputStream!=null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
        return -1;
    }
}