package com.paranoia.zharftor.proto;

//import static com.paranoia.zharftor.vpn_service.tcp_cons;
import static com.paranoia.zharftor.vpn_service.tun_buffer_distributer_packet_out_buffer_udp;
//import static com.paranoia.zharftor.vpn_service.udp_cons;

import android.util.Log;

import com.paranoia.zharftor.utils;
import com.paranoia.zharftor.vpn_service;

public class udp{
    public long dst_port,src_port;
    private static final int read_access_id=0xfffff;
    public int pure_data_len =0,dbg_total_upload=0, total_download =0;
    public utils.cirular_buffer_reader_writer server_buffer_reader_writer;
    public utils.cirular_buffer_reader_writer client_buffer_reader_writer;
    public udp(int buffer_size){
        if(buffer_size!=-1) {
            server_buffer_reader_writer = new utils.cirular_buffer_reader_writer(buffer_size);
            client_buffer_reader_writer=new utils.cirular_buffer_reader_writer(0x10000);//only for fragmented packets
        }
    }
    public int current_fragment_offset_packet_out, total_payload_size_packet_out,total_transmitted_packet_out;
}
