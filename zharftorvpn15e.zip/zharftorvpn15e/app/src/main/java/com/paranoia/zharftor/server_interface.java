package com.paranoia.zharftor;

import com.paranoia.zharftor.poshan.key_manager;
import com.paranoia.zharftor.poshan.encryption_layer;
import com.paranoia.zharftor.poshan.rsa_core;

import java.io.IOException;
import java.nio.channels.ClosedChannelException;
import java.nio.channels.SocketChannel;
import java.security.KeyFactory;
import java.security.SecureRandom;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.util.Arrays;
import java.util.Random;

public class server_interface {
    public static final byte version_0=0,
            COMMAND_SET_KEY=0,
            COMMAND_GET_KEYS=1,
            COMMAND_UPDATE=2,
            RESPONSE_KEY=0,
            RESPONSE_RSA_KEY_HAS_BEEN_UPDATED=1,
            RESPONSE_NO_KEY_WITH_SUCH_ID=2,
            RESPONSE_KEY_HAS_BEEN_ADDED=3;
    private static server_interface instance;
    public static  String server_domain_name = null;
    public static  int server_port = 999;
    public long t = 0;
    private SocketChannel protected_socket;
    private boolean force_shutdown = false;
    private static request req1;
    private static request req0;
    private static request req2;
    private static request req3;
    private static request req4;
    private static request req5;
    private static request req_minus_1;


    int total_sent=0;
    int read_size = 0;

    private final utils.pointed_byteArray tmp_server_data = new utils.pointed_byteArray(0x10000);
    private final one_task_one_thread sr=new one_task_one_thread(), rd=new one_task_one_thread();
    private static final com.paranoia.zharftor.response res = new com.paranoia.zharftor.response();

    socket_closed_exception sock_closed_e = new socket_closed_exception();
    public static class socket_closed_exception extends IOException {
        @Override
        public void printStackTrace() {
//            Log.d("server Exception", "socket is closed");
        }
    }
    private final Runnable response_decoder = new Runnable() {
        @Override
        public void run() {
            while (!force_shutdown&&!Thread.currentThread().isInterrupted()) {
                try {
                    process_next_response();
                }catch(java.lang.InterruptedException e){
//                    e.printStackTrace();
                    break;
                } catch (Throwable throwable) {
//                    throwable.printStackTrace();
                    //Log.d("exception","at decoder "+ res.response);
                    cipher_block_remainder =(int)(res.size%16);
                    if(cipher_block_remainder ==0) cipher_block_remainder =16;
                    res.data.move_offset_presumptiously(last_response_offset,(int)(res.size+(16- cipher_block_remainder)));
                }
            }
        }
    };
    private final Runnable server_reciever = new Runnable() {
        @Override
        public void run() {
            while (!Thread.currentThread().isInterrupted()&&!force_shutdown) {
                try {
                    read_from_server_decrypt_write_to_buffer(protected_socket, res.data);
                } catch (IOException e) {
                    try {
                        protected_socket.close();
                        vpn_service.vpn.reset_vpn();
                        break;
                    } catch (IOException ioException) {
//                        ioException.printStackTrace();
                    }
                    break;
                }catch (Throwable e){
//                    e.printStackTrace();
                }
            }
            shutdown();
        }
    };
    public static server_interface getInstance() {
        if (instance == null) {
            instance = new server_interface();
        }
        return instance;
    }
    private Random random=new SecureRandom();
    private utils.pointed_byteArray tmp_buffer =new utils.pointed_byteArray(4096);
    public void negotiate_keys() throws Throwable{
        key_manager.symmetric_key_and_id ski=key_manager.get_client_id_and_symmetric_key();
        if(ski==null){//register key
            byte[] symmetric_key=key_manager.generate_random_symmetric_key();
            byte[] tmp=com.paranoia.zharftor.poshan.rsa_core.rsa_with_random(
                    symmetric_key,key_manager.get_latest_dynamic_cent_server_public_key(),
                    Math.abs(random.nextLong()));

            tmp_buffer.buffer[0]=0;//version
            tmp_buffer.buffer[1]=COMMAND_SET_KEY;
            System.arraycopy(app_data_and_preferences.getInstance().get_dynamic_key_modulus_sig()
                    ,0, tmp_buffer.buffer,2,4);//modulus sig
            System.arraycopy(tmp,0, tmp_buffer.buffer,6,tmp.length);//encrypted key
            tmp_buffer.end=2+4+tmp.length; tmp_buffer.byteBuffer.limit(tmp_buffer.end);
            tmp_buffer.offset=0;
            tmp_buffer.byteBuffer.position(tmp_buffer.offset);
            protected_socket.write(tmp_buffer.byteBuffer);
            utils.read_pricesly_n_bytes_to_buffer(protected_socket.socket().getInputStream(), tmp_buffer,2);
            if(tmp_buffer.buffer[0]==version_0){
                if(tmp_buffer.buffer[1]==RESPONSE_KEY_HAS_BEEN_ADDED){
                    utils.read_pricesly_n_bytes_to_buffer(protected_socket.socket().getInputStream(), tmp_buffer,key_manager.server_dynamic_RSA_byte_size);
                    tmp=Arrays.copyOfRange(rsa_core.rsa(tmp_buffer,key_manager.current_vpn_server_RSA_public_key),tmp.length-10,tmp.length);
                    app_data_and_preferences.getInstance().set_client_id_and_symmetric_key(symmetric_key,tmp);
                    negotiate_keys();
                    return;
                }
                if(tmp_buffer.buffer[1]==RESPONSE_RSA_KEY_HAS_BEEN_UPDATED){
                    app_data_and_preferences.getInstance().load_essentials();
                    vpn_service.vpn.shut_down();
                }
            }
        }else{//identify by id
            long rand=Math.abs(random.nextLong());
            tmp_buffer.buffer[0]=0;//version
            tmp_buffer.buffer[1]=COMMAND_GET_KEYS;
            byte[] pip=new byte[26],encrypted_pepper_and_id;

            System.arraycopy(ski.id
                    ,0,pip,0,10);//connection record id

            encryption_keys=key_manager.generate_symmetric_keys(ski);
            System.arraycopy(encryption_keys.pepper,0,pip,10,16);//pepper
            encrypted_pepper_and_id= rsa_core.rsa_with_random(pip,key_manager.current_vpn_server_RSA_public_key,rand);
            System.arraycopy(encrypted_pepper_and_id,0, tmp_buffer.buffer,2,encrypted_pepper_and_id.length);//pepper
            tmp_buffer.end=2+encrypted_pepper_and_id.length; tmp_buffer.byteBuffer.limit(tmp_buffer.end);
            tmp_buffer.offset=0;
            tmp_buffer.byteBuffer.position(tmp_buffer.offset);
            protected_socket.write(tmp_buffer.byteBuffer);
            utils.read_pricesly_n_bytes_to_buffer(protected_socket.socket().getInputStream(), tmp_buffer,2);
            if(tmp_buffer.buffer[0]==version_0){
                if(tmp_buffer.buffer[1]==RESPONSE_KEY){
                    return; //connection is secured
                }
                if(tmp_buffer.buffer[1]==RESPONSE_NO_KEY_WITH_SUCH_ID){
                    utils.read_pricesly_n_bytes_to_buffer(protected_socket.socket().getInputStream(), tmp_buffer,7);
                    if(Arrays.equals(
                            utils.long_to_bytes(rand,7),
                            Arrays.copyOfRange(tmp_buffer.buffer,0,7)
                    )){
                        app_data_and_preferences.getInstance().unset_client_id_and_symmetric_key();
                        vpn_service.vpn.shut_down();
                    }
                }
            }
        }
    }
    private synchronized void write_to_server(request req) {
        try {
            req.bbuffer.position(req.data.offset);
            req.bbuffer.limit(req.data.end);
            req.size = req.data.end - req.data.offset;
            total_sent=req.size+total_sent;
            server_enc_io.write(req.data);
        }catch (ClosedChannelException e){
            vpn_service.close_protected_socket();
            shutdown();
        }
        catch (Throwable e) {
//            e.printStackTrace();
        }
    }
    public void shutdown() {
        force_shutdown=true;
        if(rd!=null&&sr!=null) {
            rd.interrupt();
            sr.interrupt();
        }
        res.data.wipe_data();
    }

    public void send_version_and_random_bytes(){//called once at the
        if(req_minus_1 ==null) req_minus_1 =new request();
        req_minus_1.version=request.VERSION_PACKET_FORWARD;
        req_minus_1.command=request.COMMAND_VERSION_SET_AND_RANDOM_BYTES;
        req_minus_1.serialize();
        write_to_server(req_minus_1);
    }
    public void send_raw_packet(utils.pointed_byteArray packet) {
        if (req5 == null) req5 = new request();
        req5.version = request.VERSION_PACKET_FORWARD;
        req5.command=request.COMMAND_RAW_PACKET;
        req5.data = packet;
        req5.serialize();
        write_to_server(req5);
    }
    public void send_data(int connection_id, utils.pointed_byteArray data, short flags, int protocol) {
        if (req0 == null) req0 = new request();
        req0.version = request.VERSION_PACKET_INTERPRET_2;
        if (protocol == protocols_namespace.IP.TCP_PROTOCOL_NUMBER)
            req0.command = request.COMMAND_FORWARD_DATA_TCP;
        if (protocol == protocols_namespace.IP.UDP_PROTOCOL_NUMBER) {
            req0.command = request.COMMAND_FORWARD_DATA_UDP;
//             Log.d("udp data from id ",connection_id+ " data: "+new String(data.buffer,data.offset,data.end));
        }
        req0.id = connection_id;
        req0.data = data;
        req0.flags = flags;
        req0.serialize();
        write_to_server(req0);
    }
    public void make_new_connection(int connection_id, byte[] ip, int port, int protocol) {
        if (req1 == null) req1 = new request();
        req1.version = request.VERSION_PACKET_INTERPRET_2;
        if (protocol == protocols_namespace.IP.TCP_PROTOCOL_NUMBER)
            req1.command = request.COMMAND_CONNECT_TCP;
        if (protocol == protocols_namespace.IP.UDP_PROTOCOL_NUMBER)
            req1.command = request.COMMAND_CONNECT_UDP;
        req1.id = connection_id;
        req1.dst_ip = ip;
        req1.dst_port = port;
        req1.serialize();
        write_to_server(req1);
//        Log.d("action", "opened con " + " id: " + req1.id+" dst: "+utils.byte_to_regex_seprated_string(req1.dst_ip,"."));
    }
    private key_manager.server_client_key_combo encryption_keys;
    private encryption_layer server_enc_io;
    public void init_interface()throws Throwable {
        encryption_keys=null;
        protected_socket = com.paranoia.zharftor.vpn_service.get_protected_socket();
        if (protected_socket.isConnected()) {
            protected_socket.socket().setSoTimeout(2000);
            //read public key of vpn server
            utils.read_pricesly_n_bytes_to_buffer(protected_socket.socket().getInputStream(), tmp_buffer,2);
            utils.read_pricesly_n_bytes_to_buffer(protected_socket.socket().getInputStream(), tmp_buffer,(int)utils.bytes_to_unsigned_long(tmp_buffer.buffer,0,2)-2);
            key_manager.current_vpn_server_RSA_public_key =(RSAPublicKey) KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(
                    Arrays.copyOfRange(tmp_buffer.buffer, tmp_buffer.offset, tmp_buffer.end)
            ));
            //negotiate keys and set up encryption layer
//            encryption_keys=key_manager.negotiate_keys_with_server(protected_socket.socket());
            vpn_service.activity.set_App_connection_status_non_ui_thread(main.CONNECTION_STATUS_EXCHANGING_KEYS);
            negotiate_keys();
            if(encryption_keys==null)return;
            force_shutdown=false;
            protected_socket.socket().setSoTimeout(0);
            server_enc_io=new encryption_layer(encryption_keys,protected_socket);
            send_version_and_random_bytes();
            sr.start(server_reciever);
            rd.start(response_decoder);
        }
    }

    public void read_from_server_decrypt_write_to_buffer(SocketChannel channel, utils.cirular_buffer_reader_writer buffer) throws Throwable {
//         if (go_to_debug)
//             return;
        read_size = buffer.get_available_empty_space_for_writing();
        if (read_size > tmp_server_data.buffer.length) read_size = tmp_server_data.buffer.length;
        tmp_server_data.end=read_size;
        tmp_server_data.offset=0;
        server_enc_io.read(tmp_server_data);
//        tmp_server_data.byteBuffer.position(0);
//        tmp_server_data.byteBuffer.limit(read_size);
//        tmp_server_data.end = channel.read(tmp_server_data.byteBuffer);
//         byte[] bytes_debug= Arrays.copyOfRange(tmp_server_data.buffer,0,tmp_server_data.end);
//         debug_incoming_responses_list.add(bytes_debug);
        if (tmp_server_data.end == -1) throw sock_closed_e;
//        tmp_server_data.offset = 0;
        synchronized (res.data) {
            buffer.write(tmp_server_data);
            res.data.notifyAll();
        }
//         if (this.buffer.end + tmp_server_data.end < this.buffer.buffer.length)
//             this.buffer.write(tmp_server_data);
    }
    private int last_response_offset;
    public void process_next_response() throws InterruptedException {
        if (res.data.get_available_data_length() == 0) {
            synchronized (res.data){
                res.data.wait();
            }
        }
        last_response_offset=res.data.offset;
        res.version = res.data.read_next_number(1);//version

//        tmp_last_command_offset = res.data.offset - 1;
        if (res.version == response.VERSION_0||
                res.version == response.VERSION_1||res.version == response.VERSION_2) {
            res.response = res.data.read_next_number(1);//response code
            if (res.response == com.paranoia.zharftor.response.RESPONSE_CLOSE_CONNECTION) {
                res.size = 5;
                res.id = res.data.read_next_number(3);//read id
//                com.paranoia.zharftor.vpn_service.vpn.On_server_closed_tcp_connection((int) res.id);
            }
            if (res.response == response.RESPONSE_TCP_CONNECTION_STATE_INFORMATION) {
                res.size = 6;
                res.id = res.data.read_next_number(3);//read id
                res.state= (byte)res.data.read_next_number(1);//read state
//                com.paranoia.zharftor.vpn_service.vpn.On_server_openness_state_response((int) res.id,res.state);
            }
            if (res.response == com.paranoia.zharftor.response.RESPONSE_DATA_TCP || res.response == com.paranoia.zharftor.response.RESPONSE_DATA_UDP) {
                res.size = res.data.read_next_number(2);//read size
                res.id = res.data.read_next_number(3);//read id
                res.data.read_data((int) res.size - 7);//read data
                if (res.response == response.RESPONSE_DATA_TCP)
                    res.protocol = protocols_namespace.IP.TCP_PROTOCOL_NUMBER;
                if (res.response == response.RESPONSE_DATA_UDP)
                    res.protocol = protocols_namespace.IP.UDP_PROTOCOL_NUMBER;
                try {
//                    com.paranoia.zharftor.vpn_service.vpn.On_server_response_data_recieved((int) res.id, res.data.current_data_portions, res.protocol);

                } catch (Exception e) {
                }
                res.data.mark_read();
            }
            if (res.response == response.RESPONSE_SET_ADS_NETWORK) {
                res.size = 16;
                main_with_ads.ad_network_index=(byte)res.data.read_next_number(1);
                try{
                    app_data_and_preferences.getInstance().update_prefered_ad_network_index();
                }catch (Throwable t){}
            }
            if (res.response == response.RESPONSE_RAW_PACKET) {
                res.size = res.data.read_next_number(2);//read size
                res.data.read_data((int) res.size - 4);//read data
                try {
                    com.paranoia.zharftor.vpn_service.vpn.route_packet_to_device(res.data.current_data_portions);
                } catch (Exception e) {
                }
                res.data.mark_read();
            }
            if (res.response == response.RESPONSE_SET_IP) {
                res.size = 7;
                res.data.read_data(4);//read data
                System.arraycopy(res.data.current_data_portions.buffer,
                        res.data.current_data_portions.offset,vpn_service.virtual_network_ip,0,4);
                res.data.mark_read();
                vpn_service.virtual_network_subnet=(byte)res.data.read_next_number(1);
                vpn_service.is_ready_for_tun_creation=true;
            }
            if(res.response>7){
                shutdown();
                vpn_service.vpn.shut_down();
            }
        }else {
            shutdown();
            vpn_service.vpn.shut_down();
        }
        cipher_block_remainder =(int)(res.size%16);
        if(cipher_block_remainder ==0) cipher_block_remainder =16;
        res.data.move_offset_presumptiously(last_response_offset,(int)(res.size+(16- cipher_block_remainder)));
        //Log.d("response ",res.response+" id: "+res.id);
    }
    private int cipher_block_remainder;
}