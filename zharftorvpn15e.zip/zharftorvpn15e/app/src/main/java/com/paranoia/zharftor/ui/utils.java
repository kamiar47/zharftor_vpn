package com.paranoia.zharftor.ui;

import java.util.regex.Pattern;

public class utils {
    public static int validation_error_empty_string=-1,validation_error_port_out_of_range=-2,
            validation_error_invalid_characters=-3,validation_error_invalid_ip_value=-4,valid=0;
    public static int validation_mode_port=1,validation_mode_ip_address=2;
    public static int validate_input(int mode,String s){
        if(s==null)return validation_error_empty_string;
        if(s.length()==0)return validation_error_empty_string;
        if(mode==validation_mode_port){
            int port=Integer.valueOf(s);
            if(port<0||port>0xffff)return validation_error_port_out_of_range;
        }
        if(mode==validation_mode_ip_address){
//            if(s.contains(" ")||s.contains(",")||s.contains("/"))return validation_error_invalid_characters;
            if (!s.matches(
                    "^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$"
            ))return validation_error_invalid_ip_value;
        }
        return valid;
    }
    public static String ip_long_to_string(long ip){
        return com.paranoia.zharftor.utils.byte_to_regex_seprated_string(com.paranoia.zharftor.utils.long_to_bytes(ip,4),".");
    }
}
