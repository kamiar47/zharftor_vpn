package com.paranoia.zharftor.ui;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.paranoia.zharftor.R;
import com.paranoia.zharftor.app_data_and_preferences;
import com.paranoia.zharftor.main;
import com.paranoia.zharftor.one_task_one_thread;
import com.paranoia.zharftor.proto.PingTask;
import com.paranoia.zharftor.server_interface;
import com.paranoia.zharftor.utils;
import com.paranoia.zharftor.vpn_service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class servers_adapter extends RecyclerView.Adapter <servers_adapter.holder>{
    private main main_activity;
    private boolean user_has_selected_item=false;
    public servers_adapter(main main_activity){
        this.main_activity=main_activity;
    }
    @NonNull
    @Override
    public holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new holder(LayoutInflater.from(parent.getContext()).inflate(R.layout.server_item,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull holder holder, int position) {
        holder.country.setText(
                com.paranoia.zharftor.ui.country_codes.get_city_and_country_by_code(
                        app_data_and_preferences.getInstance().servers.get(position).extra));
        holder.flag.setImageBitmap(country_codes.flags.get(holder.country.getText().toString().split(" ")[0].toLowerCase(Locale.ROOT)));
        holder.ip.setText(utils.byte_to_regex_seprated_string(
                app_data_and_preferences.getInstance().servers.get(position).ip,"."));
        holder.port.setText(String.valueOf(app_data_and_preferences.getInstance().servers.get(position).port));
        set_server_strength(holder,position);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                user_has_selected_item=true;
                server_interface.server_domain_name=holder.ip.getText().toString();
                server_interface.server_port=Integer.valueOf(holder.port.getText().toString());
                vpn_service.selected_server_details =app_data_and_preferences.getInstance().servers.get(position);
                main_activity.app_ui_state =main.UI_STATE_MAIN;
                main_activity.set_ui_state(main_activity.app_ui_state);
                main_activity.stop_vpn_connection();
            }
        });
    }
    private void set_server_strength(holder holder,int position){

        if( app_data_and_preferences.getInstance().getServers().get(position).latency==-1){
            holder.strength.setVisibility(View.GONE);
            return;
        }
        holder.strength.setVisibility(View.VISIBLE);
        if( app_data_and_preferences.getInstance().getServers().get(position).latency>=140||
                app_data_and_preferences.getInstance().getServers().get(position).latency==-1){
            holder.strength.setImageDrawable(vpn_service.activity.getResources().getDrawable(R.drawable.antenna_weak));
//            holder.strength.setBackgroundColor(vpn_service.activity.getResources().getColor(R.color.red_uc));
            return;
        }
        if( app_data_and_preferences.getInstance().getServers().get(position).latency>=70){
            holder.strength.setImageDrawable(vpn_service.activity.getResources().getDrawable(R.drawable.antenna_half));
//            holder.strength.setBackgroundColor(vpn_service.activity.getResources().getColor(R.color.yellow_uc));
            return;
        }
        if( app_data_and_preferences.getInstance().getServers().get(position).latency<70){
            holder.strength.setImageDrawable(vpn_service.activity.getResources().getDrawable(R.drawable.antenna_full));
//            holder.strength.setBackgroundColor(vpn_service.activity.getResources().getColor(R.color.green_c));
            return;
        }


    }

    @Override
    public int getItemCount() {
        return app_data_and_preferences.getInstance().servers.size();
    }

    public class holder extends RecyclerView.ViewHolder{
        public TextView ip,port,country;
        public ImageView flag,strength;
        public holder(View view){
            super(view);
            strength=view.findViewById(R.id.server_strength_field);
            flag=(ImageView)view.findViewById(R.id.country_flag_field);
            ip=view.findViewById(R.id.ip_field);
            port=view.findViewById(R.id.port_field);
            country=view.findViewById(R.id.country_field);
        }
    }

    @Override
    public void onViewRecycled(@NonNull holder holder) {
        super.onViewRecycled(holder);
        holder.country.setText("");
        holder.ip.setText("");
        holder.flag.setImageBitmap(null);
        holder.port.setText("");
        holder.strength.setVisibility(View.GONE);

    }
    private one_task_one_thread sdl=new one_task_one_thread();
    public void load_servers_delays(){
        new Thread(new Runnable() {
            @Override
            public void run() {

                if(vpn_service.is_connected()){
                    sdl.interrupt();
                }
                sdl.start_kill_previous(new Runnable() {
                    @Override
                    public void run() {
                        List<app_data_and_preferences.server_details> psl=new ArrayList<>();
                        while (!Thread.currentThread().isInterrupted()) {
                            psl.removeAll(psl);
                            psl.addAll(app_data_and_preferences.getInstance().getServers());
                            int i = 0;
                            while (i < app_data_and_preferences.getInstance().getServers().size()) {
                                PingTask.set_delay_milis(app_data_and_preferences.getInstance().getServers().get(i));
                                i++;
                            }
                            if(vpn_service.is_connected()){
                                app_data_and_preferences.getInstance().getServers().removeAll(app_data_and_preferences.getInstance().getServers());
                                app_data_and_preferences.getInstance().getServers().addAll(psl);
                                return;
                            }

                            Collections.sort(app_data_and_preferences.getInstance().getServers(), new Comparator<app_data_and_preferences.server_details>() {
                                @Override
                                public int compare(app_data_and_preferences.server_details server_details, app_data_and_preferences.server_details t1) {
                                    if (server_details.latency == -1) return Integer.MAX_VALUE;
                                    return Integer.compare(server_details.latency, t1.latency);
                                }
                            });
                            vpn_service.activity.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    if (!vpn_service.is_connected() && !vpn_service.is_connecting() && !user_has_selected_item) {
                                        vpn_service.selected_server_details = app_data_and_preferences.getInstance().servers.get(0);
                                        server_interface.server_domain_name = utils.byte_to_regex_seprated_string(
                                                app_data_and_preferences.getInstance().servers.get(0).ip, ".");
                                        server_interface.server_port = app_data_and_preferences.getInstance().servers.get(0).port;
                                        vpn_service.activity.set_main_page_flag_ui_thread();
                                    }
                                    notifyDataSetChanged();
                                }
                            });
                            try {
                                Thread.sleep(2000);
                            } catch (InterruptedException e) {
                                return;
                            }
//                vpn_service.activity.set_App_connection_status_non_ui_thread(vpn_service.activity.vpn_connection_state);
                        }
                    }
                });
            }
        }).start();
    }
    public void stop_loading_server_delays(){
        sdl.interrupt();
    }
}
