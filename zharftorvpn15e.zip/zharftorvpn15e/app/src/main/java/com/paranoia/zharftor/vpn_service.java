package com.paranoia.zharftor;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.VpnService;
import android.os.Build;
import android.os.IBinder;
import android.os.ParcelFileDescriptor;

import com.paranoia.zharftor.proto.ip;
import com.paranoia.zharftor.proto.ip_packet;
import com.paranoia.zharftor.proto.tcp;
import com.paranoia.zharftor.proto.udp;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.net.StandardSocketOptions;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Random;

public class vpn_service extends VpnService {
//    private Timer disconnection_timer;
//    public static byte[] dns_ip={(byte)77,(byte)88,(byte)8,(byte)7};
    public static byte[] dns_ip={(byte)8,(byte)8,(byte)8,(byte)8};
    public static byte[] virtual_network_ip=new byte[4];
    public static byte virtual_network_subnet;
    public static app_data_and_preferences.server_details selected_server_details=null;
    public static int dns_port =53;
    public static boolean is_ready_for_tun_creation=false;
    public static int TCP_TIMEOUT =3*60*1000
    ,UDP_TIMEOUT =60*1000
            ,DNS_TIMEOUT =10*1000;
    public static class unrecognized_protocol_exception extends Exception{}
    public static main activity;
    private Thread server_connection_maintainer_thread;
    private final utils.pointed_byteArray Tun_buffer_in=new utils.pointed_byteArray(0x10100);
    public static vpn_service vpn;
    public static boolean is_main_accessible=false;
    private short counter=0;
    public static boolean vpn_permission_granted=false;
    private FileInputStream TUNinputstream =null;
    private FileOutputStream TUNoutputstream=null;
    public boolean vpn_stopped=false, vpn_con_maintainer_running =false;
    public static utils.pointed_byteArray
            tun_processor_thread_packet_out_buffer=new utils.pointed_byteArray(2000),
            tun_buffer_distributer_packet_out_buffer_tcp =new utils.pointed_byteArray(2000),
            tun_buffer_distributer_packet_out_buffer_udp =new utils.pointed_byteArray(1600);
    private final ip_packet packet=new ip_packet();
    private utils.pointed_byteArray tun_packet_in=new utils.pointed_byteArray(1600);
    private void process_TUN_data(utils.pointed_byteArray bytes){
//        try {
////            dispatch_packet(bytes,packet);
//        } catch (vpn_service.unrecognized_protocol_exception unrecognized_protocol_exception) {
//            return;
//        }
        if(!app_data_and_preferences.getInstance().address_filters.
                complies_with_policies(utils.bytes_to_unsigned_long(bytes.buffer,16,4)
                        ,(int)utils.bytes_to_unsigned_long(bytes.buffer,22,2),
                        utils.byte_to_unsinged_long(bytes.buffer[9]))){
            if(utils.byte_to_unsinged_long(bytes.buffer[9])==protocols_namespace.IP.TCP_PROTOCOL_NUMBER) {
                try {
                    dispatch_packet(bytes,packet);
                } catch (unrecognized_protocol_exception e) {
                    e.printStackTrace();
                }
                generate_packet(packet, mode_tcp_reject, null, tun_processor_thread_packet_out_buffer);
                route_packet_to_device(tun_processor_thread_packet_out_buffer);
                //reject connection
            }
            return;
        }
        tun_packet_in.offset=50;
        System.arraycopy(bytes.buffer,0,tun_packet_in.buffer,tun_packet_in.offset,bytes.end-bytes.offset);
        tun_packet_in.end=tun_packet_in.offset+bytes.end;
        server_interface.getInstance().send_raw_packet(tun_packet_in);
    }
    private ip_packet packet_temp,packet_temp1;
    public synchronized void route_packet_to_device(utils.pointed_byteArray frame){
        try {
//            frame.byteBuffer.position(frame.offset);
//            frame.byteBuffer.limit(frame.end);
            TUNoutputstream.write(frame.buffer,frame.offset,frame.end-frame.offset);
//            TUNoutputstream.getChannel().write(frame.byteBuffer);
        } catch (Throwable e) {
//            e.printStackTrace();
        }
//        ip_packet resp=new ip_packet();
//        try {
//            dispatch_packet(frame,resp);
//            if(resp!=null) con_resp_mon.add(resp);
//        } catch (vpn_service.unrecognized_protocol_exception unrecognized_protocol_exception) {
//            unrecognized_protocol_exception.printStackTrace();
//        }
    }
    private void make_connection_on_server(ip_packet pack){
        if(pack.ip_header.protocol==protocols_namespace.IP.TCP_PROTOCOL_NUMBER)
            server_interface.getInstance().make_new_connection(pack.connection_id,pack.ip_header.dst_ip,(int)pack.tcp_segment.dst_port,protocols_namespace.IP.TCP_PROTOCOL_NUMBER);
        if(pack.ip_header.protocol==protocols_namespace.IP.UDP_PROTOCOL_NUMBER)
            server_interface.getInstance().make_new_connection(pack.connection_id,pack.ip_header.dst_ip,(int)pack.udp_datagram.dst_port,protocols_namespace.IP.UDP_PROTOCOL_NUMBER);
    }
    public static final Random random=new Random();
    public static final String mode_tcp_termination="mtt",mode_tcp_termination_acknowlege="mtta",mode_udp_data="udpd",
            mode_handshake_response="hs",mode_data_reception_ack="dca", mode_data_push ="du",mode_tcp_reset="mtr",mode_tcp_reject="mtrej";
    public static void generate_packet(ip_packet packet,String mode,utils.pointed_byteArray data,utils.pointed_byteArray buffer){
        ByteBuffer bbuffer=buffer.byteBuffer;
        bbuffer.limit(buffer.buffer.length-1);
        bbuffer.position(0);
        int ip_header_size=20;
        if(mode.equals(mode_handshake_response)||mode.equals(mode_data_reception_ack)||mode.equals(mode_data_push)||
        mode.equals(mode_tcp_termination_acknowlege)||mode.equals(mode_tcp_termination)||mode.equals(mode_tcp_reset)
                ||mode.equals(mode_udp_data)||
                mode.equals(mode_tcp_reject)) {
            //ip packet
            bbuffer.put((byte) (5 + 4 * 16));// version+ihl
            bbuffer.put((byte) 0);//type of service
            bbuffer.putShort((short) 0);//total length
            if(mode.equals(mode_udp_data))
                if(packet.udp_datagram.total_payload_size_packet_out >1472)//no need for packet id if its less than 1472 bytes
                    bbuffer.putShort((short) packet.ip_header.packet_id_outgoing);//identification
                else
                    bbuffer.putShort((short) 0);//identification
            else
                bbuffer.putShort((short) 0);//identification
            if(mode.equals(mode_udp_data))
                if(packet.udp_datagram.total_payload_size_packet_out >1472)
                    if((packet.udp_datagram.total_payload_size_packet_out-packet.udp_datagram.total_transmitted_packet_out)<=1480)
                        bbuffer.putShort((short) (0x0000+packet.udp_datagram.current_fragment_offset_packet_out));//flags and fragment offset
                    else
                        bbuffer.putShort((short) (0x2000+packet.udp_datagram.current_fragment_offset_packet_out));//flags and fragment offset
                else
                    bbuffer.putShort((short) 0x4000);//flags and fragment offset
            else
                bbuffer.putShort((short) 0x4000);//flags and fragment offset
            bbuffer.put((byte) 64);//time to live
            bbuffer.put((byte) packet.ip_header.protocol);//protocol
            bbuffer.putShort((short) 0);//header checksum
            bbuffer.put(packet.ip_header.dst_ip);//src ip addr //we are generating this for device
            bbuffer.put(packet.ip_header.src_ip);//dst ip addr
            ip_header_size=bbuffer.position();
        }
//            byte [] ip_header_size=bbuffer.integrate_to_bytes();
        if(mode.equals(mode_handshake_response)||mode.equals(mode_data_reception_ack)||mode.equals(mode_data_push)||
                mode.equals(mode_tcp_termination_acknowlege)||mode.equals(mode_tcp_termination)||mode.equals(mode_tcp_reset)||
                mode.equals(mode_tcp_reject)) {
            //tcp segment
            bbuffer.putShort((short)packet.tcp_segment.dst_port);//src port
            bbuffer.putShort((short) packet.tcp_segment.src_port);// dst port

            if(mode.equals(mode_tcp_reset)){
                bbuffer.putInt((int)packet.tcp_segment.last_generated_packet_seq);
                bbuffer.putInt((int)packet.tcp_segment.last_generated_ack);
            }
            if(mode.equals(mode_tcp_reject)){
                packet.tcp_segment.last_generated_packet_seq =0x0;//generate random sequence number
                bbuffer.putInt((int) packet.tcp_segment.last_generated_packet_seq);//seq
                packet.tcp_segment.last_generated_ack=utils.increament_syn_ack(packet.tcp_segment.seq_number,1);
                bbuffer.putInt((int)packet.tcp_segment.last_generated_ack);// ack
            }
            if(mode.equals(mode_tcp_termination)){
                bbuffer.putInt((int)packet.tcp_segment.last_generated_packet_seq);
                bbuffer.putInt((int)packet.tcp_segment.last_generated_ack);
            }
            if(mode.equals(mode_tcp_termination_acknowlege)){
                bbuffer.putInt((int)packet.tcp_segment.last_generated_packet_seq);
                bbuffer.putInt((int)packet.tcp_segment.last_generated_ack);
            }
            if(mode.equals(mode_handshake_response)){
                packet.tcp_segment.last_generated_packet_seq =random.nextInt()&0x0fffffff;//generate random sequence number
//                packet.tcp_segment.last_generated_packet_seq =1;//generate random sequence number
                bbuffer.putInt((int) packet.tcp_segment.last_generated_packet_seq);//seq
                packet.tcp_segment.last_generated_ack=utils.increament_syn_ack(packet.tcp_segment.seq_number,1);
                bbuffer.putInt((int)packet.tcp_segment.last_generated_ack);// ack
            }
            if(mode.equals(mode_data_reception_ack)){//now only buffer data distributer is in charge of updating seq number;
//                packet.tcp_segment.last_generated_packet_seq =packet.tcp_segment.ack_number;
                bbuffer.putInt((int)packet.tcp_segment.last_generated_packet_seq);
//                packet.tcp_segment.last_generated_ack=packet.tcp_segment.seq_number+packet.tcp_segment.data_length;
                //last generated ack already is made
                bbuffer.putInt((int)packet.tcp_segment.last_generated_ack);// ack
            }
            if(mode.equals(mode_data_push)){
                bbuffer.putInt((int)packet.tcp_segment.last_generated_packet_seq);//seq
                bbuffer.putInt((int)packet.tcp_segment.last_generated_ack);// ack
            }
            bbuffer.put((byte)0);//data offset+ reserved
            if(mode.equals(mode_tcp_reset)|| mode.equals(mode_tcp_reject)){
                bbuffer.put((byte)(com.paranoia.zharftor.protocols_namespace.tcp.flag_ack+ com.paranoia.zharftor.protocols_namespace.tcp.flag_rst));//flags
            }
            if(mode.equals(mode_tcp_termination)){
                bbuffer.put((byte)(com.paranoia.zharftor.protocols_namespace.tcp.flag_ack+ com.paranoia.zharftor.protocols_namespace.tcp.flag_fin));//flags
            }
            if(mode.equals(mode_tcp_termination_acknowlege)){
                bbuffer.put((byte)(com.paranoia.zharftor.protocols_namespace.tcp.flag_ack));//flags
            }
            if(mode.equals(mode_handshake_response)){
                bbuffer.put((byte)(com.paranoia.zharftor.protocols_namespace.tcp.flag_syn+ com.paranoia.zharftor.protocols_namespace.tcp.flag_ack));//flags
            }
            if(mode.equals(mode_data_reception_ack)){
                bbuffer.put(utils.long_to_bytes(com.paranoia.zharftor.protocols_namespace.tcp.flag_ack,1));//flags
            }
            if(mode.equals(mode_data_push)){
                bbuffer.put((byte)(com.paranoia.zharftor.protocols_namespace.tcp.flag_ack+ com.paranoia.zharftor.protocols_namespace.tcp.flag_psh));//flags
            }
            bbuffer.putShort((short) 0xfff);//window size
            bbuffer.putShort((short)0);//checksum
            bbuffer.putShort((short)0);//urgent pointer
            if(mode.equals(mode_handshake_response)){
                bbuffer.putInt(0x20405b4);//options //mss
            }
            //bytes_integrator.add_bytes();//padding
//            byte[] segment_offset=bbuffer.integrate_to_bytes();
            int segment_header_end=bbuffer.position();
            // replace 12th byte of segment
            utils.insert_int_to_bytes(buffer.buffer,ip_header_size+12,(segment_header_end-ip_header_size)/4*0x10,1);
            if(mode.equals(mode_data_push)){
                if(data==null){
                    buffer=null;
                    return;
                }else {
                    bbuffer.put(data.buffer,data.offset,data.end-data.offset);
                }
            }
            utils.insert_int_to_bytes(buffer.buffer,2,bbuffer.position(),2);
            utils.insert_int_to_bytes(buffer.buffer,10,utils.calculate_ones_complement_checksum(bbuffer,0,ip_header_size),2);//calculate and replace the checksum
            utils.insert_int_to_bytes(buffer.buffer,ip_header_size+16,utils.calculate_ones_complement_checksum_tcp(buffer.buffer,ip_header_size,bbuffer.position()),2);
            buffer.offset=0;buffer.end=bbuffer.position();
        }
        if(mode.equals(mode_udp_data)){
            if(packet.udp_datagram.current_fragment_offset_packet_out==0) {
                bbuffer.putShort((short) packet.udp_datagram.dst_port);//src port
                bbuffer.putShort((short) packet.udp_datagram.src_port);// dst port
                bbuffer.putShort((short) (packet.udp_datagram.total_payload_size_packet_out + 8));//size
                bbuffer.putShort((short) 0);//checksum
                bbuffer.put(data.buffer, data.offset, data.end - data.offset);
                bbuffer.put(data.buffer, data.secondary_offset, data.secondary_end - data.secondary_offset);
            }else{
                bbuffer.put(data.buffer, data.offset, data.end - data.offset);
                bbuffer.put(data.buffer, data.secondary_offset, data.secondary_end - data.secondary_offset);
            }
            utils.insert_int_to_bytes(buffer.buffer, 2, bbuffer.position(), 2);
            utils.insert_int_to_bytes(buffer.buffer, 10, utils.calculate_ones_complement_checksum(bbuffer, 0, ip_header_size), 2);//calculate and replace the checksum
            buffer.offset = 0;
            buffer.end = bbuffer.position();
        }
    }
    unrecognized_protocol_exception upe=new unrecognized_protocol_exception();
    private void dispatch_packet(utils.pointed_byteArray bytes,ip_packet ip_record)throws  unrecognized_protocol_exception{
        if (bytes.end < 20) throw upe;
//        ip_packet ip_record = new ip_packet();
        if(ip_record.ip_header==null)ip_record.ip_header = new ip();
        int ip_header_length=utils.byte_to_unsinged_long((byte)(0xf&bytes.buffer[0]))*4;
        long packet_length = utils.bytes_to_unsigned_long(bytes.buffer, 2, 2);
        if(packet_length!=bytes.end)throw upe;//for ipv4
        utils.replace_bytes_range(ip_record.ip_header.src_ip,0,bytes.buffer,12,4);
        utils.replace_bytes_range(ip_record.ip_header.dst_ip,0,bytes.buffer,16,4);
        ip_record.ip_header.packet_id = (int)utils.bytes_to_unsigned_long(bytes.buffer, 4, 2);

        ip_record.ip_header.packet_offset =utils.bytes_to_unsigned_long(bytes.buffer, 6, 2);//not so fast
        ip_record.ip_header.flags= (byte)(ip_record.ip_header.packet_offset>>13);
        ip_record.ip_header.packet_offset=ip_record.ip_header.packet_offset&0x1fff;

        ip_record.ip_header.protocol=(byte) utils.byte_to_unsinged_long(bytes.buffer[9]);
        if ( ip_record.ip_header.protocol== com.paranoia.zharftor.protocols_namespace.IP.TCP_PROTOCOL_NUMBER) {//tcp
            //int checksum=utils.calculate_ipv4_checksum(bytes.buffer);
            //long ip_checksum=utils.bytes_to_unsigned_long(utils.get_byte_subset(bytes.buffer,10,2));

            if(ip_record.tcp_segment==null)ip_record.tcp_segment = new tcp(0);
            ip_record.tcp_segment.src_port = utils.bytes_to_unsigned_long(bytes.buffer, ip_header_length, 2);//20
            ip_record.tcp_segment.dst_port = utils.bytes_to_unsigned_long(bytes.buffer, ip_header_length+2, 2);//22
            ip_record.tcp_segment.seq_number = utils.bytes_to_unsigned_long(bytes.buffer, ip_header_length+4, 4);//24
            ip_record.tcp_segment.ack_number = utils.bytes_to_unsigned_long(bytes.buffer, ip_header_length+8, 4);//28
            ip_record.tcp_segment.flags=utils.byte_to_unsinged_long(bytes.buffer[ip_header_length+13]);
            utils.replace_bytes_range(ip_record.tcp_segment.check_sum,0,bytes.buffer,ip_header_length+16,2);//36
//            long c0=utils.calculate_ones_complement_checksum(bytes_integrator
//                    .add_bytes(ip_record.ip_header.src_ip)
//                    .add_bytes(ip_record.ip_header.dst_ip)
//                    .add_bytes(utils.int_to_bytes(6,2))
//                    .add_bytes(utils.int_to_bytes(packet_length-ip_header_length,2))
//                    .add_bytes(utils.get_byte_subset(bytes.buffer,ip_header_length,(int)packet_length-ip_header_length))
//                    .integrate_to_bytes());
//            if(utils.calculate_ones_complement_checksum(bytes_integrator
//                    .add_bytes(utils.get_byte_subset(bytes.buffer,12,4))
//                    .add_bytes(utils.get_byte_subset(bytes.buffer,16,4))
//                    .add_bytes(utils.int_to_bytes(6,2))
//                    .add_bytes(utils.int_to_bytes(packet_length-ip_header_length,2))
//                    .add_bytes(utils.get_byte_subset(bytes.buffer,ip_header_length,(int)packet_length-ip_header_length))
//                    .integrate_to_bytes())!=0);
//            long c2=utils.bytes_to_unsigned_long(ip_record.tcp_segment.check_sum);
//            long c3=utils.calculate_ones_complement_checksum_tcp(bytes.buffer,ip_header_length,bytes.end);

            ip_record.tcp_segment.data_offset=(utils.byte_to_unsinged_long(bytes.buffer[ip_header_length+12])&0xf0)/16*4;
            ip_record.tcp_segment.window_size=utils.bytes_to_unsigned_long(bytes.buffer,ip_header_length+14,2);
            ip_record.tcp_segment.parse_and_set_options(bytes.buffer,ip_header_length+20,ip_record.tcp_segment.data_offset-20);
            ip_record.tcp_segment.window_size=ip_record.tcp_segment.window_size<<ip_record.tcp_segment.options.window_scale;
            if(ip_header_length+ip_record.tcp_segment.data_offset<packet_length){
                ip_record.tcp_segment.has_data=true;
                ip_record.tcp_segment.data_length=(int)packet_length-(ip_header_length+ip_record.tcp_segment.data_offset);
                bytes.offset=ip_header_length+ip_record.tcp_segment.data_offset;//now the pointer only points to the data portion
//                ip_record.tcp_segment.data=utils.get_byte_subset(bytes.buffer,ip_header_length+ip_record.tcp_segment.data_offset,(int)packet_length-(ip_header_length+ip_record.tcp_segment.data_offset));
            }else ip_record.tcp_segment.has_data=false;
//            else{
//                ip_record.tcp_segment.data=null;
//            }
        }
        if(ip_record.ip_header.protocol == com.paranoia.zharftor.protocols_namespace.IP.UDP_PROTOCOL_NUMBER){//udp
            if(ip_record.udp_datagram==null)ip_record.udp_datagram=new udp(-1);
            if(ip_record.ip_header.packet_offset==0) {
                ip_record.udp_datagram.src_port = utils.bytes_to_unsigned_long(bytes.buffer, ip_header_length, 2);//20
                ip_record.udp_datagram.dst_port = utils.bytes_to_unsigned_long(bytes.buffer, ip_header_length + 2, 2);//22
                ip_record.udp_datagram.pure_data_len = (int)utils.bytes_to_unsigned_long(bytes.buffer, ip_header_length + 4, 2)-8;
                bytes.offset = ip_header_length + 8;
            }else {
                bytes.offset = ip_header_length;
            }
        }
    }

    private void shutdown_virtual_stack(){
        vpn_stopped=true;
        device_TUN_com_thread.interrupt();
        buffered_data_distributer_thread_tcp.interrupt();
        buffered_data_distributer_thread_udp.interrupt();
        connections_timeout_controller.interrupt();
    }
    private void init_virtual_stack(){
        packet.tcp_segment=new tcp(10);
        packet.udp_datagram=new udp(-1);
        packet.ip_header=new ip();
        vpn_stopped=false;
        device_TUN_com_thread.start(intermidiate_out_runnable);
//        calculate_time_for_this_connection();
        update_main(main.VPN_STATE_CONNECTED);
    }
    private final Runnable intermidiate_out_runnable=new Runnable() {
        @Override
        public void run() {
            while(!vpn_stopped){
                    try {
                        Tun_buffer_in.offset = 0;
                        Tun_buffer_in.end = TUNinputstream.read(Tun_buffer_in.buffer);
                        if (Tun_buffer_in.end - Tun_buffer_in.offset > 20)
                            process_TUN_data(Tun_buffer_in);//                        bsize=TUNinputstream.read(frame);
//                        process_TUN_data(utils.get_byte_subset(frame,0,bsize));
                    } catch (Throwable e) {
//                        e.printStackTrace();
                    }
                }
        }
    };
    private one_task_one_thread device_TUN_com_thread=new one_task_one_thread(),
            buffered_data_distributer_thread_tcp=new one_task_one_thread(),
            buffered_data_distributer_thread_udp=new one_task_one_thread(),
    connections_timeout_controller=new one_task_one_thread();
    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return super.onBind(intent);
    }

    public void reset_vpn(){
        if(!vpn_con_maintainer_running)return;
        //vpn is still running
        shutdown_virtual_stack();
        try {
            if(sc!=null) {
                sc.close();
                sc=null;
            }
            if(localTunnel!=null){
                localTunnel.close();
                localTunnel=null;
            }
        } catch (IOException e) {
//            e.printStackTrace();
        }
        server_interface.getInstance().shutdown();
//        update_main(main.VPN_STATE_CONNECTING);
        synchronized (vpn){
            vpn.notifyAll();
        }
    }
    public void shut_down(){
        vpn_con_maintainer_running =false;
        if(server_connection_maintainer_thread!=null) {
            shutdown_virtual_stack();
            server_connection_maintainer_thread.interrupt();
            server_connection_maintainer_thread=null;
        }
//            vpn_running=false;
        try {
            if(sc!=null) {
                sc.close();
                sc=null;
            }
            if(localTunnel!=null){
                localTunnel.close();
                localTunnel=null;
            }
        } catch (IOException e) {
//            e.printStackTrace();
        }
//        disconnection_timer.cancel();
        server_interface.getInstance().shutdown();
        update_main(main.VPN_STATE_UNCONNETED);
    }
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        vpn=this;
        if(intent==null)return super.onStartCommand(intent, flags, startId);
        if(intent.getExtras()==null)return super.onStartCommand(intent, flags, startId);
        if(intent.getExtras().getBoolean("disconnect")){
            shut_down();
            return super.onStartCommand(intent, flags, startId);
        }
        Intent i=prepare(this);
        if(i!=null){
            activity.startActivityForResult(i,1);
        }else{
//            vpn_stopped=false;
            vpn_con_maintainer_running =true;
            vpn_permission_granted=true;
            if(server_connection_maintainer_thread==null) {
                server_connection_maintainer_thread = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        while (!Thread.currentThread().isInterrupted()&& vpn_con_maintainer_running) {
                            update_main(main.VPN_STATE_CONNECTING);
                            try {
                                if (sc == null) {
                                    try {
                                        sc = SocketChannel.open();
                                        protect(sc.socket());
//                                        tcp_cons.vanish();
//                                        udp_cons.vanish();
//                                        dns_cons.vanish();
                                        counter = 0;
//                                protected_socket.setTcpNoDelay(true);
                                    } catch (SocketException e) {
//                                        e.printStackTrace();
                                    } catch (IOException e) {
//                                        e.printStackTrace();
                                    }
                                    continue;
                                } else if (!sc.isConnected() || sc.socket().isClosed()) {
                                    if (sc.socket().isClosed()) {
                                        sc = null;
                                        continue;
                                    }
//                                boolean tmp = vpn_stopped;
                                    try {
                                        server_interface.getInstance().shutdown();
                                        if (localTunnel != null) {
                                            shutdown_virtual_stack();
                                            localTunnel.close();
                                            localTunnel = null;
                                        }
                                        if (sc != null) {
                                            is_ready_for_tun_creation=false;
//                                            sc.connect(new InetSocketAddress("192.168.1.11" ,999));
//                                            sc.connect(new InetSocketAddress("ca0.zharftor.com" ,999));
                                            sc.connect(new InetSocketAddress(server_interface.server_domain_name, server_interface.server_port));
//                                            sc.connect(new InetSocketAddress(server_interface.server_domain_name, 999));//experimental port
                                        }
                                        else continue;
//                                    vpn_stopped = tmp;
                                        sc.configureBlocking(true);
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                                            sc.setOption(StandardSocketOptions.TCP_NODELAY, true);
                                            sc.setOption(StandardSocketOptions.SO_RCVBUF, 0x1000000);
                                            sc.setOption(StandardSocketOptions.SO_SNDBUF, 0x1000000);
                                        }
                                        server_interface.getInstance().init_interface();
                                    }catch (java.net.ConnectException e){
                                        e.printStackTrace();
                                        shut_down();
                                        activity.show_message_non_ui_threads(e.getMessage());
                                    } catch (Throwable e) {
                                        e.printStackTrace();
                                        sc = null;
                                        Thread.sleep(700);
//                                    vpn_stopped = tmp;
                                        continue;
                                    }
                                } else {
                                    if (localTunnel == null&&
                                            is_ready_for_tun_creation) {
                                        create_TUN();
                                        synchronized (vpn) {
                                            try {
                                                vpn.wait();
                                            } catch (InterruptedException e) {
//                                                e.printStackTrace();
                                                return;
                                            }
                                        }
                                    }
                                }

                            }catch (Throwable t){
                                t.printStackTrace();
                            }
                        }
                    }
                });
                server_connection_maintainer_thread.start();
            }
        }
        return super.onStartCommand(intent, flags, startId);
    }
    private static  ParcelFileDescriptor localTunnel;
    public void create_TUN(){
        Builder builder = new Builder();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            builder
                    .addAddress(utils.byte_to_regex_seprated_string(virtual_network_ip,"."), virtual_network_subnet)
                    .addRoute("0.0.0.0", 0)
                    .addDnsServer(utils.byte_to_regex_seprated_string(dns_ip,"."));
            if(app_data_and_preferences.getInstance().app_filters.filter_type==
                    app_data_and_preferences.apps_filters_struct.tunnel_all_except){
                for(app_data_and_preferences.filter_app_entry app:app_data_and_preferences.getInstance().app_filters.apps_rejected){
                    try {
                        builder.addDisallowedApplication(app.package_name);
                    } catch (PackageManager.NameNotFoundException e) {
                        e.printStackTrace();
                    }
                }
            }
            if(app_data_and_preferences.getInstance().app_filters.filter_type==
                    app_data_and_preferences.apps_filters_struct.tunnel_none_except){
                for(app_data_and_preferences.filter_app_entry app:app_data_and_preferences.getInstance().app_filters.apps_accepted){
                    try {
                        builder.addAllowedApplication(app.package_name);
                    } catch (PackageManager.NameNotFoundException e) {
                        e.printStackTrace();
                    }
                }
            }
            localTunnel= builder.establish();
        }
        TUNinputstream = new FileInputStream(localTunnel.getFileDescriptor());
        TUNoutputstream= new FileOutputStream(localTunnel.getFileDescriptor());
//        server_interface.getInstance();
        init_virtual_stack();
    }

    @Override
    public void onRevoke() {
        super.onRevoke();
        shut_down();
    }
    public void update_main(short state){
        if(is_main_accessible){
            activity.set_App_state_non_ui_thread(state);
            activity.set_App_connection_status_non_ui_thread(main.CONNECTION_STATUS_READY_OR_CONNECTED);
        }
    }
    public static boolean is_connected(){
        if(vpn_service.localTunnel !=null)
            if(vpn_service.vpn.vpn_con_maintainer_running &&!vpn_service.vpn.vpn_stopped){
                return true;
        }
        return false;
    }
    public static boolean is_connecting() {
        if(vpn_service.vpn!=null)
            if(vpn_service.vpn.server_connection_maintainer_thread!=null)
                if (vpn_service.vpn.vpn_con_maintainer_running &&vpn.server_connection_maintainer_thread.isAlive()) {
                    return true;
        }
        return false;
    }
    private static SocketChannel sc;
    public static SocketChannel get_protected_socket(){
        return sc;
    }
    public static void close_protected_socket()  {
        if(sc!=null){
            try{
                synchronized (vpn) {
                    sc.close();
                    vpn.notify();
                }
            }catch (Exception e){
//                e.printStackTrace();
            }
        }
    }
    public static final byte[] mac_addr=new byte[6];
    public static void write_mac_addr(byte[] bytes){
        int i=0;
        while(i<6){
            mac_addr[i]=bytes[i];
            i++;
        }
    }
//    public static long extra_hours,minimum_hours=1,this_connection_duration_milis;
//    public static long this_connection_start_timestamp=0;
//    public void calculate_time_for_this_connection(){
//        if(extra_hours!=0){
//            this_connection_duration_milis= this_connection_duration_milis+(extra_hours*60*60*1000);
//        }else {
//            this_connection_duration_milis = minimum_hours * 60 * 60 * 1000;
//        }
////        this_connection_duration_milis=125000;
//        extra_hours=0;
//        this_connection_start_timestamp=System.currentTimeMillis();
//        try{
//            if(disconnection_timer!=null){
//                disconnection_timer.cancel();
//            }
//        }catch (Throwable t){
//        }
//        disconnection_timer=new Timer();
//        disconnection_timer.schedule(new TimerTask() {
//            @Override
//            public void run() {
//                    shut_down();
//            }
//        },this_connection_duration_milis);
//    }
//    public static void add_time(int hours){
//        extra_hours=extra_hours+hours;
//        vpn.calculate_time_for_this_connection();
//    }
//    public static long get_active_connection_time_left_milis(){
//        return this_connection_duration_milis-(System.currentTimeMillis()-this_connection_start_timestamp);
//    }
}
