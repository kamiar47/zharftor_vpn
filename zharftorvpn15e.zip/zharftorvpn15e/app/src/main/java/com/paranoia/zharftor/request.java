package com.paranoia.zharftor;

import com.paranoia.zharftor.poshan.key_manager;

import java.nio.ByteBuffer;

class request {
    public static final String END_OF_REQUEST="E O R R O E";
    public static final int VERSION_PACKET_FORWARD=0
    ,VERSION_PACKET_INTERPRET=1
    ,VERSION_PACKET_INTERPRET_2=12
    ,COMMAND_CONNECT_TCP=0
    ,COMMAND_FORWARD_DATA_TCP=2
    ,COMMAND_FORWARD_DATA_UDP=1
    , COMMAND_CLOSE_TCP_CONNECTION =3
            ,COMMAND_WAIT_SECONDS=4,
    COMMAND_CONNECT_UDP=5,
    COMMAND_UNCONNECT_UDP=6,
    COMMAND_VERSION_SET_AND_RANDOM_BYTES=7,
        COMMAND_RAW_PACKET=8;
    public short version=0;
    public int id=-1
    ,size=0
    ,flags
    ,command
    ,dst_port
    ,wait_seconds=0;
    public ByteBuffer bbuffer=null;
    private int request_offset=0;
    public byte[] dst_ip=new byte[4];
    public com.paranoia.zharftor.utils.pointed_byteArray data=new com.paranoia.zharftor.utils.pointed_byteArray(0x10100);//in case of tcp data this is the
    public void serialize(){
        bbuffer=data.byteBuffer;
        bbuffer.position(0);
        bbuffer.limit(data.buffer.length-1);
        if(version==VERSION_PACKET_INTERPRET||version==VERSION_PACKET_INTERPRET_2||version==VERSION_PACKET_FORWARD){//form packet in accourdance with version protocol
            if(command==COMMAND_CONNECT_TCP||command==COMMAND_CONNECT_UDP){
                com.paranoia.zharftor.utils.insert_int_to_bytes(data.buffer,request_offset,version,1);//version
                com.paranoia.zharftor.utils.insert_int_to_bytes(data.buffer,request_offset+1,command,1);//command
                com.paranoia.zharftor.utils.insert_int_to_bytes(data.buffer,request_offset+2,id,3);//id
                bbuffer.position(5);
                bbuffer.put(dst_ip);//ip
                bbuffer.putShort((short) dst_port);//port
                data.offset=0;
                data.end=11;
            }
            if(command== COMMAND_CLOSE_TCP_CONNECTION){
                com.paranoia.zharftor.utils.insert_int_to_bytes(data.buffer,request_offset,version,1);//version
                com.paranoia.zharftor.utils.insert_int_to_bytes(data.buffer,request_offset+1,command,1);//command
                com.paranoia.zharftor.utils.insert_int_to_bytes(data.buffer,request_offset+2,id,3);//id
                data.offset=0;
                data.end=5;
            }
            if(command== COMMAND_UNCONNECT_UDP){
                com.paranoia.zharftor.utils.insert_int_to_bytes(data.buffer,request_offset,version,1);//version
                com.paranoia.zharftor.utils.insert_int_to_bytes(data.buffer,request_offset+1,command,1);//command
                com.paranoia.zharftor.utils.insert_int_to_bytes(data.buffer,request_offset+2,id,3);//id
                data.offset=0;
                data.end=5;
            }
            if(command==COMMAND_FORWARD_DATA_TCP||command==COMMAND_FORWARD_DATA_UDP){
                request_offset=data.offset-8;
                com.paranoia.zharftor.utils.insert_int_to_bytes(data.buffer,request_offset,version,1);//version
                com.paranoia.zharftor.utils.insert_int_to_bytes(data.buffer,request_offset+1,command,1);//command
                com.paranoia.zharftor.utils.insert_int_to_bytes(data.buffer,request_offset+2,0,2);//size
                com.paranoia.zharftor.utils.insert_int_to_bytes(data.buffer,request_offset+4,id,3);//id
                com.paranoia.zharftor.utils.insert_int_to_bytes(data.buffer,request_offset+7,flags,1);//flags
//                bbuffer.put(); //data already exists we just add header
                com.paranoia.zharftor.utils.insert_int_to_bytes(data.buffer,request_offset+2,8+(data.end-data.offset),2);
                data.offset=request_offset;
                //end is already specified
            }
            if(command==COMMAND_WAIT_SECONDS){
                com.paranoia.zharftor.utils.insert_int_to_bytes(data.buffer,request_offset,version,1);//version
                com.paranoia.zharftor.utils.insert_int_to_bytes(data.buffer,request_offset+1,command,1);//command
                com.paranoia.zharftor.utils.insert_int_to_bytes(data.buffer,request_offset+2,id,3);//id
                com.paranoia.zharftor.utils.insert_int_to_bytes(data.buffer,request_offset+5,wait_seconds,1);//time in seconds
                data.offset=0;
                data.end=6;
            }
            if(command==COMMAND_VERSION_SET_AND_RANDOM_BYTES){
                com.paranoia.zharftor.utils.insert_int_to_bytes(data.buffer,request_offset,version,1);//version
                com.paranoia.zharftor.utils.insert_int_to_bytes(data.buffer,request_offset+1,command,1);//command
                byte[] rand=new byte[13];
                key_manager.random.nextBytes(rand);
                System.arraycopy(rand,0,data.buffer,request_offset+2,13);
                data.offset=0;
                data.end=15;
            }
            if(command==COMMAND_RAW_PACKET){

                request_offset=data.offset-4;
                com.paranoia.zharftor.utils.insert_int_to_bytes(data.buffer,request_offset,version,1);//version
                com.paranoia.zharftor.utils.insert_int_to_bytes(data.buffer,request_offset+1,command,1);//command
                //data already exists we just add header
                com.paranoia.zharftor.utils.insert_int_to_bytes(data.buffer,request_offset+2,4+(data.end-data.offset),2);//size
                data.offset=request_offset;
                //end is already specified
            }
        }
    }
}
